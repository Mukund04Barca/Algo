import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { useApp } from '@/lib/AppContext';
import Sidebar from '@/components/layout/Sidebar';
import Header from '@/components/layout/Header';
import AuthPage from '@/pages/AuthPage';
import Dashboard from '@/pages/Dashboard';
import Problems from '@/pages/Problems';
import Revision from '@/pages/Revision';
import Analytics from '@/pages/Analytics';
import SettingsPage from '@/pages/SettingsPage';

export default function App() {
  const { auth } = useApp();

  if (!auth) return <AuthPage />;

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Header />
        <main
          style={{
            flex: 1,
            overflow: 'auto',
            background: 'var(--bg-primary)',
          }}
        >
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/problems" element={<Problems />} />
            <Route path="/revision" element={<Revision />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
