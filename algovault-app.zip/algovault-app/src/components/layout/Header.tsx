import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Flame, X } from 'lucide-react';
import { useApp } from '@/lib/AppContext';
import { ALL_PROBLEMS } from '@/data/problems';

export default function Header() {
  const { userData } = useApp();
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const streak = userData?.streak || 0;

  const results = query.length > 1
    ? ALL_PROBLEMS.filter((p) =>
        p.title.toLowerCase().includes(query.toLowerCase()) ||
        p.topic.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 8)
    : [];

  return (
    <header
      style={{
        height: 'var(--header-height)',
        borderBottom: '1px solid var(--border)',
        display: 'flex',
        alignItems: 'center',
        padding: '0 20px',
        gap: '16px',
        background: 'var(--bg-secondary)',
        position: 'sticky',
        top: 0,
        zIndex: 5,
      }}
    >
      {/* Search bar */}
      <div style={{ flex: 1, position: 'relative', maxWidth: '480px' }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            background: 'var(--bg-tertiary)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius-md)',
            padding: '6px 12px',
            cursor: 'text',
          }}
          onClick={() => setSearchOpen(true)}
        >
          <Search size={14} color="var(--text-muted)" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setSearchOpen(true)}
            placeholder="Search problems, topics..."
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--text-primary)',
              width: '100%',
              fontSize: '13px',
            }}
          />
          {query && (
            <button
              onClick={(e) => { e.stopPropagation(); setQuery(''); setSearchOpen(false); }}
              style={{ background: 'none', border: 'none', color: 'var(--text-muted)', padding: 0 }}
            >
              <X size={12} />
            </button>
          )}
        </div>

        {/* Search dropdown */}
        {searchOpen && results.length > 0 && (
          <div
            style={{
              position: 'absolute',
              top: 'calc(100% + 6px)',
              left: 0,
              right: 0,
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-md)',
              boxShadow: 'var(--shadow-lg)',
              overflow: 'hidden',
              zIndex: 100,
            }}
            className="animate-in"
          >
            {results.map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  navigate(`/problems?id=${p.id}&roadmap=${encodeURIComponent(p.roadmap)}`);
                  setSearchOpen(false);
                  setQuery('');
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  width: '100%',
                  padding: '10px 14px',
                  background: 'none',
                  border: 'none',
                  color: 'var(--text-primary)',
                  textAlign: 'left',
                  borderBottom: '1px solid var(--border-muted)',
                  fontSize: '13px',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--bg-hover)')}
                onMouseLeave={(e) => (e.currentTarget.style.background = 'none')}
              >
                <span
                  style={{
                    fontSize: '11px',
                    padding: '2px 6px',
                    borderRadius: 'var(--radius-sm)',
                    fontFamily: 'var(--font-mono)',
                  }}
                  className={`badge-${p.difficulty.toLowerCase()}`}
                >
                  {p.difficulty[0]}
                </span>
                <span style={{ flex: 1 }}>{p.title}</span>
                <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{p.topic}</span>
              </button>
            ))}
          </div>
        )}

        {/* Click outside to close */}
        {searchOpen && (
          <div
            style={{ position: 'fixed', inset: 0, zIndex: 99 }}
            onClick={() => setSearchOpen(false)}
          />
        )}
      </div>

      <div style={{ flex: 1 }} />

      {/* Streak */}
      {streak > 0 && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '4px 12px',
            background: 'rgba(210, 153, 34, 0.1)',
            borderRadius: 'var(--radius-full)',
            color: 'var(--color-warning)',
            fontSize: '13px',
            fontWeight: 500,
          }}
        >
          <Flame size={14} />
          {streak} day streak
        </div>
      )}
    </header>
  );
}
