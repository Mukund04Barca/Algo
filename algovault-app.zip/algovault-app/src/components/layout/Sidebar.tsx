import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  BarChart3,
  RefreshCw,
  Settings,
  ChevronLeft,
  ChevronRight,
  Zap,
  Cloud,
  CloudOff,
} from 'lucide-react';
import { useApp } from '@/lib/AppContext';

const NAV = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/problems', icon: BookOpen, label: 'Problems' },
  { path: '/revision', icon: RefreshCw, label: 'Revision' },
  { path: '/analytics', icon: BarChart3, label: 'Analytics' },
  { path: '/settings', icon: Settings, label: 'Settings' },
];

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const { auth, userData, isSyncing, lastSyncTime } = useApp();
  const location = useLocation();

  const totalProblems = Object.keys(userData?.progress || {}).length;
  const solved = Object.values(userData?.progress || {}).filter(
    (p) => p.status === 'Solved' || p.status === 'Mastered'
  ).length;
  const pct = totalProblems > 0 ? Math.round((solved / 305) * 100) : 0;

  return (
    <aside
      style={{
        width: collapsed ? '60px' : 'var(--sidebar-width)',
        minWidth: collapsed ? '60px' : 'var(--sidebar-width)',
        background: 'var(--bg-secondary)',
        borderRight: '1px solid var(--border)',
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        position: 'sticky',
        top: 0,
        transition: 'width 250ms var(--ease-out), min-width 250ms var(--ease-out)',
        overflow: 'hidden',
        zIndex: 10,
      }}
    >
      {/* Logo */}
      <div
        style={{
          padding: '16px',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          borderBottom: '1px solid var(--border)',
          minHeight: 'var(--header-height)',
        }}
      >
        <div
          style={{
            width: '28px',
            height: '28px',
            borderRadius: '6px',
            background: 'linear-gradient(135deg, var(--color-accent), var(--color-purple))',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}
        >
          <Zap size={16} color="#fff" />
        </div>
        {!collapsed && (
          <span
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: '18px',
              fontWeight: 400,
              color: 'var(--text-primary)',
              letterSpacing: '-0.3px',
              whiteSpace: 'nowrap',
            }}
          >
            AlgoVault
          </span>
        )}
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '8px 0', overflow: 'hidden' }}>
        {NAV.map(({ path, icon: Icon, label }) => {
          const active = location.pathname === path;
          return (
            <NavLink
              key={path}
              to={path}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                padding: collapsed ? '10px 16px' : '10px 16px',
                color: active ? 'var(--color-accent)' : 'var(--text-secondary)',
                background: active ? 'var(--color-accent-muted)' : 'transparent',
                textDecoration: 'none',
                transition: 'all 160ms var(--ease-out)',
                borderRadius: '6px',
                margin: '2px 8px',
                justifyContent: collapsed ? 'center' : 'flex-start',
              }}
              onMouseEnter={(e) => {
                if (!active) e.currentTarget.style.background = 'var(--bg-hover)';
              }}
              onMouseLeave={(e) => {
                if (!active) e.currentTarget.style.background = 'transparent';
              }}
            >
              <Icon size={18} style={{ flexShrink: 0 }} />
              {!collapsed && (
                <span style={{ fontSize: '14px', fontWeight: active ? 500 : 400, whiteSpace: 'nowrap' }}>
                  {label}
                </span>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Progress bar */}
      {!collapsed && userData && (
        <div style={{ padding: '12px 16px', borderTop: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Overall Progress</span>
            <span style={{ fontSize: '12px', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}>
              {solved}/305
            </span>
          </div>
          <div
            style={{
              height: '4px',
              background: 'var(--border)',
              borderRadius: '2px',
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                height: '100%',
                width: `${pct}%`,
                background: 'linear-gradient(90deg, var(--color-accent), var(--color-purple))',
                borderRadius: '2px',
                transition: 'width 600ms var(--ease-out)',
              }}
            />
          </div>
        </div>
      )}

      {/* User / sync */}
      {!collapsed && auth && (
        <div
          style={{
            padding: '12px 16px',
            borderTop: '1px solid var(--border)',
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
          }}
        >
          <img
            src={auth.user.avatar_url}
            alt="avatar"
            style={{ width: '28px', height: '28px', borderRadius: '50%', flexShrink: 0 }}
          />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div
              style={{
                fontSize: '13px',
                fontWeight: 500,
                color: 'var(--text-primary)',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {auth.user.login}
            </div>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
              {isSyncing ? (
                <>
                  <Cloud size={10} className="spin" />
                  Syncing...
                </>
              ) : lastSyncTime ? (
                <>
                  <Cloud size={10} />
                  Synced
                </>
              ) : (
                <>
                  <CloudOff size={10} />
                  Not synced
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        style={{
          position: 'absolute',
          right: '-12px',
          top: '28px',
          width: '24px',
          height: '24px',
          borderRadius: '50%',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--text-muted)',
          zIndex: 20,
        }}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
    </aside>
  );
}
