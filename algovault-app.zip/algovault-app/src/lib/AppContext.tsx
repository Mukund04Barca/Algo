import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { GitHubAuth, UserData, ProblemProgress } from '@/types';
import {
  GitHubService,
  createEmptyUserData,
  createDefaultProgress,
  computeNextRevision,
  updateStreak,
} from '@/services/github';

interface AppContextType {
  auth: GitHubAuth | null;
  userData: UserData | null;
  githubService: GitHubService | null;
  isSyncing: boolean;
  lastSyncTime: Date | null;
  syncError: string | null;
  setAuth: (auth: GitHubAuth | null) => void;
  getProgress: (problemId: string) => ProblemProgress;
  saveProgress: (progress: ProblemProgress) => Promise<void>;
  manualBackup: (message?: string) => Promise<void>;
  logout: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

const AUTH_KEY = 'algovault_auth';
const DATA_KEY = 'algovault_data_cache';

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [auth, setAuthState] = useState<GitHubAuth | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [githubService, setGithubService] = useState<GitHubService | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);

  // Load auth from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(AUTH_KEY);
    if (stored) {
      try {
        const parsedAuth = JSON.parse(stored) as GitHubAuth;
        initService(parsedAuth);
      } catch {
        localStorage.removeItem(AUTH_KEY);
      }
    }
  }, []);

  const initService = useCallback(async (newAuth: GitHubAuth) => {
    const svc = new GitHubService(newAuth.token, newAuth.user.login, newAuth.repoName);
    setGithubService(svc);
    setAuthState(newAuth);

    // Load data
    setIsSyncing(true);
    setSyncError(null);
    try {
      const cached = localStorage.getItem(DATA_KEY);
      if (cached) {
        setUserData(JSON.parse(cached));
      }

      const remote = await svc.loadData();
      const data = remote || createEmptyUserData();
      setUserData(data);
      localStorage.setItem(DATA_KEY, JSON.stringify(data));
      setLastSyncTime(new Date());
    } catch (e) {
      setSyncError((e as Error).message);
    } finally {
      setIsSyncing(false);
    }
  }, []);

  const setAuth = useCallback(
    (newAuth: GitHubAuth | null) => {
      if (newAuth) {
        localStorage.setItem(AUTH_KEY, JSON.stringify(newAuth));
        initService(newAuth);
      } else {
        localStorage.removeItem(AUTH_KEY);
        localStorage.removeItem(DATA_KEY);
        setAuthState(null);
        setUserData(null);
        setGithubService(null);
      }
    },
    [initService]
  );

  const getProgress = useCallback(
    (problemId: string): ProblemProgress => {
      return userData?.progress[problemId] || createDefaultProgress(problemId);
    },
    [userData]
  );

  const saveProgress = useCallback(
    async (progress: ProblemProgress) => {
      if (!userData || !githubService) return;

      const wasNotSolved =
        userData.progress[progress.problemId]?.status !== 'Solved' &&
        userData.progress[progress.problemId]?.status !== 'Mastered';

      const isSolvedNow = progress.status === 'Solved' || progress.status === 'Mastered';

      // Compute next revision if newly solved
      let updatedProgress = { ...progress };
      if (wasNotSolved && isSolvedNow) {
        updatedProgress.lastSolved = new Date().toISOString();
        updatedProgress.attempts = (updatedProgress.attempts || 0) + 1;
        const revCount = updatedProgress.revisionDates.length;
        updatedProgress.nextRevision = computeNextRevision(revCount);
      }

      let newData: UserData = {
        ...userData,
        lastUpdated: new Date().toISOString(),
        progress: {
          ...userData.progress,
          [progress.problemId]: updatedProgress,
        },
      };

      if (wasNotSolved && isSolvedNow) {
        newData = updateStreak(newData);
      }

      setUserData(newData);
      localStorage.setItem(DATA_KEY, JSON.stringify(newData));

      // Sync to GitHub
      setIsSyncing(true);
      setSyncError(null);
      try {
        await githubService.saveData(newData);
        setLastSyncTime(new Date());
      } catch (e) {
        setSyncError((e as Error).message);
      } finally {
        setIsSyncing(false);
      }
    },
    [userData, githubService]
  );

  const manualBackup = useCallback(
    async (message?: string) => {
      if (!userData || !githubService) return;
      setIsSyncing(true);
      setSyncError(null);
      try {
        await githubService.manualBackup(userData, message || '');
        setLastSyncTime(new Date());
      } catch (e) {
        setSyncError((e as Error).message);
      } finally {
        setIsSyncing(false);
      }
    },
    [userData, githubService]
  );

  const logout = useCallback(() => {
    setAuth(null);
  }, [setAuth]);

  return (
    <AppContext.Provider
      value={{
        auth,
        userData,
        githubService,
        isSyncing,
        lastSyncTime,
        syncError,
        setAuth,
        getProgress,
        saveProgress,
        manualBackup,
        logout,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
