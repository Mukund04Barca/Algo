import { useMemo } from 'react';
import {
  AreaChart, Area, BarChart, Bar, RadarChart, Radar, PolarGrid, PolarAngleAxis,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie
} from 'recharts';
import { BarChart2, TrendingUp, Target, Clock, Layers, Award } from 'lucide-react';
import { useApp } from '../lib/AppContext';
import { ALL_PROBLEMS } from '../data/problems';
import { format, subDays, parseISO } from 'date-fns';

const DIFF_COLORS = {
  Easy: '#3fb950',
  Medium: '#d29922',
  Hard: '#f85149',
};

const STATUS_COLORS: Record<string, string> = {
  'Mastered': '#3fb950',
  'Solved': '#58a6ff',
  'Needs Revision': '#d29922',
  'Learning': '#bc8cff',
  'Not Started': '#30363d',
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: 'var(--bg-secondary)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 8,
      padding: '8px 12px',
      fontSize: 12,
    }}>
      {label && <div style={{ color: 'var(--text-muted)', marginBottom: 4 }}>{label}</div>}
      {payload.map((p: any, i: number) => (
        <div key={i} style={{ color: p.color || 'var(--text-primary)', display: 'flex', gap: 8 }}>
          <span>{p.name}:</span>
          <span style={{ fontWeight: 600 }}>{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function Analytics() {
  const { userData } = useApp();

  const stats = useMemo(() => {
    if (!userData) return null;
    const progress = userData.progress;
    const solved = Object.values(progress).filter(p => p.status === 'Solved' || p.status === 'Mastered');

    // Activity over last 30 days
    const activityData = Array.from({ length: 30 }, (_, i) => {
      const date = subDays(new Date(), 29 - i);
      const dateStr = format(date, 'yyyy-MM-dd');
      return {
        date: format(date, 'MMM d'),
        problems: userData.dailyActivity?.[dateStr] || 0,
      };
    });

    // Status distribution
    const statusCounts: Record<string, number> = {
      'Mastered': 0, 'Solved': 0, 'Needs Revision': 0, 'Learning': 0, 'Not Started': 0,
    };
    for (const p of ALL_PROBLEMS) {
      const s = progress[p.id]?.status || 'Not Started';
      statusCounts[s] = (statusCounts[s] || 0) + 1;
    }
    const statusData = Object.entries(statusCounts)
      .map(([name, value]) => ({ name, value }))
      .filter(d => d.value > 0);

    // Difficulty breakdown by solved
    const diffData = ['Easy', 'Medium', 'Hard'].map(diff => {
      const total = ALL_PROBLEMS.filter(p => p.difficulty === diff).length;
      const done = solved.filter(sp => {
        const prob = ALL_PROBLEMS.find(p => p.id === sp.problemId);
        return prob?.difficulty === diff;
      }).length;
      return { name: diff, solved: done, remaining: total - done, total };
    });

    // Topic radar (top 8 topics by solved %)
    const topicMap: Record<string, { total: number; solved: number }> = {};
    for (const p of ALL_PROBLEMS) {
      if (!topicMap[p.topic]) topicMap[p.topic] = { total: 0, solved: 0 };
      topicMap[p.topic].total++;
      const prog = progress[p.id];
      if (prog?.status === 'Solved' || prog?.status === 'Mastered') {
        topicMap[p.topic].solved++;
      }
    }
    const radarData = Object.entries(topicMap)
      .filter(([, v]) => v.total >= 3)
      .map(([topic, v]) => ({
        topic: topic.length > 12 ? topic.slice(0, 12) + '…' : topic,
        value: Math.round((v.solved / v.total) * 100),
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);

    // Roadmap progress
    const roadmapData = ['Striver A2Z', 'Blind 75', 'NeetCode 150'].map(rm => {
      const total = ALL_PROBLEMS.filter(p => p.roadmap === rm).length;
      const done = ALL_PROBLEMS.filter(p => {
        const prog = progress[p.id];
        return p.roadmap === rm && (prog?.status === 'Solved' || prog?.status === 'Mastered');
      }).length;
      return { name: rm.replace(' 150', '').replace(' A2Z', ''), total, solved: done, pct: Math.round((done / total) * 100) };
    });

    // Avg confidence of solved problems
    const avgConfidence = solved.length > 0
      ? (solved.reduce((sum, p) => sum + (p.confidence || 3), 0) / solved.length).toFixed(1)
      : '0.0';

    // Avg time
    const timed = solved.filter(p => p.timeTaken > 0);
    const avgTime = timed.length > 0
      ? Math.round(timed.reduce((sum, p) => sum + p.timeTaken, 0) / timed.length)
      : 0;

    return { activityData, statusData, diffData, radarData, roadmapData, avgConfidence, avgTime, totalSolved: solved.length };
  }, [userData]);

  if (!stats) return null;

  const sectionTitle = (icon: React.ReactNode, title: string) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 14 }}>
      <div style={{ color: 'var(--color-accent)' }}>{icon}</div>
      <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>{title}</span>
    </div>
  );

  const card = (children: React.ReactNode, style: React.CSSProperties = {}) => (
    <div style={{
      background: 'var(--bg-secondary)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 10,
      padding: '16px 18px',
      ...style,
    }}>
      {children}
    </div>
  );

  return (
    <div style={{ padding: '24px 32px', maxWidth: 1100, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <BarChart2 size={20} color="var(--color-accent)" />
          <h1 style={{ fontSize: 20, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>Analytics</h1>
        </div>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, margin: 0 }}>
          Your DSA progress at a glance.
        </p>
      </div>

      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
        {[
          { label: 'Total Solved', value: stats.totalSolved, icon: <Target size={15} />, color: 'var(--color-accent)' },
          { label: 'Avg Confidence', value: `${stats.avgConfidence}/5`, icon: <Award size={15} />, color: 'var(--color-purple)' },
          { label: 'Avg Solve Time', value: stats.avgTime > 0 ? `${stats.avgTime}m` : '—', icon: <Clock size={15} />, color: 'var(--color-warning)' },
          { label: 'Coverage', value: `${Math.round((stats.totalSolved / ALL_PROBLEMS.length) * 100)}%`, icon: <Layers size={15} />, color: 'var(--color-success)' },
        ].map(kpi => (
          <div key={kpi.label} style={{
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-subtle)',
            borderRadius: 10,
            padding: '14px 16px',
            display: 'flex',
            alignItems: 'center',
            gap: 12,
          }}>
            <div style={{
              width: 34, height: 34, borderRadius: 8,
              background: `${kpi.color}18`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: kpi.color, flexShrink: 0,
            }}>
              {kpi.icon}
            </div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', lineHeight: 1 }}>{kpi.value}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{kpi.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Activity chart — full width */}
      {card(
        <>
          {sectionTitle(<TrendingUp size={14} />, '30-Day Activity')}
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={stats.activityData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="actGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#58a6ff" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#58a6ff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#21262d" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#6e7681' }} tickLine={false} axisLine={false}
                interval={4} />
              <YAxis tick={{ fontSize: 10, fill: '#6e7681' }} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="problems" name="Problems" stroke="#58a6ff" strokeWidth={2}
                fill="url(#actGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </>,
        { marginBottom: 16 }
      )}

      {/* 2-col row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Difficulty breakdown */}
        {card(
          <>
            {sectionTitle(<BarChart2 size={14} />, 'Difficulty Breakdown')}
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={stats.diffData} layout="vertical" margin={{ top: 0, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#21262d" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10, fill: '#6e7681' }} tickLine={false} axisLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 12, fill: '#8b949e' }} tickLine={false} axisLine={false} width={50} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="solved" name="Solved" stackId="a" radius={[0, 0, 0, 0]}>
                  {stats.diffData.map(entry => (
                    <Cell key={entry.name} fill={(DIFF_COLORS as any)[entry.name]} />
                  ))}
                </Bar>
                <Bar dataKey="remaining" name="Remaining" stackId="a" fill="#21262d" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
            <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
              {stats.diffData.map(d => (
                <div key={d.name} style={{ flex: 1, textAlign: 'center' }}>
                  <div style={{ fontSize: 16, fontWeight: 700, color: (DIFF_COLORS as any)[d.name] }}>
                    {d.solved}/{d.total}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{d.name}</div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Status pie */}
        {card(
          <>
            {sectionTitle(<Layers size={14} />, 'Status Distribution')}
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <ResponsiveContainer width={140} height={140}>
                <PieChart>
                  <Pie
                    data={stats.statusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={42}
                    outerRadius={62}
                    paddingAngle={2}
                    dataKey="value"
                    strokeWidth={0}
                  >
                    {stats.statusData.map(entry => (
                      <Cell key={entry.name} fill={STATUS_COLORS[entry.name] || '#30363d'} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ flex: 1 }}>
                {stats.statusData.map(d => (
                  <div key={d.name} style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 7,
                    marginBottom: 6,
                  }}>
                    <div style={{
                      width: 8, height: 8, borderRadius: 2,
                      background: STATUS_COLORS[d.name] || '#30363d',
                      flexShrink: 0,
                    }} />
                    <span style={{ fontSize: 11, color: 'var(--text-secondary)', flex: 1 }}>{d.name}</span>
                    <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-primary)' }}>{d.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      {/* 2-col row: radar + roadmap */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Topic radar */}
        {card(
          <>
            {sectionTitle(<Target size={14} />, 'Topic Mastery (%)')}
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={stats.radarData} margin={{ top: 10, right: 20, bottom: 10, left: 20 }}>
                <PolarGrid stroke="#21262d" />
                <PolarAngleAxis
                  dataKey="topic"
                  tick={{ fontSize: 10, fill: '#8b949e' }}
                />
                <Radar
                  name="Mastery"
                  dataKey="value"
                  stroke="#bc8cff"
                  fill="#bc8cff"
                  fillOpacity={0.2}
                  strokeWidth={2}
                />
                <Tooltip content={<CustomTooltip />} formatter={(v: any) => [`${v}%`, 'Mastery']} />
              </RadarChart>
            </ResponsiveContainer>
          </>
        )}

        {/* Roadmap progress */}
        {card(
          <>
            {sectionTitle(<Award size={14} />, 'Roadmap Progress')}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16, paddingTop: 8 }}>
              {stats.roadmapData.map(rm => (
                <div key={rm.name}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                    <span style={{ fontSize: 13, color: 'var(--text-primary)', fontWeight: 500 }}>{rm.name}</span>
                    <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                      {rm.solved}/{rm.total}
                      <span style={{ color: 'var(--text-muted)', marginLeft: 4 }}>({rm.pct}%)</span>
                    </span>
                  </div>
                  <div style={{
                    height: 8, borderRadius: 4,
                    background: 'var(--bg-tertiary)',
                    overflow: 'hidden',
                  }}>
                    <div style={{
                      width: `${rm.pct}%`,
                      height: '100%',
                      background: rm.pct >= 80 ? 'var(--color-success)'
                        : rm.pct >= 40 ? 'var(--color-accent)'
                          : 'var(--color-purple)',
                      borderRadius: 4,
                      transition: 'width 0.6s ease',
                    }} />
                  </div>
                </div>
              ))}

              {/* mini legend */}
              <div style={{
                marginTop: 8,
                paddingTop: 14,
                borderTop: '1px solid var(--border-subtle)',
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: 8,
              }}>
                {[
                  { label: 'Starting', range: '0–40%', color: 'var(--color-purple)' },
                  { label: 'Progress', range: '40–80%', color: 'var(--color-accent)' },
                  { label: 'Mastery', range: '80%+', color: 'var(--color-success)' },
                ].map(l => (
                  <div key={l.label} style={{ textAlign: 'center' }}>
                    <div style={{ width: 24, height: 4, borderRadius: 2, background: l.color, margin: '0 auto 4px' }} />
                    <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{l.label}</div>
                    <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{l.range}</div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
