import React, { useState } from 'react';
import { Zap, Github, Eye, EyeOff, ExternalLink, ArrowRight, Check } from 'lucide-react';
import { GitHubService } from '@/services/github';
import { useApp } from '@/lib/AppContext';
import { GitHubAuth } from '@/types';

type Step = 'token' | 'repo';

export default function AuthPage() {
  const { setAuth } = useApp();
  const [step, setStep] = useState<Step>('token');
  const [token, setToken] = useState('');
  const [repoName, setRepoName] = useState('algovault-data');
  const [showToken, setShowToken] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [verifiedUser, setVerifiedUser] = useState<{ login: string; avatar_url: string; name: string } | null>(null);

  async function handleVerifyToken() {
    if (!token.trim()) return;
    setLoading(true);
    setError('');
    try {
      const svc = new GitHubService(token, '', '');
      const user = await svc.verifyToken();
      setVerifiedUser(user);
      setStep('repo');
    } catch {
      setError('Invalid token. Make sure it has "repo" scope enabled.');
    } finally {
      setLoading(false);
    }
  }

  async function handleConnect() {
    if (!verifiedUser || !repoName.trim()) return;
    setLoading(true);
    setError('');
    try {
      const svc = new GitHubService(token, verifiedUser.login, repoName.trim());
      await svc.ensureRepo();

      const auth: GitHubAuth = {
        token,
        user: {
          login: verifiedUser.login,
          name: verifiedUser.name || verifiedUser.login,
          avatar_url: verifiedUser.avatar_url,
          public_repos: 0,
        },
        repoName: repoName.trim(),
        repoCreated: true,
      };
      setAuth(auth);
    } catch (e) {
      setError((e as Error).message || 'Failed to set up repository');
    } finally {
      setLoading(false);
    }
  }

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '10px 14px',
    background: 'var(--bg-tertiary)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-md)',
    color: 'var(--text-primary)',
    fontSize: '14px',
    fontFamily: 'var(--font-mono)',
  };

  const btnStyle: React.CSSProperties = {
    width: '100%',
    padding: '11px',
    borderRadius: 'var(--radius-md)',
    border: 'none',
    background: 'var(--color-accent)',
    color: 'var(--bg-primary)',
    fontSize: '14px',
    fontWeight: 600,
    cursor: loading ? 'not-allowed' : 'pointer',
    opacity: loading ? 0.7 : 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--bg-primary)',
        padding: '24px',
      }}
    >
      {/* Background grid */}
      <div
        style={{
          position: 'fixed',
          inset: 0,
          backgroundImage:
            'radial-gradient(circle at 25% 25%, rgba(88, 166, 255, 0.05) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(188, 140, 255, 0.05) 0%, transparent 50%)',
          pointerEvents: 'none',
        }}
      />

      <div style={{ width: '100%', maxWidth: '440px', position: 'relative', zIndex: 1 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <div
            style={{
              width: '48px',
              height: '48px',
              borderRadius: '12px',
              background: 'linear-gradient(135deg, var(--color-accent), var(--color-purple))',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 16px',
              boxShadow: '0 8px 24px rgba(88, 166, 255, 0.3)',
            }}
          >
            <Zap size={24} color="#fff" />
          </div>
          <h1
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: '28px',
              fontWeight: 400,
              color: 'var(--text-primary)',
              letterSpacing: '-0.5px',
              marginBottom: '6px',
            }}
          >
            AlgoVault
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>
            Your personal interview preparation workspace
          </p>
        </div>

        {/* Card */}
        <div
          className="animate-in"
          style={{
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius-xl)',
            padding: '28px',
          }}
        >
          {/* Steps indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '24px' }}>
            {(['token', 'repo'] as Step[]).map((s, i) => (
              <React.Fragment key={s}>
                <div
                  style={{
                    width: '24px',
                    height: '24px',
                    borderRadius: '50%',
                    background:
                      step === s
                        ? 'var(--color-accent)'
                        : s === 'token' && step === 'repo'
                        ? 'var(--color-success)'
                        : 'var(--bg-tertiary)',
                    border: `1px solid ${step === s ? 'var(--color-accent)' : 'var(--border)'}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '11px',
                    fontWeight: 600,
                    color:
                      step === s
                        ? 'var(--bg-primary)'
                        : s === 'token' && step === 'repo'
                        ? 'var(--bg-primary)'
                        : 'var(--text-muted)',
                    transition: 'all 300ms var(--ease-out)',
                    flexShrink: 0,
                  }}
                >
                  {s === 'token' && step === 'repo' ? <Check size={12} /> : i + 1}
                </div>
                <span
                  style={{
                    fontSize: '12px',
                    color: step === s ? 'var(--text-primary)' : 'var(--text-muted)',
                    fontWeight: step === s ? 500 : 400,
                  }}
                >
                  {s === 'token' ? 'Connect GitHub' : 'Choose Repository'}
                </span>
                {i === 0 && (
                  <div
                    style={{ flex: 1, height: '1px', background: 'var(--border)', margin: '0 4px' }}
                  />
                )}
              </React.Fragment>
            ))}
          </div>

          {step === 'token' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }} className="animate-in">
              <div>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: '8px',
                  }}
                >
                  <label style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-primary)' }}>
                    GitHub Personal Access Token
                  </label>
                  <a
                    href="https://github.com/settings/tokens/new?scopes=repo&description=AlgoVault"
                    target="_blank"
                    rel="noreferrer"
                    style={{ fontSize: '12px', color: 'var(--color-accent)', display: 'flex', alignItems: 'center', gap: '4px' }}
                  >
                    Create token <ExternalLink size={10} />
                  </a>
                </div>
                <div style={{ position: 'relative' }}>
                  <input
                    type={showToken ? 'text' : 'password'}
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleVerifyToken()}
                    placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                    style={{ ...inputStyle, paddingRight: '44px' }}
                  />
                  <button
                    onClick={() => setShowToken(!showToken)}
                    style={{
                      position: 'absolute',
                      right: '12px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      background: 'none',
                      border: 'none',
                      color: 'var(--text-muted)',
                      padding: 0,
                    }}
                  >
                    {showToken ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>

              <div
                style={{
                  background: 'var(--bg-tertiary)',
                  borderRadius: 'var(--radius-md)',
                  padding: '12px',
                  fontSize: '12px',
                  color: 'var(--text-secondary)',
                  lineHeight: 1.6,
                }}
              >
                <strong style={{ color: 'var(--text-primary)' }}>How it works:</strong> Your token is stored only in your browser's localStorage. Your progress data is saved in a private GitHub repo under your own account — completely free, no servers involved.
                <br />
                <br />
                Required scope: <code style={{ color: 'var(--color-accent)' }}>repo</code>
              </div>

              {error && (
                <div
                  style={{
                    background: 'var(--color-danger-muted)',
                    border: '1px solid var(--color-danger)',
                    borderRadius: 'var(--radius-md)',
                    padding: '10px 14px',
                    color: 'var(--color-danger)',
                    fontSize: '13px',
                  }}
                >
                  {error}
                </div>
              )}

              <button onClick={handleVerifyToken} disabled={loading || !token.trim()} style={btnStyle}>
                <Github size={16} />
                {loading ? 'Verifying...' : 'Verify Token'}
                {!loading && <ArrowRight size={16} />}
              </button>
            </div>
          )}

          {step === 'repo' && verifiedUser && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }} className="animate-in">
              {/* User verified */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px',
                  background: 'var(--color-success-muted)',
                  borderRadius: 'var(--radius-md)',
                  border: '1px solid rgba(63, 185, 80, 0.2)',
                }}
              >
                <img
                  src={verifiedUser.avatar_url}
                  alt="avatar"
                  style={{ width: '36px', height: '36px', borderRadius: '50%' }}
                />
                <div>
                  <div style={{ fontSize: '13px', fontWeight: 500, color: 'var(--color-success)' }}>
                    Connected as @{verifiedUser.login}
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                    GitHub account verified
                  </div>
                </div>
                <Check size={16} color="var(--color-success)" style={{ marginLeft: 'auto' }} />
              </div>

              <div>
                <label
                  style={{
                    display: 'block',
                    fontSize: '13px',
                    fontWeight: 500,
                    color: 'var(--text-primary)',
                    marginBottom: '8px',
                  }}
                >
                  Repository Name
                </label>
                <input
                  type="text"
                  value={repoName}
                  onChange={(e) => setRepoName(e.target.value.replace(/[^a-zA-Z0-9_.-]/g, '-'))}
                  placeholder="algovault-data"
                  style={inputStyle}
                />
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '6px' }}>
                  A private repo <code style={{ color: 'var(--color-accent)' }}>{verifiedUser.login}/{repoName || 'algovault-data'}</code> will be created automatically.
                </p>
              </div>

              {error && (
                <div
                  style={{
                    background: 'var(--color-danger-muted)',
                    border: '1px solid var(--color-danger)',
                    borderRadius: 'var(--radius-md)',
                    padding: '10px 14px',
                    color: 'var(--color-danger)',
                    fontSize: '13px',
                  }}
                >
                  {error}
                </div>
              )}

              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  onClick={() => { setStep('token'); setError(''); }}
                  style={{
                    padding: '10px 16px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border)',
                    background: 'transparent',
                    color: 'var(--text-secondary)',
                    fontSize: '14px',
                  }}
                >
                  Back
                </button>
                <button
                  onClick={handleConnect}
                  disabled={loading || !repoName.trim()}
                  style={{ ...btnStyle, flex: 1, width: 'auto' }}
                >
                  {loading ? 'Setting up...' : 'Launch AlgoVault'}
                  {!loading && <Zap size={16} />}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Feature pills */}
        <div
          style={{
            display: 'flex',
            gap: '8px',
            justifyContent: 'center',
            flexWrap: 'wrap',
            marginTop: '24px',
          }}
        >
          {['305 Problems', 'Monaco Editor', 'Spaced Repetition', 'GitHub Sync', '100% Free'].map(
            (f) => (
              <span
                key={f}
                style={{
                  padding: '4px 12px',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-full)',
                  fontSize: '12px',
                  color: 'var(--text-muted)',
                }}
              >
                {f}
              </span>
            )
          )}
        </div>
      </div>
    </div>
  );
}
