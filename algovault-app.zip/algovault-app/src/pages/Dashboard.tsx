import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Flame,
  CheckCircle2,
  Trophy,
  Clock,
  TrendingUp,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '@/lib/AppContext';
import { ALL_PROBLEMS, ROADMAP_DATA } from '@/data/problems';

function StatCard({
  label,
  value,
  sub,
  color,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  sub?: string;
  color: string;
  icon: React.ComponentType<{ size?: number; color?: string }>;
}) {
  return (
    <div
      className="card"
      style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', flex: '1 1 160px' }}
    >
      <div
        style={{
          width: '36px',
          height: '36px',
          borderRadius: 'var(--radius-md)',
          background: `${color}22`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        <Icon size={18} color={color} />
      </div>
      <div>
        <div
          style={{
            fontSize: '22px',
            fontWeight: 700,
            color: 'var(--text-primary)',
            fontFamily: 'var(--font-mono)',
            letterSpacing: '-1px',
            lineHeight: 1.1,
          }}
        >
          {value}
        </div>
        <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '2px' }}>{label}</div>
        {sub && <div style={{ fontSize: '11px', color, marginTop: '2px' }}>{sub}</div>}
      </div>
    </div>
  );
}

function ActivityHeatmap({ dailyActivity }: { dailyActivity: Record<string, number> }) {
  const weeks = useMemo(() => {
    const cells: { date: string; count: number }[] = [];
    const today = new Date();
    for (let i = 83; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const key = d.toISOString().split('T')[0];
      cells.push({ date: key, count: dailyActivity[key] || 0 });
    }
    // Group into weeks
    const weeks: { date: string; count: number }[][] = [];
    for (let i = 0; i < cells.length; i += 7) {
      weeks.push(cells.slice(i, i + 7));
    }
    return weeks;
  }, [dailyActivity]);

  const maxCount = Math.max(...Object.values(dailyActivity), 1);

  return (
    <div>
      <div
        style={{
          display: 'flex',
          gap: '3px',
        }}
      >
        {weeks.map((week, wi) => (
          <div key={wi} style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
            {week.map((cell) => {
              const intensity = cell.count / maxCount;
              const bg =
                cell.count === 0
                  ? 'var(--bg-tertiary)'
                  : intensity < 0.25
                  ? 'rgba(88, 166, 255, 0.2)'
                  : intensity < 0.5
                  ? 'rgba(88, 166, 255, 0.4)'
                  : intensity < 0.75
                  ? 'rgba(88, 166, 255, 0.65)'
                  : 'var(--color-accent)';
              return (
                <div
                  key={cell.date}
                  title={`${cell.date}: ${cell.count} solved`}
                  style={{
                    width: '12px',
                    height: '12px',
                    borderRadius: '2px',
                    background: bg,
                    cursor: 'default',
                  }}
                />
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { userData } = useApp();
  const navigate = useNavigate();

  const progress = userData?.progress || {};

  const stats = useMemo(() => {
    const all = Object.values(progress);
    const solved = all.filter((p) => p.status === 'Solved' || p.status === 'Mastered').length;
    const mastered = all.filter((p) => p.status === 'Mastered').length;
    const learning = all.filter((p) => p.status === 'Learning').length;
    const needsRevision = all.filter((p) => {
      if (!p.nextRevision) return false;
      return new Date(p.nextRevision) <= new Date();
    }).length;

    const easy = ALL_PROBLEMS.filter((p) => p.difficulty === 'Easy').length;
    const medium = ALL_PROBLEMS.filter((p) => p.difficulty === 'Medium').length;
    const hard = ALL_PROBLEMS.filter((p) => p.difficulty === 'Hard').length;

    const easySolved = all.filter((pr) => {
      const prob = ALL_PROBLEMS.find((p) => p.id === pr.problemId);
      return prob?.difficulty === 'Easy' && (pr.status === 'Solved' || pr.status === 'Mastered');
    }).length;
    const mediumSolved = all.filter((pr) => {
      const prob = ALL_PROBLEMS.find((p) => p.id === pr.problemId);
      return prob?.difficulty === 'Medium' && (pr.status === 'Solved' || pr.status === 'Mastered');
    }).length;
    const hardSolved = all.filter((pr) => {
      const prob = ALL_PROBLEMS.find((p) => p.id === pr.problemId);
      return prob?.difficulty === 'Hard' && (pr.status === 'Solved' || pr.status === 'Mastered');
    }).length;

    return { solved, mastered, learning, needsRevision, easy, medium, hard, easySolved, mediumSolved, hardSolved };
  }, [progress]);

  const recentlySolved = useMemo(() => {
    return Object.values(progress)
      .filter((p) => p.lastSolved)
      .sort((a, b) => new Date(b.lastSolved!).getTime() - new Date(a.lastSolved!).getTime())
      .slice(0, 5)
      .map((p) => ({
        ...p,
        problem: ALL_PROBLEMS.find((pr) => pr.id === p.problemId),
      }));
  }, [progress]);

  const roadmapProgress = useMemo(() => {
    return Object.entries(ROADMAP_DATA).map(([name, problems]) => {
      const solved = problems.filter((p) => {
        const pr = progress[p.id];
        return pr?.status === 'Solved' || pr?.status === 'Mastered';
      }).length;
      return { name, total: problems.length, solved };
    });
  }, [progress]);

  const TOTAL = 305;

  return (
    <div style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Welcome */}
      <div style={{ marginBottom: '24px' }}>
        <h1
          style={{
            fontFamily: 'var(--font-serif)',
            fontSize: '26px',
            fontWeight: 400,
            color: 'var(--text-primary)',
            letterSpacing: '-0.5px',
            marginBottom: '4px',
          }}
        >
          Good {getTimeOfDay()}, ready to grind?
        </h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>
          {stats.solved === 0
            ? "You haven't solved any problems yet. Start with the Problems page."
            : `You've solved ${stats.solved} of ${TOTAL} problems. Keep going!`}
        </p>
      </div>

      {/* Stats */}
      <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '24px' }}>
        <StatCard
          label="Problems Solved"
          value={stats.solved}
          sub={`of ${TOTAL} total`}
          color="var(--color-accent)"
          icon={CheckCircle2}
        />
        <StatCard
          label="Mastered"
          value={stats.mastered}
          sub="spaced repetition complete"
          color="var(--color-purple)"
          icon={Trophy}
        />
        <StatCard
          label="Day Streak"
          value={userData?.streak || 0}
          sub={userData?.streak ? 'Keep it up!' : 'Start today'}
          color="var(--color-warning)"
          icon={Flame}
        />
        <StatCard
          label="Due for Revision"
          value={stats.needsRevision}
          sub={stats.needsRevision > 0 ? 'Click to review' : 'All caught up!'}
          color="var(--color-danger)"
          icon={RefreshCw}
        />
        <StatCard
          label="In Progress"
          value={stats.learning}
          sub="learning phase"
          color="var(--color-success)"
          icon={TrendingUp}
        />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: '16px', marginBottom: '16px' }}>
        {/* Activity heatmap */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <h2 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-primary)' }}>
              Activity (last 12 weeks)
            </h2>
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
              {Object.values(userData?.dailyActivity || {}).reduce((a, b) => a + b, 0)} total
            </span>
          </div>
          <ActivityHeatmap dailyActivity={userData?.dailyActivity || {}} />
        </div>

        {/* Difficulty breakdown */}
        <div className="card">
          <h2 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '16px' }}>
            Difficulty Breakdown
          </h2>
          {[
            { label: 'Easy', solved: stats.easySolved, total: stats.easy, color: 'var(--color-easy)' },
            { label: 'Medium', solved: stats.mediumSolved, total: stats.medium, color: 'var(--color-medium)' },
            { label: 'Hard', solved: stats.hardSolved, total: stats.hard, color: 'var(--color-hard)' },
          ].map(({ label, solved, total, color }) => (
            <div key={label} style={{ marginBottom: '14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                <span style={{ fontSize: '13px', color }}>{label}</span>
                <span style={{ fontSize: '12px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                  {solved}/{total}
                </span>
              </div>
              <div style={{ height: '5px', background: 'var(--bg-tertiary)', borderRadius: '3px', overflow: 'hidden' }}>
                <div
                  style={{
                    height: '100%',
                    width: `${(solved / total) * 100}%`,
                    background: color,
                    borderRadius: '3px',
                    transition: 'width 600ms var(--ease-out)',
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
        {/* Roadmap progress */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <h2 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-primary)' }}>
              Roadmap Progress
            </h2>
            <button
              onClick={() => navigate('/problems')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                background: 'none',
                border: 'none',
                color: 'var(--color-accent)',
                fontSize: '12px',
              }}
            >
              View all <ArrowRight size={12} />
            </button>
          </div>
          {roadmapProgress.map(({ name, total, solved }) => (
            <div key={name} style={{ marginBottom: '14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>{name}</span>
                <span style={{ fontSize: '12px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                  {solved}/{total}
                </span>
              </div>
              <div style={{ height: '5px', background: 'var(--bg-tertiary)', borderRadius: '3px', overflow: 'hidden' }}>
                <div
                  style={{
                    height: '100%',
                    width: `${(solved / total) * 100}%`,
                    background: 'linear-gradient(90deg, var(--color-accent), var(--color-purple))',
                    borderRadius: '3px',
                    transition: 'width 600ms var(--ease-out)',
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Recently solved */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <h2 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-primary)' }}>
              Recently Solved
            </h2>
            <Clock size={14} color="var(--text-muted)" />
          </div>
          {recentlySolved.length === 0 ? (
            <p style={{ color: 'var(--text-muted)', fontSize: '13px', textAlign: 'center', padding: '20px 0' }}>
              No problems solved yet
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {recentlySolved.map(({ problem, status, lastSolved }) => (
                <div
                  key={problem?.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    padding: '8px 0',
                    borderBottom: '1px solid var(--border-muted)',
                  }}
                >
                  <span
                    style={{
                      fontSize: '10px',
                      padding: '2px 6px',
                      borderRadius: 'var(--radius-sm)',
                      fontFamily: 'var(--font-mono)',
                      flexShrink: 0,
                    }}
                    className={`badge-${problem?.difficulty.toLowerCase()}`}
                  >
                    {problem?.difficulty[0]}
                  </span>
                  <span style={{ flex: 1, fontSize: '13px', color: 'var(--text-primary)' }} className="truncate">
                    {problem?.title}
                  </span>
                  <span style={{ fontSize: '11px', color: 'var(--text-muted)', flexShrink: 0 }}>
                    {lastSolved ? formatRelative(lastSolved) : ''}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function getTimeOfDay() {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
}

function formatRelative(isoStr: string) {
  const diff = Date.now() - new Date(isoStr).getTime();
  const hours = Math.floor(diff / 3600000);
  if (hours < 1) return 'just now';
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
