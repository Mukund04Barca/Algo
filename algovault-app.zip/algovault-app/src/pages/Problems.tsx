import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Search,
  Filter,
  ExternalLink,
  Star,
  ChevronDown,
  X,
  Save,
  Clock,
  Code2,
  StickyNote,
  Lightbulb,
} from 'lucide-react';
import Editor from '@monaco-editor/react';
import { useApp } from '@/lib/AppContext';
import { ALL_PROBLEMS, ROADMAP_DATA } from '@/data/problems';
import { Problem, Status, Difficulty, Language, ProblemProgress } from '@/types';

const STATUSES: Status[] = ['Not Started', 'Learning', 'Solved', 'Needs Revision', 'Mastered'];
const DIFFICULTIES: Difficulty[] = ['Easy', 'Medium', 'Hard'];
const LANGUAGES: Language[] = ['python', 'java', 'cpp', 'javascript'];
const LANG_LABELS: Record<Language, string> = {
  python: 'Python',
  java: 'Java',
  cpp: 'C++',
  javascript: 'JavaScript',
};
const LANG_MONACO: Record<Language, string> = {
  python: 'python',
  java: 'java',
  cpp: 'cpp',
  javascript: 'javascript',
};
const LANG_STARTERS: Record<Language, string> = {
  python: '# Write your Python solution here\n\ndef solution():\n    pass\n',
  java: '// Write your Java solution here\n\nclass Solution {\n    public void solve() {\n        // your code\n    }\n}\n',
  cpp: '// Write your C++ solution here\n\n#include <bits/stdc++.h>\nusing namespace std;\n\nvoid solution() {\n    // your code\n}\n',
  javascript: '// Write your JavaScript solution here\n\nfunction solution() {\n    // your code\n}\n',
};

const STATUS_BADGE: Record<Status, string> = {
  'Not Started': 'status-not-started',
  Learning: 'status-learning',
  Solved: 'status-solved',
  'Needs Revision': 'status-needs-revision',
  Mastered: 'status-mastered',
};

type ModalTab = 'solution' | 'notes' | 'approach' | 'complexity';

function ConfidenceDots({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div style={{ display: 'flex', gap: '4px' }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          onClick={() => onChange(i)}
          style={{
            width: '14px',
            height: '14px',
            borderRadius: '50%',
            border: 'none',
            background: i <= value ? 'var(--color-accent)' : 'var(--bg-tertiary)',
            cursor: 'pointer',
            padding: 0,
            transition: 'background 160ms',
          }}
        />
      ))}
    </div>
  );
}

function ProblemModal({
  problem,
  onClose,
}: {
  problem: Problem;
  onClose: () => void;
}) {
  const { getProgress, saveProgress } = useApp();
  const [progress, setProgress] = useState<ProblemProgress>(() => getProgress(problem.id));
  const [activeTab, setActiveTab] = useState<ModalTab>('solution');
  const [activeLang, setActiveLang] = useState<Language>('python');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const currentSolution = progress.solutions.find((s) => s.language === activeLang);

  function updateSolution(field: string, value: string) {
    setProgress((prev) => {
      const solutions = [...prev.solutions];
      const idx = solutions.findIndex((s) => s.language === activeLang);
      if (idx >= 0) {
        solutions[idx] = { ...solutions[idx], [field]: value };
      } else {
        solutions.push({
          language: activeLang,
          code: field === 'code' ? value : LANG_STARTERS[activeLang],
          timeComplexity: field === 'timeComplexity' ? value : '',
          spaceComplexity: field === 'spaceComplexity' ? value : '',
          approach: field === 'approach' ? value : '',
        });
      }
      return { ...prev, solutions };
    });
  }

  async function handleSave() {
    setSaving(true);
    await saveProgress(progress);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const tabs: { key: ModalTab; label: string; icon: React.ComponentType<{ size?: number }> }[] = [
    { key: 'solution', label: 'Solution', icon: Code2 },
    { key: 'notes', label: 'Notes', icon: StickyNote },
    { key: 'approach', label: 'Approach', icon: Lightbulb },
    { key: 'complexity', label: 'Complexity', icon: Clock },
  ];

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.7)',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
      }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="animate-in"
        style={{
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius-xl)',
          width: '100%',
          maxWidth: '860px',
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border)',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '12px',
          }}
        >
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
              <span
                style={{ fontSize: '11px', padding: '2px 8px', borderRadius: 'var(--radius-sm)', fontFamily: 'var(--font-mono)' }}
                className={`badge-${problem.difficulty.toLowerCase()}`}
              >
                {problem.difficulty}
              </span>
              <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{problem.topic}</span>
              <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>•</span>
              <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{problem.platform}</span>
              {problem.link && (
                <a href={problem.link} target="_blank" rel="noreferrer" style={{ color: 'var(--color-accent)', display: 'flex', alignItems: 'center', gap: '3px', fontSize: '12px' }}>
                  Open <ExternalLink size={10} />
                </a>
              )}
            </div>
            <h2 style={{ fontSize: '17px', fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.3px' }}>
              {problem.title}
            </h2>
            <div style={{ display: 'flex', gap: '4px', marginTop: '6px', flexWrap: 'wrap' }}>
              {problem.tags.map((t) => (
                <span key={t} style={{ fontSize: '11px', padding: '2px 7px', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', color: 'var(--text-muted)' }}>
                  {t}
                </span>
              ))}
            </div>
          </div>
          <button
            onClick={onClose}
            style={{ background: 'none', border: 'none', color: 'var(--text-muted)', padding: '2px' }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Controls row */}
        <div
          style={{
            padding: '12px 20px',
            borderBottom: '1px solid var(--border)',
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
            flexWrap: 'wrap',
          }}
        >
          {/* Status */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <label style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Status</label>
            <select
              value={progress.status}
              onChange={(e) => setProgress((p) => ({ ...p, status: e.target.value as Status }))}
              style={{ padding: '4px 8px', fontSize: '12px', borderRadius: 'var(--radius-sm)' }}
            >
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>

          {/* Confidence */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <label style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Confidence</label>
            <ConfidenceDots value={progress.confidence} onChange={(v) => setProgress((p) => ({ ...p, confidence: v }))} />
          </div>

          {/* Time */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Clock size={13} color="var(--text-muted)" />
            <input
              type="number"
              value={progress.timeTaken || ''}
              onChange={(e) => setProgress((p) => ({ ...p, timeTaken: Number(e.target.value) }))}
              placeholder="min"
              style={{ width: '60px', padding: '4px 8px', fontSize: '12px', borderRadius: 'var(--radius-sm)' }}
            />
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>min</span>
          </div>

          {/* Favorite */}
          <button
            onClick={() => setProgress((p) => ({ ...p, favorite: !p.favorite }))}
            style={{
              background: 'none',
              border: 'none',
              color: progress.favorite ? 'var(--color-warning)' : 'var(--text-muted)',
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              fontSize: '12px',
            }}
          >
            <Star size={14} fill={progress.favorite ? 'var(--color-warning)' : 'none'} />
            Favorite
          </button>

          <div style={{ flex: 1 }} />

          <button
            onClick={handleSave}
            disabled={saving}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 14px',
              background: saved ? 'var(--color-success)' : 'var(--color-accent)',
              border: 'none',
              borderRadius: 'var(--radius-md)',
              color: 'var(--bg-primary)',
              fontSize: '13px',
              fontWeight: 600,
              cursor: saving ? 'wait' : 'pointer',
              transition: 'background 300ms',
            }}
          >
            <Save size={13} />
            {saving ? 'Saving...' : saved ? 'Saved!' : 'Save to GitHub'}
          </button>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', padding: '0 20px' }}>
          {tabs.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '10px 14px',
                background: 'none',
                border: 'none',
                borderBottom: `2px solid ${activeTab === key ? 'var(--color-accent)' : 'transparent'}`,
                color: activeTab === key ? 'var(--color-accent)' : 'var(--text-muted)',
                fontSize: '13px',
                fontWeight: activeTab === key ? 500 : 400,
                marginBottom: '-1px',
              }}
            >
              <Icon size={13} />
              {label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div style={{ flex: 1, overflow: 'auto', minHeight: 0 }}>
          {activeTab === 'solution' && (
            <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
              {/* Language tabs */}
              <div style={{ display: 'flex', gap: '4px', padding: '10px 20px', borderBottom: '1px solid var(--border-muted)' }}>
                {LANGUAGES.map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setActiveLang(lang)}
                    style={{
                      padding: '4px 12px',
                      borderRadius: 'var(--radius-sm)',
                      border: '1px solid var(--border)',
                      background: activeLang === lang ? 'var(--color-accent-muted)' : 'transparent',
                      color: activeLang === lang ? 'var(--color-accent)' : 'var(--text-muted)',
                      fontSize: '12px',
                      fontFamily: 'var(--font-mono)',
                    }}
                  >
                    {LANG_LABELS[lang]}
                  </button>
                ))}
              </div>
              <div style={{ flex: 1, minHeight: '320px' }}>
                <Editor
                  height="100%"
                  language={LANG_MONACO[activeLang]}
                  value={currentSolution?.code || LANG_STARTERS[activeLang]}
                  onChange={(val) => updateSolution('code', val || '')}
                  theme="vs-dark"
                  options={{
                    fontSize: 13,
                    fontFamily: 'DM Mono, Fira Code, monospace',
                    minimap: { enabled: false },
                    lineNumbers: 'on',
                    scrollBeyondLastLine: false,
                    wordWrap: 'on',
                    padding: { top: 12, bottom: 12 },
                    renderLineHighlight: 'line',
                    cursorStyle: 'line',
                    automaticLayout: true,
                  }}
                />
              </div>
            </div>
          )}

          {activeTab === 'notes' && (
            <div style={{ padding: '16px 20px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '8px' }}>
                Notes & observations
              </label>
              <textarea
                value={progress.notes}
                onChange={(e) => setProgress((p) => ({ ...p, notes: e.target.value }))}
                placeholder="Write your notes, key observations, or things to remember..."
                style={{
                  width: '100%',
                  minHeight: '220px',
                  padding: '12px',
                  background: 'var(--bg-tertiary)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-md)',
                  color: 'var(--text-primary)',
                  fontSize: '13px',
                  lineHeight: 1.7,
                  resize: 'vertical',
                }}
              />
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--text-secondary)', margin: '16px 0 8px' }}>
                Common mistakes to avoid
              </label>
              <textarea
                value={progress.mistakes}
                onChange={(e) => setProgress((p) => ({ ...p, mistakes: e.target.value }))}
                placeholder="Edge cases, bugs, pitfalls..."
                style={{
                  width: '100%',
                  minHeight: '100px',
                  padding: '12px',
                  background: 'var(--bg-tertiary)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-md)',
                  color: 'var(--text-primary)',
                  fontSize: '13px',
                  lineHeight: 1.7,
                  resize: 'vertical',
                }}
              />
            </div>
          )}

          {activeTab === 'approach' && (
            <div style={{ padding: '16px 20px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '8px' }}>
                Your approach & algorithm
              </label>
              <textarea
                value={currentSolution?.approach || ''}
                onChange={(e) => updateSolution('approach', e.target.value)}
                placeholder="Describe your approach: brute force → optimized. What data structures? What's the key insight?..."
                style={{
                  width: '100%',
                  minHeight: '320px',
                  padding: '12px',
                  background: 'var(--bg-tertiary)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-md)',
                  color: 'var(--text-primary)',
                  fontSize: '13px',
                  lineHeight: 1.7,
                  resize: 'vertical',
                }}
              />
            </div>
          )}

          {activeTab === 'complexity' && (
            <div style={{ padding: '16px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '8px' }}>
                  Time Complexity
                </label>
                <input
                  type="text"
                  value={currentSolution?.timeComplexity || ''}
                  onChange={(e) => updateSolution('timeComplexity', e.target.value)}
                  placeholder="e.g. O(n log n)"
                  style={{ width: '100%', padding: '10px 12px', fontSize: '14px', fontFamily: 'var(--font-mono)' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '8px' }}>
                  Space Complexity
                </label>
                <input
                  type="text"
                  value={currentSolution?.spaceComplexity || ''}
                  onChange={(e) => updateSolution('spaceComplexity', e.target.value)}
                  placeholder="e.g. O(n)"
                  style={{ width: '100%', padding: '10px 12px', fontSize: '14px', fontFamily: 'var(--font-mono)' }}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Problems() {
  const { getProgress } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();

  const activeRoadmap = (searchParams.get('roadmap') || 'Striver A2Z') as keyof typeof ROADMAP_DATA;
  const openId = searchParams.get('id');

  const [search, setSearch] = useState('');
  const [diffFilter, setDiffFilter] = useState<Difficulty | 'All'>('All');
  const [statusFilter, setStatusFilter] = useState<Status | 'All'>('All');
  const [topicFilter, setTopicFilter] = useState('All');

  const problems = ROADMAP_DATA[activeRoadmap] || [];

  const topics = useMemo(() => {
    const set = new Set(problems.map((p) => p.topic));
    return ['All', ...Array.from(set)];
  }, [problems]);

  const filtered = useMemo(() => {
    return problems.filter((p) => {
      if (search && !p.title.toLowerCase().includes(search.toLowerCase()) && !p.topic.toLowerCase().includes(search.toLowerCase())) return false;
      if (diffFilter !== 'All' && p.difficulty !== diffFilter) return false;
      if (topicFilter !== 'All' && p.topic !== topicFilter) return false;
      if (statusFilter !== 'All') {
        const pr = getProgress(p.id);
        if (pr.status !== statusFilter) return false;
      }
      return true;
    });
  }, [problems, search, diffFilter, statusFilter, topicFilter, getProgress]);

  const openProblem = openId ? ALL_PROBLEMS.find((p) => p.id === openId) : null;

  function openModal(id: string) {
    setSearchParams((prev) => {
      prev.set('id', id);
      return prev;
    });
  }

  function closeModal() {
    setSearchParams((prev) => {
      prev.delete('id');
      return prev;
    });
  }

  const DIFF_COLORS: Record<string, string> = {
    Easy: 'var(--color-easy)',
    Medium: 'var(--color-medium)',
    Hard: 'var(--color-hard)',
  };

  return (
    <div style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Roadmap tabs */}
      <div style={{ display: 'flex', gap: '4px', marginBottom: '20px', borderBottom: '1px solid var(--border)', paddingBottom: '0' }}>
        {Object.keys(ROADMAP_DATA).map((rm) => (
          <button
            key={rm}
            onClick={() => setSearchParams({ roadmap: rm })}
            style={{
              padding: '8px 16px',
              background: 'none',
              border: 'none',
              borderBottom: `2px solid ${activeRoadmap === rm ? 'var(--color-accent)' : 'transparent'}`,
              color: activeRoadmap === rm ? 'var(--color-accent)' : 'var(--text-muted)',
              fontSize: '14px',
              fontWeight: activeRoadmap === rm ? 500 : 400,
              marginBottom: '-1px',
              cursor: 'pointer',
            }}
          >
            {rm}
            <span
              style={{
                marginLeft: '6px',
                fontSize: '11px',
                fontFamily: 'var(--font-mono)',
                color: 'var(--text-muted)',
              }}
            >
              {ROADMAP_DATA[rm as keyof typeof ROADMAP_DATA].length}
            </span>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '16px', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: '1', minWidth: '200px' }}>
          <Search size={13} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search problems..."
            style={{ width: '100%', paddingLeft: '32px', padding: '7px 10px 7px 32px' }}
          />
        </div>

        <select
          value={diffFilter}
          onChange={(e) => setDiffFilter(e.target.value as Difficulty | 'All')}
          style={{ padding: '7px 10px' }}
        >
          <option value="All">All Difficulty</option>
          {DIFFICULTIES.map((d) => <option key={d}>{d}</option>)}
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as Status | 'All')}
          style={{ padding: '7px 10px' }}
        >
          <option value="All">All Status</option>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>

        <select
          value={topicFilter}
          onChange={(e) => setTopicFilter(e.target.value)}
          style={{ padding: '7px 10px' }}
        >
          {topics.map((t) => <option key={t}>{t === 'All' ? 'All Topics' : t}</option>)}
        </select>

        {(search || diffFilter !== 'All' || statusFilter !== 'All' || topicFilter !== 'All') && (
          <button
            onClick={() => { setSearch(''); setDiffFilter('All'); setStatusFilter('All'); setTopicFilter('All'); }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              padding: '7px 12px',
              background: 'var(--bg-tertiary)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-md)',
              color: 'var(--text-muted)',
              fontSize: '12px',
            }}
          >
            <X size={12} /> Clear
          </button>
        )}

        <span style={{ alignSelf: 'center', fontSize: '12px', color: 'var(--text-muted)', marginLeft: 'auto' }}>
          {filtered.length} problems
        </span>
      </div>

      {/* Problems table */}
      <div
        style={{
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius-lg)',
          overflow: 'hidden',
        }}
      >
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              {['#', 'Problem', 'Difficulty', 'Topic', 'Status', 'Confidence', ''].map((h) => (
                <th
                  key={h}
                  style={{
                    padding: '10px 16px',
                    textAlign: 'left',
                    fontSize: '11px',
                    fontWeight: 600,
                    color: 'var(--text-muted)',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((p, i) => {
              const pr = getProgress(p.id);
              return (
                <tr
                  key={p.id}
                  onClick={() => openModal(p.id)}
                  style={{
                    borderBottom: '1px solid var(--border-muted)',
                    cursor: 'pointer',
                    transition: 'background 120ms',
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--bg-hover)')}
                  onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
                >
                  <td style={{ padding: '11px 16px', fontSize: '12px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', width: '48px' }}>
                    {(p.order || i + 1).toString().padStart(3, '0')}
                  </td>
                  <td style={{ padding: '11px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '13px', color: 'var(--text-primary)', fontWeight: 450 }}>
                        {p.title}
                      </span>
                      {pr.favorite && <Star size={12} fill="var(--color-warning)" color="var(--color-warning)" />}
                      {p.link && (
                        <a
                          href={p.link}
                          target="_blank"
                          rel="noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          style={{ color: 'var(--text-muted)', display: 'flex' }}
                        >
                          <ExternalLink size={11} />
                        </a>
                      )}
                    </div>
                    {p.companies.length > 0 && (
                      <div style={{ display: 'flex', gap: '4px', marginTop: '3px', flexWrap: 'wrap' }}>
                        {p.companies.slice(0, 3).map((c) => (
                          <span key={c} style={{ fontSize: '10px', color: 'var(--text-muted)' }}>{c}</span>
                        ))}
                      </div>
                    )}
                  </td>
                  <td style={{ padding: '11px 16px' }}>
                    <span
                      style={{
                        fontSize: '11px',
                        padding: '2px 8px',
                        borderRadius: 'var(--radius-sm)',
                        fontFamily: 'var(--font-mono)',
                        color: DIFF_COLORS[p.difficulty],
                        background: `${DIFF_COLORS[p.difficulty]}1a`,
                      }}
                    >
                      {p.difficulty}
                    </span>
                  </td>
                  <td style={{ padding: '11px 16px', fontSize: '12px', color: 'var(--text-secondary)' }}>
                    {p.topic}
                  </td>
                  <td style={{ padding: '11px 16px' }}>
                    <span
                      style={{ fontSize: '11px', padding: '2px 8px', borderRadius: 'var(--radius-sm)' }}
                      className={STATUS_BADGE[pr.status]}
                    >
                      {pr.status}
                    </span>
                  </td>
                  <td style={{ padding: '11px 16px' }}>
                    <div style={{ display: 'flex', gap: '3px' }}>
                      {[1, 2, 3, 4, 5].map((dot) => (
                        <div
                          key={dot}
                          style={{
                            width: '8px',
                            height: '8px',
                            borderRadius: '50%',
                            background: dot <= pr.confidence ? 'var(--color-accent)' : 'var(--bg-tertiary)',
                          }}
                        />
                      ))}
                    </div>
                  </td>
                  <td style={{ padding: '11px 16px' }}>
                    <ChevronDown size={14} color="var(--text-muted)" style={{ transform: 'rotate(-90deg)' }} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <div style={{ padding: '48px', textAlign: 'center', color: 'var(--text-muted)' }}>
            <Filter size={32} style={{ margin: '0 auto 12px', opacity: 0.5 }} />
            <p>No problems match your filters</p>
          </div>
        )}
      </div>

      {openProblem && <ProblemModal problem={openProblem} onClose={closeModal} />}
    </div>
  );
}
