import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, Clock, CheckCircle, AlertCircle, Flame, ChevronRight, Calendar, RotateCcw, Trophy, Zap } from 'lucide-react';
import { useApp } from '../lib/AppContext';
import { ALL_PROBLEMS } from '../data/problems';
import { Problem, ProblemProgress } from '../types';

interface RevisionItem {
  problem: Problem;
  progress: ProblemProgress;
  dueDate: Date;
  overdueDays: number;
  isOverdue: boolean;
  isDueToday: boolean;
}

const INTERVALS = [1, 3, 7, 15, 30, 60];

function getIntervalLabel(revCount: number): string {
  if (revCount === 0) return '1 day';
  if (revCount === 1) return '3 days';
  if (revCount === 2) return '1 week';
  if (revCount === 3) return '2 weeks';
  if (revCount === 4) return '1 month';
  return '2 months';
}

function getDifficultyColor(difficulty: string) {
  switch (difficulty) {
    case 'Easy': return 'var(--color-success)';
    case 'Medium': return 'var(--color-warning)';
    case 'Hard': return 'var(--color-danger)';
    default: return 'var(--text-secondary)';
  }
}

function ConfidenceDots({ value }: { value: number }) {
  return (
    <div style={{ display: 'flex', gap: 3 }}>
      {[1, 2, 3, 4, 5].map(i => (
        <div
          key={i}
          style={{
            width: 6,
            height: 6,
            borderRadius: '50%',
            background: i <= value
              ? value >= 4 ? 'var(--color-success)'
                : value >= 3 ? 'var(--color-warning)'
                : 'var(--color-danger)'
              : 'var(--bg-tertiary)',
            border: `1px solid ${i <= value ? 'transparent' : 'var(--border-subtle)'}`,
          }}
        />
      ))}
    </div>
  );
}

export default function Revision() {
  const { userData, saveProgress } = useApp();
  const navigate = useNavigate();
  const [completedToday, setCompletedToday] = useState<Set<string>>(new Set());
  const [selectedItem, setSelectedItem] = useState<RevisionItem | null>(null);

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);

  const revisionItems = useMemo<RevisionItem[]>(() => {
    if (!userData) return [];
    const items: RevisionItem[] = [];

    for (const problem of ALL_PROBLEMS) {
      const progress = userData.progress[problem.id];
      if (!progress?.nextRevision) continue;
      if (progress.status !== 'Solved' && progress.status !== 'Mastered') continue;

      const dueDate = new Date(progress.nextRevision);
      const dueDateStr = dueDate.toISOString().slice(0, 10);
      const isOverdue = dueDateStr < todayStr;
      const isDueToday = dueDateStr === todayStr;

      if (isOverdue || isDueToday) {
        const overdueDays = isOverdue
          ? Math.floor((now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24))
          : 0;
        items.push({ problem, progress, dueDate, overdueDays, isOverdue, isDueToday });
      }
    }

    // Sort: overdue first (most overdue first), then today's
    return items.sort((a, b) => b.overdueDays - a.overdueDays);
  }, [userData]);

  const upcomingItems = useMemo(() => {
    if (!userData) return [];
    const items: { problem: Problem; progress: ProblemProgress; dueDate: Date; daysUntil: number }[] = [];

    for (const problem of ALL_PROBLEMS) {
      const progress = userData.progress[problem.id];
      if (!progress?.nextRevision) continue;
      if (progress.status !== 'Solved' && progress.status !== 'Mastered') continue;

      const dueDate = new Date(progress.nextRevision);
      const dueDateStr = dueDate.toISOString().slice(0, 10);
      if (dueDateStr <= todayStr) continue;

      const daysUntil = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      if (daysUntil <= 7) {
        items.push({ problem, progress, dueDate, daysUntil });
      }
    }

    return items.sort((a, b) => a.daysUntil - b.daysUntil).slice(0, 10);
  }, [userData]);

  const handleMarkRevised = async (item: RevisionItem) => {
    if (!userData) return;
    const revCount = item.progress.revisionDates.length + 1;
    const intervalDays = INTERVALS[Math.min(revCount, INTERVALS.length - 1)];
    const nextRevDate = new Date();
    nextRevDate.setDate(nextRevDate.getDate() + intervalDays);

    const updated = {
      ...item.progress,
      revisionDates: [...item.progress.revisionDates, new Date().toISOString()],
      nextRevision: nextRevDate.toISOString(),
      status: revCount >= 5 ? 'Mastered' as const : item.progress.status,
    };

    await saveProgress(updated);
    setCompletedToday(prev => new Set([...prev, item.problem.id]));
    setSelectedItem(null);
  };

  const overdueCount = revisionItems.filter(i => i.isOverdue && !completedToday.has(i.problem.id)).length;
  const todayCount = revisionItems.filter(i => i.isDueToday && !completedToday.has(i.problem.id)).length;
  const pendingItems = revisionItems.filter(i => !completedToday.has(i.problem.id));

  return (
    <div style={{ padding: '24px 32px', maxWidth: 1000, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <Brain size={20} color="var(--color-purple)" />
          <h1 style={{ fontSize: 20, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
            Revision Queue
          </h1>
        </div>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, margin: 0 }}>
          Spaced repetition keeps solutions fresh. Review problems due today to maintain your streak.
        </p>
      </div>

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 28 }}>
        {[
          { label: 'Due Today', value: todayCount, icon: <Calendar size={15} />, color: 'var(--color-accent)' },
          { label: 'Overdue', value: overdueCount, icon: <AlertCircle size={15} />, color: 'var(--color-danger)' },
          { label: 'Done Today', value: completedToday.size, icon: <CheckCircle size={15} />, color: 'var(--color-success)' },
          { label: 'Up Next (7d)', value: upcomingItems.length, icon: <Clock size={15} />, color: 'var(--color-warning)' },
        ].map(stat => (
          <div key={stat.label} style={{
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-subtle)',
            borderRadius: 10,
            padding: '14px 16px',
            display: 'flex',
            alignItems: 'center',
            gap: 12,
          }}>
            <div style={{
              width: 34,
              height: 34,
              borderRadius: 8,
              background: `${stat.color}18`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: stat.color,
              flexShrink: 0,
            }}>
              {stat.icon}
            </div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', lineHeight: 1 }}>{stat.value}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 20, alignItems: 'start' }}>
        {/* Main queue */}
        <div>
          {pendingItems.length === 0 ? (
            <div style={{
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 12,
              padding: '48px 24px',
              textAlign: 'center',
            }}>
              <div style={{
                width: 56,
                height: 56,
                borderRadius: '50%',
                background: 'var(--color-success)18',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px',
              }}>
                <Trophy size={24} color="var(--color-success)" />
              </div>
              <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 6 }}>
                All caught up!
              </div>
              <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                No revisions due today. Come back tomorrow.
              </div>
              {upcomingItems.length > 0 && (
                <div style={{
                  marginTop: 16,
                  fontSize: 12,
                  color: 'var(--text-muted)',
                  padding: '8px 16px',
                  background: 'var(--bg-tertiary)',
                  borderRadius: 6,
                  display: 'inline-block',
                }}>
                  Next: {upcomingItems[0].problem.title} in {upcomingItems[0].daysUntil}d
                </div>
              )}
            </div>
          ) : (
            <div style={{
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 12,
              overflow: 'hidden',
            }}>
              <div style={{
                padding: '12px 16px',
                borderBottom: '1px solid var(--border-subtle)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  {pendingItems.length} Problem{pendingItems.length !== 1 ? 's' : ''} to Review
                </span>
                <div style={{ display: 'flex', gap: 8 }}>
                  {overdueCount > 0 && (
                    <span style={{
                      fontSize: 11,
                      padding: '2px 8px',
                      borderRadius: 4,
                      background: 'var(--color-danger)18',
                      color: 'var(--color-danger)',
                      border: '1px solid var(--color-danger)30',
                    }}>
                      {overdueCount} overdue
                    </span>
                  )}
                </div>
              </div>

              {pendingItems.map((item, idx) => (
                <div
                  key={item.problem.id}
                  onClick={() => setSelectedItem(selectedItem?.problem.id === item.problem.id ? null : item)}
                  style={{
                    padding: '14px 16px',
                    borderBottom: idx < pendingItems.length - 1 ? '1px solid var(--border-subtle)' : 'none',
                    cursor: 'pointer',
                    transition: 'background 150ms',
                    background: selectedItem?.problem.id === item.problem.id ? 'var(--bg-tertiary)' : 'transparent',
                  }}
                  onMouseEnter={e => {
                    if (selectedItem?.problem.id !== item.problem.id)
                      (e.currentTarget as HTMLElement).style.background = 'var(--bg-tertiary)';
                  }}
                  onMouseLeave={e => {
                    if (selectedItem?.problem.id !== item.problem.id)
                      (e.currentTarget as HTMLElement).style.background = 'transparent';
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    {/* Overdue badge */}
                    <div style={{
                      width: 8,
                      height: 8,
                      borderRadius: '50%',
                      background: item.isOverdue ? 'var(--color-danger)' : 'var(--color-accent)',
                      flexShrink: 0,
                    }} />

                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                        <span style={{
                          fontSize: 13,
                          fontWeight: 500,
                          color: 'var(--text-primary)',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}>
                          {item.problem.title}
                        </span>
                        <span style={{
                          fontSize: 11,
                          color: getDifficultyColor(item.problem.difficulty),
                          flexShrink: 0,
                        }}>
                          {item.problem.difficulty}
                        </span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{item.problem.topic}</span>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>·</span>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{item.problem.roadmap}</span>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>·</span>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                          Rev #{item.progress.revisionDates.length + 1} → {getIntervalLabel(item.progress.revisionDates.length + 1)}
                        </span>
                      </div>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
                      <ConfidenceDots value={item.progress.confidence} />
                      {item.isOverdue && (
                        <span style={{
                          fontSize: 11,
                          color: 'var(--color-danger)',
                          background: 'var(--color-danger)15',
                          padding: '2px 6px',
                          borderRadius: 4,
                        }}>
                          +{item.overdueDays}d
                        </span>
                      )}
                      <ChevronRight
                        size={14}
                        color="var(--text-muted)"
                        style={{
                          transform: selectedItem?.problem.id === item.problem.id ? 'rotate(90deg)' : 'none',
                          transition: 'transform 150ms',
                        }}
                      />
                    </div>
                  </div>

                  {/* Expanded actions */}
                  {selectedItem?.problem.id === item.problem.id && (
                    <div
                      style={{
                        marginTop: 12,
                        paddingTop: 12,
                        borderTop: '1px solid var(--border-subtle)',
                        display: 'flex',
                        gap: 8,
                      }}
                      onClick={e => e.stopPropagation()}
                    >
                      <button
                        onClick={() => navigate('/problems')}
                        style={{
                          flex: 1,
                          padding: '8px 12px',
                          borderRadius: 7,
                          background: 'var(--bg-primary)',
                          border: '1px solid var(--border-subtle)',
                          color: 'var(--text-secondary)',
                          fontSize: 12,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: 5,
                        }}
                      >
                        <RotateCcw size={12} />
                        Open Problem
                      </button>
                      <button
                        onClick={() => handleMarkRevised(item)}
                        style={{
                          flex: 2,
                          padding: '8px 12px',
                          borderRadius: 7,
                          background: 'var(--color-success)',
                          border: 'none',
                          color: '#0d1117',
                          fontSize: 12,
                          fontWeight: 600,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: 5,
                        }}
                      >
                        <CheckCircle size={12} />
                        Mark Revised
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Completed today */}
          {completedToday.size > 0 && (
            <div style={{ marginTop: 16 }}>
              <div style={{
                fontSize: 12,
                fontWeight: 600,
                color: 'var(--text-muted)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                marginBottom: 8,
              }}>
                Completed Today ({completedToday.size})
              </div>
              {revisionItems
                .filter(i => completedToday.has(i.problem.id))
                .map(item => (
                  <div key={item.problem.id} style={{
                    padding: '10px 14px',
                    marginBottom: 4,
                    background: 'var(--bg-secondary)',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: 8,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    opacity: 0.6,
                  }}>
                    <CheckCircle size={14} color="var(--color-success)" />
                    <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{item.problem.title}</span>
                    <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-muted)' }}>
                      Next in {getIntervalLabel(item.progress.revisionDates.length + 1)}
                    </span>
                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Sidebar: upcoming */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* How it works */}
          <div style={{
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-subtle)',
            borderRadius: 10,
            padding: 14,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
              <Zap size={13} color="var(--color-purple)" />
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Spaced Repetition
              </span>
            </div>
            {INTERVALS.map((days, i) => (
              <div key={i} style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                padding: '4px 0',
                borderBottom: i < INTERVALS.length - 1 ? '1px solid var(--border-subtle)' : 'none',
              }}>
                <div style={{
                  fontSize: 11,
                  color: 'var(--text-muted)',
                  width: 60,
                }}>
                  Review {i + 1}
                </div>
                <div style={{ flex: 1, height: 3, borderRadius: 2, background: 'var(--bg-tertiary)', overflow: 'hidden' }}>
                  <div style={{
                    width: `${Math.min(100, (days / 60) * 100)}%`,
                    height: '100%',
                    background: 'var(--color-purple)',
                    borderRadius: 2,
                  }} />
                </div>
                <div style={{ fontSize: 11, color: 'var(--color-purple)', width: 42, textAlign: 'right' }}>
                  {days < 7 ? `${days}d` : days < 30 ? `${days / 7}w` : `${days / 30}mo`}
                </div>
              </div>
            ))}
          </div>

          {/* Upcoming */}
          {upcomingItems.length > 0 && (
            <div style={{
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 10,
              overflow: 'hidden',
            }}>
              <div style={{
                padding: '10px 14px',
                borderBottom: '1px solid var(--border-subtle)',
                fontSize: 12,
                fontWeight: 600,
                color: 'var(--text-secondary)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}>
                Coming Up (7 days)
              </div>
              {upcomingItems.map((item, i) => (
                <div key={item.problem.id} style={{
                  padding: '10px 14px',
                  borderBottom: i < upcomingItems.length - 1 ? '1px solid var(--border-subtle)' : 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                }}>
                  <div style={{
                    fontSize: 11,
                    fontWeight: 700,
                    color: item.daysUntil === 1 ? 'var(--color-warning)' : 'var(--text-muted)',
                    width: 28,
                    flexShrink: 0,
                  }}>
                    {item.daysUntil === 1 ? 'tmrw' : `+${item.daysUntil}d`}
                  </div>
                  <div style={{
                    flex: 1,
                    fontSize: 12,
                    color: 'var(--text-secondary)',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}>
                    {item.problem.title}
                  </div>
                  <div style={{
                    width: 6,
                    height: 6,
                    borderRadius: '50%',
                    background: getDifficultyColor(item.problem.difficulty),
                    flexShrink: 0,
                  }} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
