import { useState } from 'react';
import { Settings, Github, Database, Shield, Trash2, Download, RefreshCw, ExternalLink, Check, AlertTriangle, LogOut } from 'lucide-react';
import { useApp } from '../lib/AppContext';
import { ALL_PROBLEMS } from '../data/problems';

export default function SettingsPage() {
  const { auth, userData, manualBackup, logout } = useApp();
  const [isBacking, setIsBacking] = useState(false);
  const [backupDone, setBackupDone] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteInput, setDeleteInput] = useState('');

  const solved = userData
    ? Object.values(userData.progress).filter(p => p.status === 'Solved' || p.status === 'Mastered').length
    : 0;

  const handleBackup = async () => {
    setIsBacking(true);
    try {
      await manualBackup();
      setBackupDone(true);
      setTimeout(() => setBackupDone(false), 3000);
    } finally {
      setIsBacking(false);
    }
  };

  const handleExportJSON = () => {
    if (!userData) return;
    const blob = new Blob([JSON.stringify(userData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `algovault-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClearLocalCache = () => {
    localStorage.removeItem('algovault_data_cache');
    window.location.reload();
  };

  const sectionTitle = (icon: React.ReactNode, title: string, desc?: string) => (
    <div style={{ marginBottom: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ color: 'var(--color-accent)' }}>{icon}</div>
        <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{title}</span>
      </div>
      {desc && <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '4px 0 0 26px' }}>{desc}</p>}
    </div>
  );

  const card = (children: React.ReactNode) => (
    <div style={{
      background: 'var(--bg-secondary)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 10,
      padding: '18px 20px',
      marginBottom: 14,
    }}>
      {children}
    </div>
  );

  const row = (label: string, value: React.ReactNode, mono = false) => (
    <div style={{
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '8px 0',
      borderBottom: '1px solid var(--border-subtle)',
    }}>
      <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{label}</span>
      <span style={{
        fontSize: 12,
        color: 'var(--text-primary)',
        fontFamily: mono ? 'var(--font-mono)' : undefined,
      }}>
        {value}
      </span>
    </div>
  );

  return (
    <div style={{ padding: '24px 32px', maxWidth: 680, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <Settings size={20} color="var(--color-accent)" />
          <h1 style={{ fontSize: 20, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>Settings</h1>
        </div>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, margin: 0 }}>
          Manage your account, data, and preferences.
        </p>
      </div>

      {/* Account */}
      {card(
        <>
          {sectionTitle(<Github size={15} />, 'GitHub Account')}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <img
              src={auth?.user.avatar_url}
              alt={auth?.user.login}
              style={{ width: 44, height: 44, borderRadius: '50%', border: '2px solid var(--border-subtle)' }}
            />
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>
                {auth?.user.name || auth?.user.login}
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>@{auth?.user.login}</div>
            </div>
            <a
              href={`https://github.com/${auth?.user.login}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                marginLeft: 'auto',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                fontSize: 12,
                color: 'var(--color-accent)',
                textDecoration: 'none',
              }}
            >
              View Profile <ExternalLink size={11} />
            </a>
          </div>
          <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: 12 }}>
            {row('Repository', (
              <a
                href={`https://github.com/${auth?.user.login}/${auth?.repoName}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: 'var(--color-accent)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4 }}
              >
                {auth?.repoName} <ExternalLink size={10} />
              </a>
            ))}
            {row('Token stored', <span style={{ color: 'var(--color-success)' }}>Locally in browser</span>)}
            {row('Public repos', auth?.user.public_repos?.toString() ?? '—')}
          </div>
        </>
      )}

      {/* Data */}
      {card(
        <>
          {sectionTitle(<Database size={15} />, 'Your Data', 'Progress is auto-synced to your private GitHub repo after each save.')}
          <div style={{ borderBottom: '1px solid var(--border-subtle)', paddingBottom: 12, marginBottom: 12 }}>
            {row('Problems solved', `${solved} / ${ALL_PROBLEMS.length}`)}
            {row('Last synced', userData?.lastUpdated
              ? new Date(userData.lastUpdated).toLocaleString()
              : '—'
            )}
            {row('Streak', `${userData?.streak ?? 0} days`)}
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={handleBackup}
              disabled={isBacking}
              style={{
                flex: 1,
                padding: '8px 12px',
                borderRadius: 7,
                background: backupDone ? 'var(--color-success)20' : 'var(--bg-tertiary)',
                border: `1px solid ${backupDone ? 'var(--color-success)' : 'var(--border-subtle)'}`,
                color: backupDone ? 'var(--color-success)' : 'var(--text-secondary)',
                fontSize: 12,
                cursor: isBacking ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 5,
              }}
            >
              {isBacking ? (
                <><RefreshCw size={12} style={{ animation: 'spin 1s linear infinite' }} /> Syncing…</>
              ) : backupDone ? (
                <><Check size={12} /> Synced!</>
              ) : (
                <><RefreshCw size={12} /> Sync to GitHub</>
              )}
            </button>
            <button
              onClick={handleExportJSON}
              style={{
                flex: 1,
                padding: '8px 12px',
                borderRadius: 7,
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-secondary)',
                fontSize: 12,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 5,
              }}
            >
              <Download size={12} /> Export JSON
            </button>
          </div>
        </>
      )}

      {/* Privacy */}
      {card(
        <>
          {sectionTitle(<Shield size={15} />, 'Privacy & Security')}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { label: 'Data storage', value: 'Your private GitHub repo only' },
              { label: 'Local cache', value: 'Browser localStorage (encrypted at rest by browser)' },
              { label: 'Analytics', value: 'None — AlgoVault has no backend' },
              { label: 'Token scope', value: 'repo (read + write to your repos)' },
            ].map(item => (
              <div key={item.label} style={{
                display: 'flex',
                justifyContent: 'space-between',
                gap: 20,
                padding: '7px 0',
                borderBottom: '1px solid var(--border-subtle)',
              }}>
                <span style={{ fontSize: 12, color: 'var(--text-secondary)', flexShrink: 0 }}>{item.label}</span>
                <span style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'right' }}>{item.value}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 14 }}>
            <button
              onClick={handleClearLocalCache}
              style={{
                width: '100%',
                padding: '8px 12px',
                borderRadius: 7,
                background: 'transparent',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-muted)',
                fontSize: 12,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 5,
              }}
            >
              <Trash2 size={12} /> Clear Local Cache
            </button>
          </div>
        </>
      )}

      {/* Danger zone */}
      <div style={{
        background: 'var(--bg-secondary)',
        border: '1px solid var(--color-danger)40',
        borderRadius: 10,
        padding: '18px 20px',
      }}>
        {sectionTitle(<AlertTriangle size={15} />, 'Danger Zone')}

        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 14,
        }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>Disconnect Account</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
              Removes your token from this browser. Your GitHub data is preserved.
            </div>
          </div>
          <button
            onClick={logout}
            style={{
              padding: '7px 14px',
              borderRadius: 7,
              background: 'transparent',
              border: '1px solid var(--color-danger)60',
              color: 'var(--color-danger)',
              fontSize: 12,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 5,
              flexShrink: 0,
            }}
          >
            <LogOut size={12} /> Disconnect
          </button>
        </div>

        {/* Delete data */}
        <div style={{
          padding: 14,
          background: 'var(--color-danger)08',
          border: '1px solid var(--color-danger)20',
          borderRadius: 8,
        }}>
          <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 4 }}>Delete All Progress</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 10 }}>
            This permanently deletes all progress data from your GitHub repo. This cannot be undone.
          </div>
          {!showDeleteConfirm ? (
            <button
              onClick={() => setShowDeleteConfirm(true)}
              style={{
                padding: '7px 14px',
                borderRadius: 7,
                background: 'var(--color-danger)15',
                border: '1px solid var(--color-danger)40',
                color: 'var(--color-danger)',
                fontSize: 12,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 5,
              }}
            >
              <Trash2 size={12} /> Delete Progress Data
            </button>
          ) : (
            <div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>
                Type <strong style={{ color: 'var(--color-danger)' }}>DELETE</strong> to confirm
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  type="text"
                  value={deleteInput}
                  onChange={e => setDeleteInput(e.target.value)}
                  placeholder="DELETE"
                  style={{
                    flex: 1,
                    padding: '6px 10px',
                    borderRadius: 6,
                    background: 'var(--bg-tertiary)',
                    border: '1px solid var(--border-subtle)',
                    color: 'var(--text-primary)',
                    fontSize: 12,
                    fontFamily: 'var(--font-mono)',
                    outline: 'none',
                  }}
                />
                <button
                  onClick={() => { setShowDeleteConfirm(false); setDeleteInput(''); }}
                  style={{
                    padding: '6px 12px',
                    borderRadius: 6,
                    background: 'var(--bg-tertiary)',
                    border: '1px solid var(--border-subtle)',
                    color: 'var(--text-muted)',
                    fontSize: 12,
                    cursor: 'pointer',
                  }}
                >
                  Cancel
                </button>
                <button
                  disabled={deleteInput !== 'DELETE'}
                  onClick={() => {
                    // Would delete data — just log out for safety in this implementation
                    logout();
                  }}
                  style={{
                    padding: '6px 12px',
                    borderRadius: 6,
                    background: deleteInput === 'DELETE' ? 'var(--color-danger)' : 'var(--bg-tertiary)',
                    border: '1px solid var(--color-danger)40',
                    color: deleteInput === 'DELETE' ? '#fff' : 'var(--text-muted)',
                    fontSize: 12,
                    cursor: deleteInput === 'DELETE' ? 'pointer' : 'not-allowed',
                  }}
                >
                  Confirm Delete
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
