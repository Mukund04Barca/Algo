import { GitHubUser, UserData, ProblemProgress, Status } from '@/types';

const GITHUB_API = 'https://api.github.com';
const DATA_FILE = 'progress.json';
const COMMIT_MSG = 'AlgoVault: Update progress';

export class GitHubService {
  private token: string;
  private repoName: string;
  private owner: string;
  private fileSha: string | null = null;

  constructor(token: string, owner: string, repoName: string) {
    this.token = token;
    this.owner = owner;
    this.repoName = repoName;
  }

  private headers() {
    return {
      Authorization: `Bearer ${this.token}`,
      'Content-Type': 'application/json',
      Accept: 'application/vnd.github+json',
    };
  }

  async verifyToken(): Promise<GitHubUser> {
    const res = await fetch(`${GITHUB_API}/user`, { headers: this.headers() });
    if (!res.ok) throw new Error('Invalid token or no access');
    return res.json();
  }

  async ensureRepo(): Promise<boolean> {
    // Check if repo exists
    const check = await fetch(`${GITHUB_API}/repos/${this.owner}/${this.repoName}`, {
      headers: this.headers(),
    });

    if (check.ok) return true;

    // Create repo
    const create = await fetch(`${GITHUB_API}/user/repos`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify({
        name: this.repoName,
        description: 'AlgoVault — My interview preparation data',
        private: true,
        auto_init: true,
      }),
    });

    if (!create.ok) {
      const err = await create.json();
      throw new Error(err.message || 'Failed to create repository');
    }

    // Wait a moment for repo to initialize
    await new Promise((r) => setTimeout(r, 1500));
    return true;
  }

  async loadData(): Promise<UserData | null> {
    const res = await fetch(
      `${GITHUB_API}/repos/${this.owner}/${this.repoName}/contents/${DATA_FILE}`,
      { headers: this.headers() }
    );

    if (res.status === 404) return null;
    if (!res.ok) throw new Error('Failed to load data from GitHub');

    const file = await res.json();
    this.fileSha = file.sha;
    const content = atob(file.content.replace(/\n/g, ''));
    return JSON.parse(content) as UserData;
  }

  async saveData(data: UserData): Promise<void> {
    const content = btoa(unescape(encodeURIComponent(JSON.stringify(data, null, 2))));

    const body: Record<string, unknown> = {
      message: COMMIT_MSG,
      content,
    };
    if (this.fileSha) body.sha = this.fileSha;

    const res = await fetch(
      `${GITHUB_API}/repos/${this.owner}/${this.repoName}/contents/${DATA_FILE}`,
      {
        method: 'PUT',
        headers: this.headers(),
        body: JSON.stringify(body),
      }
    );

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Failed to save data to GitHub');
    }

    const result = await res.json();
    this.fileSha = result.content.sha;
  }

  async manualBackup(data: UserData, message: string): Promise<void> {
    const solved = Object.values(data.progress).filter(
      (p) => p.status === 'Solved' || p.status === 'Mastered'
    ).length;

    const content = btoa(unescape(encodeURIComponent(JSON.stringify(data, null, 2))));

    const body: Record<string, unknown> = {
      message: message || `AlgoVault Backup — ${solved} problems solved`,
      content,
    };
    if (this.fileSha) body.sha = this.fileSha;

    const res = await fetch(
      `${GITHUB_API}/repos/${this.owner}/${this.repoName}/contents/${DATA_FILE}`,
      {
        method: 'PUT',
        headers: this.headers(),
        body: JSON.stringify(body),
      }
    );

    if (!res.ok) throw new Error('Backup failed');
    const result = await res.json();
    this.fileSha = result.content.sha;
  }
}

// UserData helpers
export function createEmptyUserData(): UserData {
  return {
    version: '1.0.0',
    lastUpdated: new Date().toISOString(),
    progress: {},
    dailyActivity: {},
    streak: 0,
    lastActiveDate: null,
  };
}

export function createDefaultProgress(problemId: string): ProblemProgress {
  return {
    problemId,
    status: 'Not Started',
    confidence: 0,
    attempts: 0,
    timeTaken: 0,
    notes: '',
    mistakes: '',
    solutions: [],
    revisionDates: [],
    lastSolved: null,
    favorite: false,
    nextRevision: null,
  };
}

export function computeNextRevision(revisionCount: number): string {
  const intervals = [1, 3, 7, 15, 30, 60];
  const days = intervals[Math.min(revisionCount, intervals.length - 1)];
  const next = new Date();
  next.setDate(next.getDate() + days);
  return next.toISOString();
}

export function updateStreak(data: UserData): UserData {
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  const updated = { ...data };

  if (updated.lastActiveDate === today) {
    // Already counted today
  } else if (updated.lastActiveDate === yesterday) {
    updated.streak += 1;
    updated.lastActiveDate = today;
  } else {
    updated.streak = 1;
    updated.lastActiveDate = today;
  }

  // Update daily activity
  updated.dailyActivity = {
    ...updated.dailyActivity,
    [today]: (updated.dailyActivity[today] || 0) + 1,
  };

  return updated;
}

export function getStatusColor(status: Status): string {
  const colors: Record<Status, string> = {
    'Not Started': 'var(--color-muted)',
    Learning: 'var(--color-warning)',
    Solved: 'var(--color-success)',
    'Needs Revision': 'var(--color-warning)',
    Mastered: 'var(--color-accent)',
  };
  return colors[status];
}
