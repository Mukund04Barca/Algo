export type Difficulty = 'Easy' | 'Medium' | 'Hard';
export type Status = 'Not Started' | 'Learning' | 'Solved' | 'Needs Revision' | 'Mastered';
export type Roadmap = 'Striver A2Z' | 'Blind 75' | 'NeetCode 150';
export type Language = 'python' | 'java' | 'cpp' | 'javascript';

export interface Problem {
  id: string;
  title: string;
  topic: string;
  difficulty: Difficulty;
  platform: string;
  link?: string;
  tags: string[];
  companies: string[];
  roadmap: Roadmap;
  order?: number;
}

export interface Solution {
  language: Language;
  code: string;
  timeComplexity: string;
  spaceComplexity: string;
  approach: string;
}

export interface ProblemProgress {
  problemId: string;
  status: Status;
  confidence: number; // 1-5
  attempts: number;
  timeTaken: number; // minutes
  notes: string;
  mistakes: string;
  solutions: Solution[];
  revisionDates: string[]; // ISO strings
  lastSolved: string | null; // ISO string
  favorite: boolean;
  nextRevision: string | null; // ISO string
}

export interface UserData {
  version: string;
  lastUpdated: string;
  progress: Record<string, ProblemProgress>;
  dailyActivity: Record<string, number>; // date -> problems solved
  streak: number;
  lastActiveDate: string | null;
}

export interface GitHubUser {
  login: string;
  name: string;
  avatar_url: string;
  public_repos: number;
}

export interface GitHubAuth {
  token: string;
  user: GitHubUser;
  repoName: string;
  repoCreated: boolean;
}

export interface FilterState {
  search: string;
  difficulty: Difficulty | 'All';
  status: Status | 'All';
  topic: string;
  company: string;
  tag: string;
}
