import { BrowserRouter } from 'react-router-dom';
import { useAuthStore } from '@/store';
import { AppRouter } from './Router';
import { Providers } from './Providers';
import { AppLayout } from '@/widgets/AppLayout';

export function App() {
  const auth = useAuthStore((s) => s.auth);

  return (
    <BrowserRouter>
      <Providers>
        {auth ? (
          <AppLayout>
            <AppRouter />
          </AppLayout>
        ) : (
          <AppRouter />
        )}
      </Providers>
    </BrowserRouter>
  );
}
