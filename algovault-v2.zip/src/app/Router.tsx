import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from '@/store';
import { Loading } from '@/shared/ui/Loading/Loading';

const AuthPage = lazy(() => import('@/features/auth/AuthPage'));
const Dashboard = lazy(() => import('@/features/dashboard/Dashboard'));
const Problems = lazy(() => import('@/features/problems/Problems'));
const Revision = lazy(() => import('@/features/revision/Revision'));
const Analytics = lazy(() => import('@/features/analytics/Analytics'));
const Settings = lazy(() => import('@/features/settings/Settings'));

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const auth = useAuthStore((s) => s.auth);
  if (!auth) return <Navigate to="/auth" replace />;
  return <>{children}</>;
}

export function AppRouter() {
  return (
    <Suspense fallback={<Loading fullscreen />}>
      <Routes>
        <Route path="/auth" element={<AuthPage />} />
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/problems"
          element={
            <ProtectedRoute>
              <Problems />
            </ProtectedRoute>
          }
        />
        <Route
          path="/revision"
          element={
            <ProtectedRoute>
              <Revision />
            </ProtectedRoute>
          }
        />
        <Route
          path="/analytics"
          element={
            <ProtectedRoute>
              <Analytics />
            </ProtectedRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <ProtectedRoute>
              <Settings />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}
