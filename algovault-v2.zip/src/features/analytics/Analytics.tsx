import { useMemo } from 'react';
import { BarChart2 } from 'lucide-react';
import { useProgressStore } from '@/store';
import { useRoadmaps } from '@/hooks';
import { Card } from '@/shared/ui/Card/Card';
import { Progress } from '@/shared/ui/Progress/Progress';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { subDays, format } from 'date-fns';

const CT = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-[var(--border-default)] bg-[var(--bg-elevated)] px-3 py-2 text-xs">
      {label && <div className="text-[var(--text-muted)] mb-1">{label}</div>}
      {payload.map((p: any) => (
        <div key={p.name} style={{ color: p.color }} className="flex gap-2">
          <span>{p.name}:</span><span className="font-bold">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function Analytics() {
  const { userData } = useProgressStore();
  const { allProblems } = useRoadmaps();

  const data = useMemo(() => {
    if (!userData) return null;
    const prog = userData.progress;
    const solved = Object.values(prog).filter((p) => p.status === 'Solved' || p.status === 'Mastered');

    const activity = Array.from({ length: 30 }, (_, i) => {
      const d = subDays(new Date(), 29 - i);
      const key = format(d, 'yyyy-MM-dd');
      return { date: format(d, 'MMM d'), problems: userData.dailyActivity?.[key] ?? 0 };
    });

    const difficulty = ['Easy', 'Medium', 'Hard'].map((diff) => ({
      name: diff,
      solved: solved.filter((sp) => allProblems.find((p) => p.id === sp.problemId)?.difficulty === diff).length,
      remaining: allProblems.filter((p) => p.difficulty === diff).length -
        solved.filter((sp) => allProblems.find((p) => p.id === sp.problemId)?.difficulty === diff).length,
    }));

    return { activity, difficulty, totalSolved: solved.length };
  }, [userData, allProblems]);

  if (!data) return null;

  return (
    <div className="p-6 max-w-[1000px] space-y-5">
      <div className="flex items-center gap-2 mb-1">
        <BarChart2 size={18} className="text-[var(--accent)]" />
        <h1 className="text-lg font-semibold text-[var(--text-primary)]">Analytics</h1>
      </div>

      <Card>
        <div className="mb-3 text-xs font-semibold text-[var(--text-secondary)]">30-Day Activity</div>
        <ResponsiveContainer width="100%" height={140}>
          <AreaChart data={data.activity} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="ag" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#58a6ff" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#58a6ff" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#21262d" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#6e7681' }} tickLine={false} axisLine={false} interval={4} />
            <YAxis tick={{ fontSize: 10, fill: '#6e7681' }} tickLine={false} axisLine={false} allowDecimals={false} />
            <Tooltip content={<CT />} />
            <Area type="monotone" dataKey="problems" name="Problems" stroke="#58a6ff" strokeWidth={2} fill="url(#ag)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <div className="mb-3 text-xs font-semibold text-[var(--text-secondary)]">Difficulty Breakdown</div>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={data.difficulty} layout="vertical" margin={{ top: 0, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#21262d" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 10, fill: '#6e7681' }} tickLine={false} axisLine={false} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#8b949e' }} tickLine={false} axisLine={false} width={50} />
              <Tooltip content={<CT />} />
              <Bar dataKey="solved" name="Solved" stackId="a">
                {data.difficulty.map((d) => (
                  <Cell key={d.name} fill={d.name === 'Easy' ? '#3fb950' : d.name === 'Medium' ? '#d29922' : '#f85149'} />
                ))}
              </Bar>
              <Bar dataKey="remaining" name="Remaining" stackId="a" fill="#21262d" radius={[0, 3, 3, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <div className="mb-3 text-xs font-semibold text-[var(--text-secondary)]">Coverage</div>
          <div className="text-3xl font-bold text-[var(--text-primary)] tabular-nums mb-2">
            {Math.round((data.totalSolved / allProblems.length) * 100)}%
          </div>
          <Progress value={Math.round((data.totalSolved / allProblems.length) * 100)} color="accent" size="md" />
          <p className="mt-2 text-xs text-[var(--text-muted)]">{data.totalSolved} / {allProblems.length} problems solved</p>
        </Card>
      </div>
    </div>
  );
}
