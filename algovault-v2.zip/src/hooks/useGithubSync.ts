import { useRef, useCallback } from 'react';
import { useAuthStore, useProgressStore } from '@/store';
import { GithubClient } from '@/services/github/GithubClient';
import { GithubStorage } from '@/services/github/GithubStorage';
import { LocalStorageAdapter } from '@/services/storage/LocalStorageAdapter';

const DEBOUNCE_MS = 2500;

/**
 * useGithubSync
 *
 * Composable hook that:
 * 1. Debounces saves (2.5s after last change)
 * 2. Writes to localStorage immediately (optimistic)
 * 3. Syncs to GitHub in background
 * 4. Updates sync status in progressStore
 *
 * No component imports GitHub directly. This hook is the only entry point.
 */
export function useGithubSync() {
  const { auth } = useAuthStore();
  const { userData, setSyncing, setSyncError, setSyncSuccess } = useProgressStore();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const localAdapter = new LocalStorageAdapter();

  const sync = useCallback(async () => {
    if (!userData) return;

    // Always write to local cache immediately
    await localAdapter.save(userData);

    // Only sync to GitHub if authenticated
    if (!auth) return;

    setSyncing(true);
    try {
      const client = new GithubClient(auth.token);
      const storage = new GithubStorage(client, auth.user.login, auth.repoName);
      await storage.save(userData);
      setSyncSuccess();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown sync error';
      setSyncError(message);
    }
  }, [userData, auth]);

  const debouncedSync = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(sync, DEBOUNCE_MS);
  }, [sync]);

  const syncNow = useCallback(async () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    await sync();
  }, [sync]);

  return { debouncedSync, syncNow };
}
