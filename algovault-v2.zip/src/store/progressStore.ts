import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type { ProblemProgress, UserData } from '@/types';
import { todayKey } from '@/lib/utils';

interface ProgressState {
  userData: UserData | null;
  isLoading: boolean;
  syncState: {
    status: 'idle' | 'syncing' | 'error' | 'success';
    lastSynced: string | null;
    error: string | null;
  };
}

interface ProgressActions {
  loadUserData: (data: UserData) => void;
  updateProgress: (id: string, patch: Partial<ProblemProgress>) => void;
  markActivity: () => void;
  setSyncing: (syncing: boolean) => void;
  setSyncError: (error: string | null) => void;
  setSyncSuccess: () => void;
  clearUserData: () => void;
}

type ProgressStore = ProgressState & ProgressActions;

export const useProgressStore = create<ProgressStore>()(
  devtools(
    immer((set) => ({
      userData: null,
      isLoading: false,
      syncState: { status: 'idle', lastSynced: null, error: null },

      loadUserData: (data) => set((state) => {
        state.userData = data;
        state.isLoading = false;
      }),

      updateProgress: (id, patch) => set((state) => {
        if (!state.userData) return;
        const existing = state.userData.progress[id];
        state.userData.progress[id] = {
          ...existing,
          ...patch,
          updatedAt: new Date().toISOString(),
        };
        state.userData.updatedAt = new Date().toISOString();
      }),

      markActivity: () => set((state) => {
        if (!state.userData) return;
        const today = todayKey();
        const prev = state.userData.dailyActivity[today] ?? 0;
        state.userData.dailyActivity[today] = prev + 1;

        // Streak logic
        const lastActive = state.userData.lastActiveDate;
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayKey = yesterday.toISOString().slice(0, 10);

        if (lastActive === yesterdayKey) {
          state.userData.streak += 1;
        } else if (lastActive !== today) {
          state.userData.streak = 1;
        }

        state.userData.longestStreak = Math.max(
          state.userData.streak,
          state.userData.longestStreak
        );
        state.userData.lastActiveDate = today;
        state.userData.updatedAt = new Date().toISOString();
      }),

      setSyncing: (syncing) => set((state) => {
        state.syncState.status = syncing ? 'syncing' : 'idle';
        if (syncing) state.syncState.error = null;
      }),

      setSyncError: (error) => set((state) => {
        state.syncState.status = 'error';
        state.syncState.error = error;
      }),

      setSyncSuccess: () => set((state) => {
        state.syncState.status = 'success';
        state.syncState.lastSynced = new Date().toISOString();
        state.syncState.error = null;
      }),

      clearUserData: () => set((state) => {
        state.userData = null;
        state.syncState = { status: 'idle', lastSynced: null, error: null };
      }),
    })),
    { name: 'ProgressStore' }
  )
);
