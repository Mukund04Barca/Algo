import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Code2, Brain, BarChart2, Settings,
  ChevronLeft, ChevronRight, LogOut, RefreshCw
} from 'lucide-react';
import { useAuthStore, useProgressStore, useSettingsStore } from '@/store';
import { Progress } from '@/shared/ui/Progress/Progress';
import { cn } from '@/lib/utils';
import { useRoadmaps } from '@/hooks';
import styles from './Sidebar.module.css';

const NAV = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/problems', icon: Code2, label: 'Problems' },
  { to: '/revision', icon: Brain, label: 'Revision' },
  { to: '/analytics', icon: BarChart2, label: 'Analytics' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

export function Sidebar() {
  const { auth, clearAuth } = useAuthStore();
  const { userData, syncState } = useProgressStore();
  const { collapsed, toggleSidebar } = useSettingsStore((s) => ({
    collapsed: s.sidebarCollapsed,
    toggleSidebar: s.toggleSidebar,
  }));
  const { allProblems } = useRoadmaps();
  const location = useLocation();

  const solved = userData
    ? Object.values(userData.progress).filter(
        (p) => p.status === 'Solved' || p.status === 'Mastered'
      ).length
    : 0;
  const pct = allProblems.length > 0 ? Math.round((solved / allProblems.length) * 100) : 0;

  return (
    <aside
      className={cn(
        styles.sidebar,
        'fixed left-0 top-0 h-full flex flex-col border-r border-[var(--border-default)] bg-[var(--bg-elevated)]',
        'transition-[width] duration-300',
        collapsed ? 'w-[60px]' : 'w-[220px]'
      )}
    >
      {/* Header */}
      <div className={cn('flex items-center border-b border-[var(--border-default)] py-3',
        collapsed ? 'justify-center px-3' : 'justify-between px-4'
      )}>
        {!collapsed && (
          <span className="text-[13px] font-semibold tracking-tight text-[var(--text-primary)]">
            AlgoVault
          </span>
        )}
        <button
          onClick={toggleSidebar}
          className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--text-muted)] transition-colors hover:bg-[var(--bg-overlay)] hover:text-[var(--text-primary)]"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-2">
        {NAV.map(({ to, icon: Icon, label }) => {
          const active = to === '/'
            ? location.pathname === '/'
            : location.pathname.startsWith(to);
          return (
            <NavLink
              key={to}
              to={to}
              className={cn(
                'flex items-center gap-3 px-3 py-2 mx-2 rounded-md text-[13px] font-medium',
                'transition-colors duration-100',
                active
                  ? 'bg-[var(--accent-subtle)] text-[var(--accent)]'
                  : 'text-[var(--text-secondary)] hover:bg-[var(--bg-overlay)] hover:text-[var(--text-primary)]',
                collapsed && 'justify-center'
              )}
            >
              <Icon size={15} className="shrink-0" />
              {!collapsed && label}
            </NavLink>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-[var(--border-default)] p-3 space-y-2">
        {/* Progress bar */}
        {!collapsed && (
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] text-[var(--text-muted)]">
              <span>Overall</span>
              <span className="tabular-nums">{solved}/{allProblems.length}</span>
            </div>
            <Progress value={pct} color={pct >= 80 ? 'success' : pct >= 40 ? 'accent' : 'purple'} />
          </div>
        )}

        {/* Sync status */}
        {!collapsed && (
          <div className={cn(
            'flex items-center gap-1.5 text-[11px]',
            syncState.status === 'error' ? 'text-[var(--danger)]'
              : syncState.status === 'syncing' ? 'text-[var(--warning)]'
              : 'text-[var(--text-muted)]'
          )}>
            <RefreshCw
              size={10}
              className={syncState.status === 'syncing' ? 'animate-spin' : ''}
            />
            {syncState.status === 'error' ? 'Sync failed'
              : syncState.status === 'syncing' ? 'Syncing…'
              : syncState.lastSynced ? 'Synced' : 'Not synced'}
          </div>
        )}

        {/* User */}
        {auth && (
          <div className={cn(
            'flex items-center gap-2',
            collapsed ? 'justify-center' : 'justify-between'
          )}>
            <div className="flex items-center gap-2 min-w-0">
              <img
                src={auth.user.avatar_url}
                alt={auth.user.login}
                className="h-6 w-6 shrink-0 rounded-full"
              />
              {!collapsed && (
                <span className="truncate text-[12px] text-[var(--text-secondary)]">
                  {auth.user.login}
                </span>
              )}
            </div>
            {!collapsed && (
              <button
                onClick={clearAuth}
                className="shrink-0 text-[var(--text-muted)] hover:text-[var(--danger)] transition-colors"
                title="Disconnect"
              >
                <LogOut size={13} />
              </button>
            )}
          </div>
        )}
      </div>
    </aside>
  );
}
