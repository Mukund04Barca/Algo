import { useMemo } from 'react';
import { useProgressStore } from '@/store';
import { useRoadmaps } from '@/hooks';
import { Card } from '@/shared/ui/Card/Card';
import { Progress } from '@/shared/ui/Progress/Progress';
import { DifficultyBadge } from '@/shared/ui/Badge/Badge';
import { Flame, Target, Brain, Trophy, TrendingUp } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { cn } from '@/lib/utils';

export default function Dashboard() {
  const { userData } = useProgressStore();
  const { allProblems, roadmaps } = useRoadmaps();

  const stats = useMemo(() => {
    if (!userData) return null;
    const progress = userData.progress;
    const solved = Object.values(progress).filter(
      (p) => p.status === 'Solved' || p.status === 'Mastered'
    );
    const mastered = Object.values(progress).filter((p) => p.status === 'Mastered');
    const needsRevision = Object.values(progress).filter((p) => p.status === 'Needs Revision');

    const diffStats = ['Easy', 'Medium', 'Hard'].map((d) => ({
      diff: d,
      total: allProblems.filter((p) => p.difficulty === d).length,
      solved: solved.filter((sp) => {
        const p = allProblems.find((prob) => prob.id === sp.problemId);
        return p?.difficulty === d;
      }).length,
    }));

    const recentSolved = Object.values(progress)
      .filter((p) => p.lastSolved && (p.status === 'Solved' || p.status === 'Mastered'))
      .sort((a, b) => (b.lastSolved! > a.lastSolved! ? 1 : -1))
      .slice(0, 5)
      .map((p) => ({
        ...p,
        problem: allProblems.find((prob) => prob.id === p.problemId),
      }))
      .filter((p) => p.problem);

    // Heatmap: last 84 days
    const heatmap = Array.from({ length: 84 }, (_, i) => {
      const date = subDays(new Date(), 83 - i);
      const key = format(date, 'yyyy-MM-dd');
      return { date: key, count: userData.dailyActivity?.[key] ?? 0 };
    });

    return { solved: solved.length, mastered: mastered.length, needsRevision: needsRevision.length, diffStats, recentSolved, heatmap };
  }, [userData, allProblems]);

  if (!stats) return null;

  const pct = Math.round((stats.solved / allProblems.length) * 100);

  return (
    <div className="p-6 space-y-5 max-w-[1100px]">
      <div>
        <h1 className="text-lg font-semibold text-[var(--text-primary)]">Dashboard</h1>
        <p className="text-sm text-[var(--text-secondary)] mt-0.5">
          Welcome back, {userData?.profile.githubName}
        </p>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Streak', value: userData?.streak ?? 0, suffix: 'days', icon: <Flame size={15} />, color: 'text-[var(--warning)]', bg: 'bg-[var(--warning-subtle)]' },
          { label: 'Solved', value: stats.solved, suffix: `/ ${allProblems.length}`, icon: <Target size={15} />, color: 'text-[var(--accent)]', bg: 'bg-[var(--accent-subtle)]' },
          { label: 'Mastered', value: stats.mastered, suffix: 'problems', icon: <Trophy size={15} />, color: 'text-[var(--success)]', bg: 'bg-[var(--success-subtle)]' },
          { label: 'To Review', value: stats.needsRevision, suffix: 'queued', icon: <Brain size={15} />, color: 'text-[var(--purple)]', bg: 'bg-[var(--purple-subtle)]' },
        ].map((kpi) => (
          <Card key={kpi.label} className="flex items-center gap-3">
            <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-lg', kpi.bg, kpi.color)}>
              {kpi.icon}
            </div>
            <div>
              <div className="text-xl font-bold tabular-nums text-[var(--text-primary)] leading-none">
                {kpi.value}
              </div>
              <div className="text-[11px] text-[var(--text-muted)] mt-0.5">{kpi.label} · {kpi.suffix}</div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-[1fr_320px] gap-4">
        {/* Left col */}
        <div className="space-y-4">
          {/* Activity heatmap */}
          <Card>
            <div className="mb-3 flex items-center gap-2">
              <TrendingUp size={14} className="text-[var(--accent)]" />
              <span className="text-xs font-semibold text-[var(--text-secondary)]">Activity — Last 12 Weeks</span>
            </div>
            <div className="grid gap-1" style={{ gridTemplateColumns: 'repeat(12, 1fr)' }}>
              {Array.from({ length: 12 }, (_, week) => (
                <div key={week} className="flex flex-col gap-1">
                  {Array.from({ length: 7 }, (_, day) => {
                    const idx = week * 7 + day;
                    const cell = stats.heatmap[idx];
                    return (
                      <div
                        key={day}
                        title={cell ? `${cell.date}: ${cell.count} solved` : ''}
                        className="h-3 w-full rounded-[2px]"
                        style={{
                          background: !cell?.count ? 'var(--bg-overlay)'
                            : cell.count >= 5 ? 'var(--accent)'
                            : cell.count >= 3 ? 'color-mix(in srgb, var(--accent) 70%, transparent)'
                            : 'color-mix(in srgb, var(--accent) 40%, transparent)',
                        }}
                      />
                    );
                  })}
                </div>
              ))}
            </div>
          </Card>

          {/* Difficulty breakdown */}
          <Card>
            <div className="mb-3 flex items-center gap-2">
              <Target size={14} className="text-[var(--accent)]" />
              <span className="text-xs font-semibold text-[var(--text-secondary)]">Difficulty Breakdown</span>
            </div>
            <div className="space-y-3">
              {stats.diffStats.map((d) => {
                const p = d.total > 0 ? Math.round((d.solved / d.total) * 100) : 0;
                const color = d.diff === 'Easy' ? 'success' : d.diff === 'Medium' ? 'warning' : 'danger';
                return (
                  <div key={d.diff}>
                    <div className="flex justify-between mb-1">
                      <span className="text-xs text-[var(--text-secondary)]">{d.diff}</span>
                      <span className="text-xs tabular-nums text-[var(--text-muted)]">{d.solved}/{d.total}</span>
                    </div>
                    <Progress value={p} color={color} />
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Right col */}
        <div className="space-y-4">
          {/* Overall */}
          <Card>
            <div className="mb-3 text-xs font-semibold text-[var(--text-secondary)]">Overall Progress</div>
            <div className="text-3xl font-bold text-[var(--text-primary)] tabular-nums mb-1">{pct}%</div>
            <Progress value={pct} color={pct >= 80 ? 'success' : pct >= 40 ? 'accent' : 'purple'} size="md" />
            <p className="mt-2 text-[11px] text-[var(--text-muted)]">
              {stats.solved} of {allProblems.length} problems
            </p>
          </Card>

          {/* Roadmap progress */}
          <Card>
            <div className="mb-3 text-xs font-semibold text-[var(--text-secondary)]">Roadmaps</div>
            <div className="space-y-3">
              {roadmaps.map((rm) => {
                const total = rm.totalProblems;
                const done = rm.topics.flatMap((t) => t.problems).filter((p) => {
                  const prog = userData?.progress[p.id];
                  return prog?.status === 'Solved' || prog?.status === 'Mastered';
                }).length;
                const p = total > 0 ? Math.round((done / total) * 100) : 0;
                return (
                  <div key={rm.id}>
                    <div className="flex justify-between mb-1">
                      <span className="text-xs text-[var(--text-secondary)]">{rm.name}</span>
                      <span className="text-xs tabular-nums text-[var(--text-muted)]">{done}/{total}</span>
                    </div>
                    <Progress value={p} color={p >= 80 ? 'success' : p >= 40 ? 'accent' : 'purple'} />
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Recent */}
          <Card>
            <div className="mb-3 text-xs font-semibold text-[var(--text-secondary)]">Recently Solved</div>
            {stats.recentSolved.length === 0 ? (
              <p className="text-xs text-[var(--text-muted)]">No problems solved yet</p>
            ) : (
              <div className="space-y-2">
                {stats.recentSolved.map((item) => (
                  <div key={item.problemId} className="flex items-center gap-2">
                    <DifficultyBadge difficulty={item.problem!.difficulty} />
                    <span className="flex-1 truncate text-xs text-[var(--text-secondary)]">
                      {item.problem!.title}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
