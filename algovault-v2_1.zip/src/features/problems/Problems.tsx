import { useState, useMemo } from 'react';
import { Search, Filter, ExternalLink } from 'lucide-react';
import { useProgressStore } from '@/store';
import { useRoadmaps, useSearch } from '@/hooks';
import { Input } from '@/shared/ui/Input/Input';
import { DifficultyBadge, StatusBadge } from '@/shared/ui/Badge/Badge';
import { EmptyState } from '@/shared/ui/EmptyState/EmptyState';
import type { RoadmapId } from '@/types';
import type { SearchFilters } from '@/hooks/useSearch';
import { cn } from '@/lib/utils';

const ROADMAP_LABELS: Record<RoadmapId, string> = {
  'striver-a2z': 'Striver A2Z',
  'blind-75': 'Blind 75',
  'neetcode-150': 'NeetCode 150',
};

export default function Problems() {
  const { userData } = useProgressStore();
  const { allProblems, roadmaps } = useRoadmaps();
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    difficulty: 'All',
    status: 'All',
    topic: '',
    roadmapId: '',
  });

  const statuses = useMemo(
    () => Object.fromEntries(
      Object.entries(userData?.progress ?? {}).map(([id, p]) => [id, { status: p.status }])
    ),
    [userData]
  );

  const filtered = useSearch(allProblems, statuses, filters);

  const topics = useMemo(
    () => [...new Set(allProblems.map((p) => p.topic))].sort(),
    [allProblems]
  );

  return (
    <div className="p-6 max-w-[1100px]">
      <div className="mb-5">
        <h1 className="text-lg font-semibold text-[var(--text-primary)]">Problems</h1>
        <p className="text-sm text-[var(--text-secondary)] mt-0.5">
          {filtered.length} of {allProblems.length} problems
        </p>
      </div>

      {/* Roadmap tabs */}
      <div className="flex items-center gap-1 mb-4 border-b border-[var(--border-default)] pb-0">
        {[{ id: '', name: 'All' }, ...roadmaps.map((r) => ({ id: r.id, name: r.name }))].map((rm) => (
          <button
            key={rm.id}
            onClick={() => setFilters((f) => ({ ...f, roadmapId: rm.id }))}
            className={cn(
              'px-3 py-2 text-sm font-medium border-b-2 -mb-px transition-colors',
              filters.roadmapId === rm.id
                ? 'border-[var(--accent)] text-[var(--accent)]'
                : 'border-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            )}
          >
            {rm.name}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-4 flex-wrap">
        <Input
          className="w-64"
          placeholder="Search problems, tags, companies…"
          value={filters.query}
          onChange={(e) => setFilters((f) => ({ ...f, query: e.target.value }))}
          iconLeft={<Search size={13} />}
        />
        {(['All', 'Easy', 'Medium', 'Hard'] as const).map((d) => (
          <button
            key={d}
            onClick={() => setFilters((f) => ({ ...f, difficulty: d }))}
            className={cn(
              'px-3 h-9 text-xs rounded-md border transition-colors',
              filters.difficulty === d
                ? d === 'All' ? 'bg-[var(--bg-overlay)] border-[var(--border-emphasis)] text-[var(--text-primary)]'
                  : d === 'Easy' ? 'bg-[var(--success-subtle)] border-[var(--success)] text-[var(--success)]'
                  : d === 'Medium' ? 'bg-[var(--warning-subtle)] border-[var(--warning)] text-[var(--warning)]'
                  : 'bg-[var(--danger-subtle)] border-[var(--danger)] text-[var(--danger)]'
                : 'bg-[var(--bg-elevated)] border-[var(--border-default)] text-[var(--text-muted)] hover:text-[var(--text-secondary)]'
            )}
          >
            {d}
          </button>
        ))}
        <select
          value={filters.status}
          onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value as SearchFilters['status'] }))}
          className="h-9 rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] px-2 text-xs text-[var(--text-secondary)] outline-none focus:border-[var(--accent)]"
        >
          {['All', 'Not Started', 'Learning', 'Solved', 'Needs Revision', 'Mastered'].map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <select
          value={filters.topic}
          onChange={(e) => setFilters((f) => ({ ...f, topic: e.target.value }))}
          className="h-9 rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] px-2 text-xs text-[var(--text-secondary)] outline-none focus:border-[var(--accent)]"
        >
          <option value="">All Topics</option>
          {topics.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={<Filter size={20} />}
          title="No problems match"
          description="Try adjusting your filters"
          action={{ label: 'Clear filters', onClick: () => setFilters({ query: '', difficulty: 'All', status: 'All', topic: '', roadmapId: '' }) }}
        />
      ) : (
        <div className="rounded-lg border border-[var(--border-default)] overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[var(--border-default)] bg-[var(--bg-elevated)]">
                <th className="px-4 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">#</th>
                <th className="px-4 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Title</th>
                <th className="px-4 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Topic</th>
                <th className="px-4 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Difficulty</th>
                <th className="px-4 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Status</th>
                <th className="px-4 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Link</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p, i) => {
                const prog = userData?.progress[p.id];
                const status = prog?.status ?? 'Not Started';
                return (
                  <tr
                    key={p.id}
                    className="border-b border-[var(--border-muted)] last:border-0 hover:bg-[var(--bg-elevated)] transition-colors"
                  >
                    <td className="px-4 py-3 text-xs tabular-nums text-[var(--text-muted)]">{i + 1}</td>
                    <td className="px-4 py-3">
                      <div className="text-sm font-medium text-[var(--text-primary)]">{p.title}</div>
                      <div className="text-[11px] text-[var(--text-muted)]">{ROADMAP_LABELS[p.roadmapId]}</div>
                    </td>
                    <td className="px-4 py-3 text-xs text-[var(--text-secondary)]">{p.topic}</td>
                    <td className="px-4 py-3"><DifficultyBadge difficulty={p.difficulty} /></td>
                    <td className="px-4 py-3"><StatusBadge status={status} /></td>
                    <td className="px-4 py-3">
                      {p.link ? (
                        <a href={p.link} target="_blank" rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-[var(--accent)] hover:underline">
                          <ExternalLink size={11} />
                          {p.platform}
                        </a>
                      ) : (
                        <span className="text-xs text-[var(--text-muted)]">{p.platform}</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
