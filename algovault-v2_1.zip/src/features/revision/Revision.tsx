import { useRevision } from '@/hooks';
import { useRevisionStore, useProgressStore } from '@/store';
import { Brain, CheckCircle, AlertCircle, ChevronRight } from 'lucide-react';
import { Card } from '@/shared/ui/Card/Card';
import { Button } from '@/shared/ui/Button/Button';
import { DifficultyBadge } from '@/shared/ui/Badge/Badge';
import { EmptyState } from '@/shared/ui/EmptyState/EmptyState';
import { computeNextReview } from './RevisionEngine';
import { useState } from 'react';

export default function Revision() {
  useRevision();
  const { dueItems, completedToday, markComplete } = useRevisionStore();
  const { userData, updateProgress } = useProgressStore();
  const [expanded, setExpanded] = useState<string | null>(null);

  const handleMarkRevised = async (problemId: string) => {
    const prog = userData?.progress[problemId];
    if (!prog) return;

    const { nextReview, newInterval, newEaseFactor } = computeNextReview(
      prog.confidence,
      prog.interval,
      prog.easeFactor
    );

    updateProgress(problemId, {
      reviewHistory: [...prog.reviewHistory, { reviewedAt: new Date().toISOString(), confidence: prog.confidence }],
      nextReview: nextReview.toISOString(),
      interval: newInterval,
      easeFactor: newEaseFactor,
      status: prog.reviewHistory.length >= 4 ? 'Mastered' : prog.status,
    });
    markComplete(problemId);
    setExpanded(null);
  };

  return (
    <div className="p-6 max-w-[800px]">
      <div className="mb-5">
        <div className="flex items-center gap-2 mb-1">
          <Brain size={18} className="text-[var(--purple)]" />
          <h1 className="text-lg font-semibold text-[var(--text-primary)]">Revision Queue</h1>
        </div>
        <p className="text-sm text-[var(--text-secondary)]">
          Spaced repetition · {dueItems.length} due · {completedToday.size} done today
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-5">
        {[
          { label: 'Due', value: dueItems.filter((i) => !i.isOverdue).length, color: 'text-[var(--accent)]', bg: 'bg-[var(--accent-subtle)]', icon: <CheckCircle size={14} /> },
          { label: 'Overdue', value: dueItems.filter((i) => i.isOverdue).length, color: 'text-[var(--danger)]', bg: 'bg-[var(--danger-subtle)]', icon: <AlertCircle size={14} /> },
          { label: 'Done today', value: completedToday.size, color: 'text-[var(--success)]', bg: 'bg-[var(--success-subtle)]', icon: <CheckCircle size={14} /> },
        ].map((s) => (
          <Card key={s.label} className="flex items-center gap-3">
            <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${s.bg} ${s.color}`}>{s.icon}</div>
            <div>
              <div className={`text-xl font-bold tabular-nums ${s.color}`}>{s.value}</div>
              <div className="text-[11px] text-[var(--text-muted)]">{s.label}</div>
            </div>
          </Card>
        ))}
      </div>

      {dueItems.length === 0 ? (
        <EmptyState
          icon={<Brain size={20} />}
          title="All caught up!"
          description="No revisions due. Come back tomorrow."
        />
      ) : (
        <Card padding="none">
          {dueItems.map((item, i) => (
            <div
              key={item.problem.id}
              className={`border-b border-[var(--border-muted)] last:border-0 ${i === 0 ? '' : ''}`}
            >
              <div
                className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-[var(--bg-overlay)] transition-colors"
                onClick={() => setExpanded(expanded === item.problem.id ? null : item.problem.id)}
              >
                <div className={`h-2 w-2 shrink-0 rounded-full ${item.isOverdue ? 'bg-[var(--danger)]' : 'bg-[var(--accent)]'}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-[var(--text-primary)] truncate">{item.problem.title}</span>
                    <DifficultyBadge difficulty={item.problem.difficulty} />
                  </div>
                  <div className="text-[11px] text-[var(--text-muted)]">
                    {item.problem.topic} · Rev #{(item.progress.reviewHistory.length ?? 0) + 1}
                    {item.isOverdue && ` · ${item.daysOverdue}d overdue`}
                  </div>
                </div>
                <ChevronRight
                  size={14}
                  className={`shrink-0 text-[var(--text-muted)] transition-transform ${expanded === item.problem.id ? 'rotate-90' : ''}`}
                />
              </div>

              {expanded === item.problem.id && (
                <div className="px-4 pb-3 flex gap-2" onClick={(e) => e.stopPropagation()}>
                  {item.problem.link && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => window.open(item.problem.link, '_blank')}
                    >
                      Open Problem
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="success"
                    onClick={() => handleMarkRevised(item.problem.id)}
                  >
                    Mark Revised ✓
                  </Button>
                </div>
              )}
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}
