import { BrowserRouter } from 'react-router-dom';
import { AppRouter } from './Router';
import { Providers } from './Providers';
import { AppLayout } from '@/widgets/AppLayout';
import { useBootstrap } from '@/hooks/useBootstrap';

function AppShell() {
  useBootstrap();
  return (
    <AppLayout>
      <AppRouter />
    </AppLayout>
  );
}

export function App() {
  return (
    <BrowserRouter>
      <Providers>
        <AppShell />
      </Providers>
    </BrowserRouter>
  );
}
