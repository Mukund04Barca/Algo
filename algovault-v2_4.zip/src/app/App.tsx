import { BrowserRouter } from 'react-router-dom';
import { AppRouter } from './Router';
import { Providers } from './Providers';
import { AppLayout } from '@/widgets/AppLayout';
import { useBootstrap } from '@/hooks/useBootstrap';
import { useAutoSave } from '@/hooks/useAutoSave';

function AppShell() {
  useBootstrap();
  useAutoSave();
  return (
    <AppLayout>
      <AppRouter />
    </AppLayout>
  );
}

export function App() {
  return (
    <BrowserRouter>
      <Providers>
        <AppShell />
      </Providers>
    </BrowserRouter>
  );
}
