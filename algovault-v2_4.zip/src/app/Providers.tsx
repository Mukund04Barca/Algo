import type { ReactNode } from 'react';

/**
 * Providers — wraps the app with any future context providers.
 * Currently a passthrough; expand as the app grows.
 */
interface ProvidersProps {
  children: ReactNode;
}

export function Providers({ children }: ProvidersProps) {
  return <>{children}</>;
}
