import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Loading } from '@/shared/ui/Loading/Loading';

const Dashboard = lazy(() => import('@/features/dashboard/Dashboard'));
const Problems = lazy(() => import('@/features/problems/Problems'));
const Revision = lazy(() => import('@/features/revision/Revision'));
const Analytics = lazy(() => import('@/features/analytics/Analytics'));
const Settings = lazy(() => import('@/features/settings/Settings'));

export function AppRouter() {
  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/problems" element={<Problems />} />
        <Route path="/revision" element={<Revision />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}
