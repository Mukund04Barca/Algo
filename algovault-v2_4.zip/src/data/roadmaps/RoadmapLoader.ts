import type { Roadmap } from '@/types';
import { RoadmapSchema } from '@/lib/zod/roadmap.schema';
import { striverA2Z } from './striver';
import { blind75 } from './blind75';
import { neetcode150 } from './neetcode150';

const RAW_ROADMAPS = [striverA2Z, blind75, neetcode150];

let _loaded: Roadmap[] | null = null;

/**
 * Load, validate, and cache all roadmaps.
 * Throws on schema violation — fail fast, not silently.
 */
export function loadAllRoadmaps(): Roadmap[] {
  if (_loaded) return _loaded;

  _loaded = RAW_ROADMAPS.map((raw, i) => {
    const result = RoadmapSchema.safeParse(raw);
    if (!result.success) {
      throw new Error(
        `Roadmap[${i}] failed validation:\n${JSON.stringify(result.error.flatten(), null, 2)}`
      );
    }
    return {
      ...result.data,
      totalProblems: result.data.topics.reduce((sum, t) => sum + t.problems.length, 0),
    };
  });

  return _loaded;
}

export function getRoadmapById(id: string): Roadmap | undefined {
  return loadAllRoadmaps().find((r) => r.id === id);
}
