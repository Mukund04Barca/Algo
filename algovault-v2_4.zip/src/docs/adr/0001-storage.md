# ADR 0001 — Storage Layer Architecture

**Date:** 2024  
**Status:** Accepted

## Context

AlgoVault needs to persist user progress. The natural choice is GitHub (user already has an account, free private repos, built-in version history). But hardcoding GitHub into every store or component creates tight coupling — if we ever want to add Supabase, IndexedDB, or offline-first support, we'd need to touch code everywhere.

## Decision

Introduce a `StorageAdapter` interface that all stores interact with exclusively. No store or component ever imports `GithubClient` directly.

```ts
interface StorageAdapter {
  load(): Promise<UserData | null>;
  save(data: UserData): Promise<void>;
  delete(): Promise<void>;
  readonly name: string;
}
```

Three implementations:
- `LocalStorageAdapter` — used before auth, and as write-through cache
- `GithubStorage` — primary persistent storage after auth
- *(future)* `SupabaseAdapter`, `IndexedDBAdapter`

## Consequences

**Good:** Stores are storage-agnostic. Swapping backend = implement one interface.  
**Good:** Tests can inject a mock adapter trivially.  
**Good:** Offline-first falls out naturally — write to localStorage, sync to GitHub when online.  
**Tradeoff:** Slightly more abstraction than strictly needed today. Worth it for a project intended to last years.
