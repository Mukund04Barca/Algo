# ADR 0002 — State Management

**Date:** 2024  
**Status:** Accepted

## Context

The app has four distinct state concerns: auth, progress, revision queue, and settings. Options considered: React Context, Redux, Zustand, Jotai.

## Decision

**Zustand 5** with Immer + Devtools middleware, split into four stores by domain:

| Store | Owns |
|---|---|
| `authStore` | GitHub token, user profile |
| `progressStore` | All problem progress, sync state |
| `revisionStore` | Computed due items, today's completed set |
| `settingsStore` | Theme, language, auto-sync, sidebar state |

Each store has one responsibility. No god-object `AppContext`.

## Consequences

**Good:** Minimal boilerplate. Stores are just functions.  
**Good:** Devtools give time-travel debugging in development.  
**Good:** Immer lets us write mutating code that's actually immutable.  
**Good:** Any component subscribes to any store slice without prop drilling.  
**Tradeoff:** Four separate stores means cross-store logic (e.g., revision reads from progress) lives in hooks, not stores. This is intentional — hooks compose, stores don't.
