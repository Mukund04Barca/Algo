# ADR 0003 — Roadmap Data Format

**Date:** 2024  
**Status:** Accepted

## Context

Problem data (750+ problems across 3 roadmaps) needs to be stored somewhere. Options: hardcoded objects, JSON files, remote API, database.

## Decision

TypeScript source files (`.ts`) validated by Zod on first load, not raw JSON.

Rationale for `.ts` over `.json`:
- TypeScript files get autocomplete and compile-time checking during editing
- Zod validates at runtime on first `loadAllRoadmaps()` call
- If a problem definition is malformed, the app throws immediately — fail fast, not silently
- No network request required — data is bundled

`RoadmapLoader.ts` is the single entry point. It validates every roadmap, attaches computed `totalProblems`, and caches the result. Cache is module-level — roadmap data never changes at runtime.

```ts
export function loadAllRoadmaps(): Roadmap[] {
  if (_loaded) return _loaded;
  _loaded = RAW_ROADMAPS.map((raw) => {
    const result = RoadmapSchema.safeParse(raw);
    if (!result.success) throw new Error(`Roadmap validation failed`);
    return { ...result.data, totalProblems: ... };
  });
  return _loaded;
}
```

## Consequences

**Good:** Zero network requests for roadmap data.  
**Good:** Typos in problem data caught at startup, not at render.  
**Good:** Easy to add a new roadmap — create a `.ts` file, add to `RAW_ROADMAPS`.  
**Tradeoff:** Roadmap updates require a code deploy. Acceptable — these don't change frequently.
