import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Github, ArrowRight, Check, AlertCircle, Lock } from 'lucide-react';
import { useAuthStore, useProgressStore } from '@/store';
import { GithubClient } from '@/services/github/GithubClient';
import { GithubStorage } from '@/services/github/GithubStorage';
import { LocalStorageAdapter } from '@/services/storage/LocalStorageAdapter';
import { Button } from '@/shared/ui/Button/Button';
import { Input } from '@/shared/ui/Input/Input';
import { cn } from '@/lib/utils';
import type { GitHubAuth } from '@/types';

type Step = 'token' | 'repo';

function createInitialUserData(auth: GitHubAuth) {
  const now = new Date().toISOString();
  return {
    version: '2.0.0',
    profile: {
      githubLogin: auth.user.login,
      githubName: auth.user.name ?? auth.user.login,
      avatarUrl: auth.user.avatar_url,
      repoName: auth.repoName,
    },
    progress: {},
    dailyActivity: {},
    streak: 0,
    longestStreak: 0,
    lastActiveDate: null,
    createdAt: now,
    updatedAt: now,
  };
}

export default function AuthPage() {
  const navigate = useNavigate();
  const { setAuth } = useAuthStore();
  const { loadUserData } = useProgressStore();

  const [step, setStep] = useState<Step>('token');
  const [token, setToken] = useState('');
  const [repoName, setRepoName] = useState('algovault-progress');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [verifiedAuth, setVerifiedAuth] = useState<Omit<GitHubAuth, 'repoName'> | null>(null);

  const handleVerifyToken = async () => {
    if (!token.trim()) return;
    setLoading(true);
    setError('');
    try {
      const client = new GithubClient(token.trim());
      const user = await client.getUser();
      setVerifiedAuth({ token: token.trim(), user });
      setStep('repo');
    } catch {
      setError('Invalid token or insufficient permissions. Make sure the token has repo scope.');
    } finally {
      setLoading(false);
    }
  };

  const handleConnectRepo = async () => {
    if (!verifiedAuth || !repoName.trim()) return;
    setLoading(true);
    setError('');
    try {
      const auth: GitHubAuth = { ...verifiedAuth, repoName: repoName.trim() };
      const client = new GithubClient(auth.token);
      const storage = new GithubStorage(client, auth.user.login, auth.repoName);

      // Try to create repo if it doesn't exist
      const exists = await client.repoExists(auth.user.login, auth.repoName);
      if (!exists) await client.createRepo(auth.repoName);

      // Load existing data or create fresh
      const local = new LocalStorageAdapter();
      let userData = await local.load() ?? await storage.load();
      if (!userData) {
        userData = createInitialUserData(auth);
        await storage.save(userData);
      }

      setAuth(auth);
      loadUserData(userData);
      navigate('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to connect repository');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[var(--bg-base)] px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="mb-8 text-center">
          <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--bg-elevated)] border border-[var(--border-default)]">
            <Lock size={22} className="text-[var(--accent)]" />
          </div>
          <h1 className="text-xl font-semibold text-[var(--text-primary)]">AlgoVault</h1>
          <p className="mt-1 text-sm text-[var(--text-secondary)]">
            DSA progress tracker · Synced to GitHub
          </p>
        </div>

        {/* Steps indicator */}
        <div className="mb-6 flex items-center justify-center gap-2">
          {(['token', 'repo'] as Step[]).map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <div className={cn(
                'flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold',
                step === s
                  ? 'bg-[var(--accent)] text-[#0d1117]'
                  : (step === 'repo' && s === 'token')
                    ? 'bg-[var(--success)] text-[#0d1117]'
                    : 'bg-[var(--bg-elevated)] border border-[var(--border-default)] text-[var(--text-muted)]'
              )}>
                {step === 'repo' && s === 'token' ? <Check size={11} /> : i + 1}
              </div>
              {i === 0 && <div className="h-px w-8 bg-[var(--border-default)]" />}
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-[var(--border-default)] bg-[var(--bg-elevated)] p-6">
          {step === 'token' ? (
            <>
              <div className="mb-4">
                <h2 className="text-sm font-semibold text-[var(--text-primary)]">GitHub Token</h2>
                <p className="mt-1 text-xs text-[var(--text-secondary)]">
                  Create a Personal Access Token with <code className="rounded bg-[var(--bg-overlay)] px-1 py-0.5 font-mono text-[var(--accent)]">repo</code> scope at{' '}
                  <a href="https://github.com/settings/tokens" target="_blank" rel="noopener noreferrer"
                    className="text-[var(--accent)] underline underline-offset-2">
                    github.com/settings/tokens
                  </a>
                </p>
              </div>

              <div className="space-y-3">
                <Input
                  type="password"
                  placeholder="ghp_xxxxxxxxxxxx"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleVerifyToken()}
                  iconLeft={<Github size={14} />}
                  autoComplete="off"
                  spellCheck={false}
                />
                {error && (
                  <p className="flex items-center gap-1.5 text-xs text-[var(--danger)]">
                    <AlertCircle size={12} /> {error}
                  </p>
                )}
                <Button
                  variant="primary"
                  className="w-full"
                  loading={loading}
                  iconRight={<ArrowRight size={14} />}
                  onClick={handleVerifyToken}
                  disabled={!token.trim()}
                >
                  Verify Token
                </Button>
              </div>

              <p className="mt-4 text-[11px] text-[var(--text-muted)]">
                Your token is stored only in this browser's localStorage and never sent anywhere except GitHub's API.
              </p>
            </>
          ) : (
            <>
              {verifiedAuth && (
                <div className="mb-4 flex items-center gap-3 rounded-lg bg-[var(--success-subtle)] border border-[color-mix(in_srgb,var(--success)_30%,transparent)] p-3">
                  <img src={verifiedAuth.user.avatar_url} className="h-8 w-8 rounded-full" alt="" />
                  <div>
                    <p className="text-sm font-medium text-[var(--text-primary)]">
                      {verifiedAuth.user.name ?? verifiedAuth.user.login}
                    </p>
                    <p className="text-xs text-[var(--text-muted)]">@{verifiedAuth.user.login}</p>
                  </div>
                  <Check size={16} className="ml-auto text-[var(--success)]" />
                </div>
              )}

              <div className="mb-4">
                <h2 className="text-sm font-semibold text-[var(--text-primary)]">Repository</h2>
                <p className="mt-1 text-xs text-[var(--text-secondary)]">
                  Choose a private repo name. It will be created automatically if it doesn't exist.
                </p>
              </div>

              <div className="space-y-3">
                <Input
                  placeholder="algovault-progress"
                  value={repoName}
                  onChange={(e) => setRepoName(e.target.value.toLowerCase().replace(/\s+/g, '-'))}
                  onKeyDown={(e) => e.key === 'Enter' && handleConnectRepo()}
                />
                {error && (
                  <p className="flex items-center gap-1.5 text-xs text-[var(--danger)]">
                    <AlertCircle size={12} /> {error}
                  </p>
                )}
                <Button
                  variant="primary"
                  className="w-full"
                  loading={loading}
                  onClick={handleConnectRepo}
                  disabled={!repoName.trim()}
                >
                  {loading ? 'Connecting…' : 'Launch AlgoVault'}
                </Button>
                <button
                  onClick={() => { setStep('token'); setError(''); }}
                  className="w-full text-xs text-[var(--text-muted)] hover:text-[var(--text-secondary)] transition-colors"
                >
                  ← Back
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
