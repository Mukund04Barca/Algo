import { useState } from 'react';
import { Github, ArrowRight, Check, AlertCircle, X } from 'lucide-react';
import { useAuthStore, useProgressStore } from '@/store';
import { GithubClient } from '@/services/github/GithubClient';
import { GithubStorage } from '@/services/github/GithubStorage';
import { Button } from '@/shared/ui/Button/Button';
import { Input } from '@/shared/ui/Input/Input';
import { cn } from '@/lib/utils';
import type { GitHubAuth } from '@/types';

type Step = 'token' | 'repo';

interface Props {
  onClose: () => void;
}

export function GithubConnectModal({ onClose }: Props) {
  const { setAuth } = useAuthStore();
  const { userData, loadUserData } = useProgressStore();

  const [step, setStep] = useState<Step>('token');
  const [token, setToken] = useState('');
  const [repoName, setRepoName] = useState('algovault-progress');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [verifiedAuth, setVerifiedAuth] = useState<Omit<GitHubAuth, 'repoName'> | null>(null);

  const handleVerifyToken = async () => {
    if (!token.trim()) return;
    setLoading(true);
    setError('');
    try {
      const client = new GithubClient(token.trim());
      const user = await client.getUser();
      setVerifiedAuth({ token: token.trim(), user });
      setStep('repo');
    } catch {
      setError('Invalid token or missing repo scope.');
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async () => {
    if (!verifiedAuth || !repoName.trim()) return;
    setLoading(true);
    setError('');
    try {
      const auth: GitHubAuth = { ...verifiedAuth, repoName: repoName.trim() };
      const client = new GithubClient(auth.token);
      const storage = new GithubStorage(client, auth.user.login, auth.repoName);

      const exists = await client.repoExists(auth.user.login, auth.repoName);
      if (!exists) await client.createRepo(auth.repoName);

      // Load existing GitHub data or migrate current local progress
      const remoteData = await storage.load();
      const dataToUse = remoteData ?? {
        ...userData,
        profile: {
          githubLogin: auth.user.login,
          githubName: auth.user.name ?? auth.user.login,
          avatarUrl: auth.user.avatar_url,
          repoName: auth.repoName,
        },
        updatedAt: new Date().toISOString(),
      };

      // If no remote data existed, push local progress up
      if (!remoteData) {
        await storage.save(dataToUse);
      }

      setAuth(auth);
      loadUserData(dataToUse);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Connection failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md mx-4">
        <div className="rounded-xl border border-[var(--border-default)] bg-[var(--bg-elevated)] shadow-2xl">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[var(--border-default)] px-5 py-4">
            <div>
              <h2 className="text-sm font-semibold text-[var(--text-primary)]">Connect GitHub</h2>
              <p className="text-xs text-[var(--text-muted)] mt-0.5">
                Your local progress will sync to a private repo
              </p>
            </div>
            <button
              onClick={onClose}
              className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--text-muted)] hover:bg-[var(--bg-overlay)] hover:text-[var(--text-primary)] transition-colors"
            >
              <X size={14} />
            </button>
          </div>

          <div className="p-5">
            {/* Step indicators */}
            <div className="flex items-center gap-2 mb-5">
              {(['token', 'repo'] as Step[]).map((s, i) => (
                <div key={s} className="flex items-center gap-2">
                  <div className={cn(
                    'flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold',
                    step === s ? 'bg-[var(--accent)] text-[#0d1117]'
                      : step === 'repo' && s === 'token' ? 'bg-[var(--success)] text-[#0d1117]'
                      : 'bg-[var(--bg-overlay)] border border-[var(--border-default)] text-[var(--text-muted)]'
                  )}>
                    {step === 'repo' && s === 'token' ? <Check size={10} /> : i + 1}
                  </div>
                  {i === 0 && <div className="h-px w-6 bg-[var(--border-default)]" />}
                </div>
              ))}
              <span className="ml-1 text-xs text-[var(--text-muted)]">
                {step === 'token' ? 'Personal Access Token' : 'Repository Name'}
              </span>
            </div>

            {step === 'token' ? (
              <div className="space-y-3">
                <p className="text-xs text-[var(--text-secondary)]">
                  Create a token with <code className="rounded bg-[var(--bg-overlay)] px-1 font-mono text-[var(--accent)]">repo</code> scope at{' '}
                  <a href="https://github.com/settings/tokens/new" target="_blank" rel="noopener noreferrer"
                    className="text-[var(--accent)] underline underline-offset-2">
                    github.com/settings/tokens
                  </a>
                </p>
                <Input
                  type="password"
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleVerifyToken()}
                  iconLeft={<Github size={13} />}
                  autoComplete="off"
                  spellCheck={false}
                />
                {error && (
                  <p className="flex items-center gap-1.5 text-xs text-[var(--danger)]">
                    <AlertCircle size={12} /> {error}
                  </p>
                )}
                <Button
                  variant="primary"
                  className="w-full"
                  loading={loading}
                  iconRight={<ArrowRight size={13} />}
                  onClick={handleVerifyToken}
                  disabled={!token.trim()}
                >
                  Verify Token
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {verifiedAuth && (
                  <div className="flex items-center gap-2.5 rounded-lg bg-[var(--success-subtle)] border border-[color-mix(in_srgb,var(--success)_25%,transparent)] p-2.5">
                    <img src={verifiedAuth.user.avatar_url} className="h-7 w-7 rounded-full" alt="" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-[var(--text-primary)]">
                        {verifiedAuth.user.name ?? verifiedAuth.user.login}
                      </p>
                      <p className="text-[11px] text-[var(--text-muted)]">@{verifiedAuth.user.login}</p>
                    </div>
                    <Check size={14} className="text-[var(--success)] shrink-0" />
                  </div>
                )}
                <p className="text-xs text-[var(--text-secondary)]">
                  Your local progress will be uploaded. Existing remote data takes priority.
                </p>
                <Input
                  placeholder="algovault-progress"
                  value={repoName}
                  onChange={(e) => setRepoName(e.target.value.toLowerCase().replace(/\s+/g, '-'))}
                  onKeyDown={(e) => e.key === 'Enter' && handleConnect()}
                />
                {error && (
                  <p className="flex items-center gap-1.5 text-xs text-[var(--danger)]">
                    <AlertCircle size={12} /> {error}
                  </p>
                )}
                <Button
                  variant="primary"
                  className="w-full"
                  loading={loading}
                  onClick={handleConnect}
                  disabled={!repoName.trim()}
                >
                  {loading ? 'Connecting…' : 'Connect & Sync'}
                </Button>
                <button
                  onClick={() => { setStep('token'); setError(''); }}
                  className="w-full text-xs text-[var(--text-muted)] hover:text-[var(--text-secondary)] transition-colors"
                >
                  ← Back
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
