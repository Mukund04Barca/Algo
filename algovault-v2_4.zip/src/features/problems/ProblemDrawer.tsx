import { useState, useEffect } from 'react';
import {
  X, ExternalLink, Star, ChevronDown, ChevronUp,
  BookOpen, CheckCircle2, RotateCcw, Brain, Trophy
} from 'lucide-react';
import type { Problem, ProblemProgress, ProblemStatus } from '@/types';
import { useProgressStore } from '@/store';
import { Button } from '@/shared/ui/Button/Button';
import { DifficultyBadge } from '@/shared/ui/Badge/Badge';
import { cn } from '@/lib/utils';
import { DEFAULT_EASE_FACTOR } from '@/features/revision/RevisionEngine';

interface ProblemDrawerProps {
  problem: Problem;
  progress: ProblemProgress | undefined;
  onClose: () => void;
}

const STATUS_OPTIONS: { value: ProblemStatus; label: string; icon: React.ReactNode; color: string }[] = [
  { value: 'Not Started', label: 'Not Started', icon: <RotateCcw size={13} />, color: 'text-[var(--text-muted)]' },
  { value: 'Learning', label: 'Learning', icon: <BookOpen size={13} />, color: 'text-[var(--purple)]' },
  { value: 'Solved', label: 'Solved', icon: <CheckCircle2 size={13} />, color: 'text-[var(--accent)]' },
  { value: 'Needs Revision', label: 'Needs Revision', icon: <Brain size={13} />, color: 'text-[var(--warning)]' },
  { value: 'Mastered', label: 'Mastered', icon: <Trophy size={13} />, color: 'text-[var(--success)]' },
];

function createInitialProgress(problemId: string): ProblemProgress {
  const now = new Date().toISOString();
  return {
    problemId,
    status: 'Not Started',
    confidence: 3,
    attempts: 0,
    timeTaken: 0,
    notes: '',
    mistakes: '',
    solutions: [],
    reviewHistory: [],
    nextReview: null,
    easeFactor: DEFAULT_EASE_FACTOR,
    interval: 0,
    lastSolved: null,
    favorite: false,
    createdAt: now,
    updatedAt: now,
  };
}

export function ProblemDrawer({ problem, progress, onClose }: ProblemDrawerProps) {
  const { updateProgress, markActivity } = useProgressStore();

  const [status, setStatus] = useState<ProblemStatus>(progress?.status ?? 'Not Started');
  const [confidence, setConfidence] = useState(progress?.confidence ?? 3);
  const [notes, setNotes] = useState(progress?.notes ?? '');
  const [notesOpen, setNotesOpen] = useState(false);
  const [dirty, setDirty] = useState(false);

  // Keep local state in sync if a different problem is selected
  useEffect(() => {
    setStatus(progress?.status ?? 'Not Started');
    setConfidence(progress?.confidence ?? 3);
    setNotes(progress?.notes ?? '');
    setDirty(false);
    setNotesOpen(false);
  }, [problem.id, progress]);

  function handleStatusChange(newStatus: ProblemStatus) {
    setStatus(newStatus);
    setDirty(true);
  }

  function handleSave() {
    const base = progress ?? createInitialProgress(problem.id);
    const isSolving = (status === 'Solved' || status === 'Mastered') && base.status !== 'Solved' && base.status !== 'Mastered';

    updateProgress(problem.id, {
      ...base,
      status,
      confidence,
      notes,
      attempts: isSolving ? base.attempts + 1 : base.attempts,
      lastSolved: isSolving ? new Date().toISOString() : base.lastSolved,
    });

    if (isSolving) markActivity();
    setDirty(false);
  }

  function handleToggleFavorite() {
    const base = progress ?? createInitialProgress(problem.id);
    updateProgress(problem.id, { ...base, favorite: !base.favorite });
  }

  const isFavorite = progress?.favorite ?? false;
  const attempts = progress?.attempts ?? 0;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40 bg-black/40 backdrop-blur-[2px]"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="fixed right-0 top-0 z-50 h-full w-full max-w-[460px] flex flex-col bg-[var(--bg-elevated)] border-l border-[var(--border-default)] shadow-2xl">

        {/* Header */}
        <div className="flex items-start gap-3 border-b border-[var(--border-default)] px-5 py-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <DifficultyBadge difficulty={problem.difficulty} />
              {problem.isPremium && (
                <span className="rounded-md bg-[var(--warning-subtle)] px-1.5 py-0.5 text-[10px] text-[var(--warning)]">
                  Premium
                </span>
              )}
            </div>
            <h2 className="mt-1.5 text-base font-semibold text-[var(--text-primary)] leading-tight">
              {problem.title}
            </h2>
            <p className="mt-0.5 text-xs text-[var(--text-muted)]">{problem.topic}</p>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={handleToggleFavorite}
              className={cn(
                'flex h-7 w-7 items-center justify-center rounded-md transition-colors',
                isFavorite ? 'text-[var(--warning)]' : 'text-[var(--text-muted)] hover:text-[var(--warning)]'
              )}
              title={isFavorite ? 'Unfavorite' : 'Favorite'}
            >
              <Star size={14} fill={isFavorite ? 'currentColor' : 'none'} />
            </button>
            <button
              onClick={onClose}
              className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--text-muted)] hover:bg-[var(--bg-overlay)] hover:text-[var(--text-primary)] transition-colors"
            >
              <X size={14} />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">

          {/* Links */}
          <div className="flex gap-2 flex-wrap">
            {problem.link && (
              <a
                href={problem.link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-md border border-[var(--border-default)] bg-[var(--bg-overlay)] px-3 py-1.5 text-xs font-medium text-[var(--text-secondary)] hover:border-[var(--accent)] hover:text-[var(--accent)] transition-colors"
              >
                <ExternalLink size={11} />
                Open on {problem.platform}
              </a>
            )}
          </div>

          {/* Status */}
          <div>
            <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">Status</div>
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
              {STATUS_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => handleStatusChange(opt.value)}
                  className={cn(
                    'flex items-center gap-2 rounded-md border px-3 py-2 text-xs font-medium transition-colors text-left',
                    status === opt.value
                      ? 'border-[var(--accent)] bg-[var(--accent-subtle)] text-[var(--accent)]'
                      : 'border-[var(--border-default)] bg-[var(--bg-overlay)] text-[var(--text-secondary)] hover:border-[var(--border-emphasis)]'
                  )}
                >
                  <span className={status === opt.value ? 'text-[var(--accent)]' : opt.color}>
                    {opt.icon}
                  </span>
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Confidence — only relevant once attempted */}
          {(status === 'Solved' || status === 'Mastered' || status === 'Needs Revision') && (
            <div>
              <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">
                Confidence <span className="text-[var(--text-muted)] font-normal">(affects revision schedule)</span>
              </div>
              <div className="flex gap-1.5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    onClick={() => { setConfidence(n); setDirty(true); }}
                    className={cn(
                      'flex-1 rounded-md border py-2 text-xs font-semibold tabular-nums transition-colors',
                      confidence === n
                        ? n <= 2 ? 'border-[var(--danger)] bg-[var(--danger-subtle)] text-[var(--danger)]'
                          : n === 3 ? 'border-[var(--warning)] bg-[var(--warning-subtle)] text-[var(--warning)]'
                          : 'border-[var(--success)] bg-[var(--success-subtle)] text-[var(--success)]'
                        : 'border-[var(--border-default)] bg-[var(--bg-overlay)] text-[var(--text-muted)] hover:border-[var(--border-emphasis)]'
                    )}
                  >
                    {n}
                  </button>
                ))}
              </div>
              <div className="mt-1 flex justify-between text-[10px] text-[var(--text-muted)]">
                <span>Couldn't do it</span>
                <span>Perfect</span>
              </div>
            </div>
          )}

          {/* Tags */}
          {problem.tags.length > 0 && (
            <div>
              <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">Tags</div>
              <div className="flex flex-wrap gap-1.5">
                {problem.tags.map((tag) => (
                  <span key={tag} className="rounded-full bg-[var(--bg-overlay)] border border-[var(--border-muted)] px-2.5 py-0.5 text-[11px] text-[var(--text-secondary)]">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Companies */}
          {problem.companies.length > 0 && (
            <div>
              <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">Asked at</div>
              <div className="flex flex-wrap gap-1.5">
                {problem.companies.map((c) => (
                  <span key={c} className="rounded-full bg-[var(--accent-subtle)] px-2.5 py-0.5 text-[11px] text-[var(--accent)]">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          <div>
            <button
              onClick={() => setNotesOpen((o) => !o)}
              className="flex w-full items-center justify-between text-xs font-semibold text-[var(--text-secondary)] mb-2"
            >
              Notes {notes && <span className="text-[var(--accent)] font-normal">Saved</span>}
              {notesOpen ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
            </button>
            {notesOpen && (
              <textarea
                value={notes}
                onChange={(e) => { setNotes(e.target.value); setDirty(true); }}
                placeholder="Approach, edge cases, key insight…"
                rows={5}
                className="w-full rounded-md border border-[var(--border-default)] bg-[var(--bg-overlay)] px-3 py-2 text-xs text-[var(--text-primary)] placeholder:text-[var(--text-muted)] outline-none focus:border-[var(--accent)] resize-none font-mono"
              />
            )}
          </div>

          {/* Meta */}
          {attempts > 0 && (
            <div className="rounded-md bg-[var(--bg-overlay)] px-3 py-2 text-[11px] text-[var(--text-muted)]">
              Attempted {attempts} time{attempts !== 1 ? 's' : ''}
              {progress?.lastSolved && ` · Last solved ${new Date(progress.lastSolved).toLocaleDateString()}`}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-[var(--border-default)] px-5 py-3 flex items-center justify-between gap-3">
          <span className="text-[11px] text-[var(--text-muted)]">
            {dirty ? 'Unsaved changes' : progress ? 'Saved locally' : 'Not tracked yet'}
          </span>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={onClose}>Cancel</Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleSave}
              disabled={!dirty && !!progress}
            >
              Save
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
