import { useState, useMemo } from 'react';
import { ChevronRight, CheckCircle2 } from 'lucide-react';
import type { RoadmapTopic, ProblemProgress, Problem } from '@/types';
import { DifficultyBadge, StatusBadge } from '@/shared/ui/Badge/Badge';
import { Progress } from '@/shared/ui/Progress/Progress';
import { cn } from '@/lib/utils';

interface TopicRowProps {
  topic: RoadmapTopic;
  progress: Record<string, ProblemProgress>;
  onSelectProblem: (p: Problem) => void;
  defaultOpen?: boolean;
}

export function TopicRow({ topic, progress, onSelectProblem, defaultOpen = false }: TopicRowProps) {
  const [open, setOpen] = useState(defaultOpen);

  const stats = useMemo(() => {
    const solved = topic.problems.filter((p) => {
      const s = progress[p.id]?.status;
      return s === 'Solved' || s === 'Mastered';
    }).length;
    return { solved, total: topic.problems.length, pct: Math.round((solved / topic.problems.length) * 100) };
  }, [topic, progress]);

  const allDone = stats.solved === stats.total && stats.total > 0;

  return (
    <div>
      {/* Topic header */}
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-3 px-6 py-3 hover:bg-[var(--bg-elevated)] transition-colors text-left"
      >
        <ChevronRight
          size={14}
          className={cn(
            'shrink-0 text-[var(--text-muted)] transition-transform duration-150',
            open && 'rotate-90'
          )}
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={cn(
              'text-sm font-medium',
              allDone ? 'text-[var(--success)]' : 'text-[var(--text-primary)]'
            )}>
              {topic.name}
            </span>
            {allDone && <CheckCircle2 size={13} className="text-[var(--success)] shrink-0" />}
          </div>
          <div className="mt-1 flex items-center gap-3">
            <Progress
              value={stats.pct}
              color={stats.pct === 100 ? 'success' : stats.pct >= 50 ? 'accent' : 'purple'}
              className="w-32"
            />
            <span className="text-[11px] tabular-nums text-[var(--text-muted)]">
              {stats.solved}/{stats.total}
            </span>
          </div>
        </div>
      </button>

      {/* Problem list */}
      {open && (
        <div className="border-t border-[var(--border-muted)]">
          {topic.problems.map((problem, i) => {
            const prog = progress[problem.id];
            const status = prog?.status ?? 'Not Started';
            const isSolved = status === 'Solved' || status === 'Mastered';

            return (
              <button
                key={problem.id}
                onClick={() => onSelectProblem(problem)}
                className={cn(
                  'flex w-full items-center gap-4 px-6 py-2.5 text-left',
                  'hover:bg-[var(--bg-elevated)] transition-colors',
                  'border-b border-[var(--border-muted)] last:border-0'
                )}
              >
                {/* Row number / checkmark */}
                <span className="w-7 shrink-0 text-center">
                  {isSolved ? (
                    <CheckCircle2 size={14} className="mx-auto text-[var(--success)]" />
                  ) : (
                    <span className="text-[11px] tabular-nums text-[var(--text-muted)]">{i + 1}</span>
                  )}
                </span>

                {/* Title */}
                <span className={cn(
                  'flex-1 text-sm',
                  isSolved ? 'text-[var(--text-muted)] line-through decoration-[var(--border-emphasis)]' : 'text-[var(--text-primary)]'
                )}>
                  {problem.title}
                  {problem.isPremium && (
                    <span className="ml-1.5 text-[10px] text-[var(--warning)]">★</span>
                  )}
                </span>

                {/* Tags (first 2) */}
                <div className="hidden sm:flex items-center gap-1">
                  {problem.tags.slice(0, 2).map((tag) => (
                    <span key={tag} className="rounded-full bg-[var(--bg-overlay)] px-2 py-0.5 text-[10px] text-[var(--text-muted)]">
                      {tag}
                    </span>
                  ))}
                </div>

                <DifficultyBadge difficulty={problem.difficulty} />
                <div className="w-28 shrink-0">
                  <StatusBadge status={status} />
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
