import { describe, it, expect } from 'vitest';
import {
  computeNextReview,
  isDue,
  daysOverdue,
  averageConfidence,
  retentionScore,
  DEFAULT_EASE_FACTOR,
  MIN_EASE_FACTOR,
} from './RevisionEngine';

describe('computeNextReview', () => {
  it('resets interval on low confidence (1)', () => {
    const result = computeNextReview(1, 30, DEFAULT_EASE_FACTOR);
    expect(result.newInterval).toBe(1);
    expect(result.newEaseFactor).toBeLessThan(DEFAULT_EASE_FACTOR);
  });

  it('never drops ease factor below minimum', () => {
    const result = computeNextReview(1, 0, MIN_EASE_FACTOR);
    expect(result.newEaseFactor).toBeGreaterThanOrEqual(MIN_EASE_FACTOR);
  });

  it('returns 1-day interval for first review', () => {
    const result = computeNextReview(5, 0);
    expect(result.newInterval).toBe(1);
  });

  it('returns 3-day interval for second review', () => {
    const result = computeNextReview(5, 1);
    expect(result.newInterval).toBe(3);
  });

  it('multiplies by ease factor after second review', () => {
    const result = computeNextReview(5, 3, 2.5);
    expect(result.newInterval).toBe(Math.round(3 * 2.5));
  });

  it('sets next review date in the future', () => {
    const result = computeNextReview(4, 7);
    expect(result.nextReview.getTime()).toBeGreaterThan(Date.now());
  });

  it('increases ease factor on perfect confidence', () => {
    const result = computeNextReview(5, 7, DEFAULT_EASE_FACTOR);
    expect(result.newEaseFactor).toBeGreaterThan(DEFAULT_EASE_FACTOR);
  });
});

describe('isDue', () => {
  it('returns false for null', () => {
    expect(isDue(null)).toBe(false);
  });

  it('returns true for past date', () => {
    const past = new Date(Date.now() - 86_400_000).toISOString();
    expect(isDue(past)).toBe(true);
  });

  it('returns false for future date', () => {
    const future = new Date(Date.now() + 86_400_000).toISOString();
    expect(isDue(future)).toBe(false);
  });
});

describe('daysOverdue', () => {
  it('returns 0 for null', () => {
    expect(daysOverdue(null)).toBe(0);
  });

  it('returns 0 for future date', () => {
    const future = new Date(Date.now() + 86_400_000).toISOString();
    expect(daysOverdue(future)).toBe(0);
  });

  it('returns correct days for overdue', () => {
    const threeDaysAgo = new Date(Date.now() - 3 * 86_400_000).toISOString();
    expect(daysOverdue(threeDaysAgo)).toBe(3);
  });
});

describe('averageConfidence', () => {
  it('returns 0 for empty history', () => {
    expect(averageConfidence([])).toBe(0);
  });

  it('computes mean correctly', () => {
    const history = [
      { reviewedAt: new Date().toISOString(), confidence: 4 },
      { reviewedAt: new Date().toISOString(), confidence: 2 },
    ];
    expect(averageConfidence(history)).toBe(3);
  });
});

describe('retentionScore', () => {
  it('returns 0 for no reviews', () => {
    expect(retentionScore(0, DEFAULT_EASE_FACTOR)).toBe(0);
  });

  it('caps at 100', () => {
    expect(retentionScore(100, 4)).toBe(100);
  });
});
