import type { ReviewEvent } from '@/types';

/**
 * RevisionEngine — pure functions, zero React, fully testable.
 *
 * Implements a simplified SM-2 spaced repetition algorithm.
 * https://www.supermemo.com/en/archives1990-2015/english/ol/sm2
 */

export const DEFAULT_EASE_FACTOR = 2.5;
export const MIN_EASE_FACTOR = 1.3;

/** Base intervals in days for each review step. */
export const SM2_INTERVALS = [1, 3, 7, 15, 30, 60] as const;

export interface ReviewResult {
  nextReview: Date;
  newInterval: number;
  newEaseFactor: number;
}

/**
 * Compute next review date using SM-2.
 *
 * @param confidence  User's self-rated confidence 1–5.
 * @param interval    Current interval in days (0 = first review).
 * @param easeFactor  Current ease factor (default 2.5).
 */
export function computeNextReview(
  confidence: number,
  interval: number,
  easeFactor: number = DEFAULT_EASE_FACTOR
): ReviewResult {
  // SM-2 quality mapping: confidence 1-5 → quality 0-5
  const quality = Math.round(((confidence - 1) / 4) * 5);

  let newInterval: number;
  let newEaseFactor: number;

  if (quality < 3) {
    // Failed recall — reset interval
    newInterval = 1;
    newEaseFactor = Math.max(MIN_EASE_FACTOR, easeFactor - 0.2);
  } else {
    if (interval === 0) {
      newInterval = 1;
    } else if (interval === 1) {
      newInterval = 3;
    } else {
      newInterval = Math.round(interval * easeFactor);
    }
    // SM-2 ease factor update
    newEaseFactor = Math.max(
      MIN_EASE_FACTOR,
      easeFactor + 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)
    );
  }

  const nextReview = new Date();
  nextReview.setDate(nextReview.getDate() + newInterval);

  return { nextReview, newInterval, newEaseFactor };
}

/** Is a problem due for review right now? */
export function isDue(nextReview: string | null): boolean {
  if (!nextReview) return false;
  return new Date(nextReview) <= new Date();
}

/** How many days overdue is a review? (0 if not overdue) */
export function daysOverdue(nextReview: string | null): number {
  if (!nextReview) return 0;
  const diff = Date.now() - new Date(nextReview).getTime();
  return Math.max(0, Math.floor(diff / 86_400_000));
}

/** Average confidence from review history. */
export function averageConfidence(history: ReviewEvent[]): number {
  if (history.length === 0) return 0;
  return history.reduce((sum, e) => sum + e.confidence, 0) / history.length;
}

/** Retention score 0–100 based on history length and ease factor. */
export function retentionScore(
  reviewCount: number,
  easeFactor: number
): number {
  if (reviewCount === 0) return 0;
  const base = Math.min(100, reviewCount * 15);
  const ease = ((easeFactor - MIN_EASE_FACTOR) / (4 - MIN_EASE_FACTOR)) * 20;
  return Math.round(Math.min(100, base + ease));
}
