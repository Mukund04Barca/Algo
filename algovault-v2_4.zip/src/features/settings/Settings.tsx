import { useState } from 'react';
import { Settings as SettingsIcon, Github, LogOut, Download, RefreshCw, Check, Cloud } from 'lucide-react';
import { useAuthStore, useProgressStore } from '@/store';
import { Card } from '@/shared/ui/Card/Card';
import { Button } from '@/shared/ui/Button/Button';
import { useGithubSync } from '@/hooks';
import { GithubConnectModal } from '@/features/auth/GithubConnectModal';

export default function Settings() {
  const { auth, clearAuth } = useAuthStore();
  const { userData } = useProgressStore();
  const { syncNow } = useGithubSync();
  const [synced, setSynced] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [showConnect, setShowConnect] = useState(false);

  const handleSync = async () => {
    setSyncing(true);
    await syncNow();
    setSyncing(false);
    setSynced(true);
    setTimeout(() => setSynced(false), 3000);
  };

  const handleExport = () => {
    const blob = new Blob([JSON.stringify(userData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `algovault-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <div className="p-6 max-w-[600px] space-y-4">
        <div className="flex items-center gap-2 mb-5">
          <SettingsIcon size={18} className="text-[var(--accent)]" />
          <h1 className="text-lg font-semibold text-[var(--text-primary)]">Settings</h1>
        </div>

        {/* GitHub Sync */}
        <Card>
          <div className="mb-3 text-xs font-semibold text-[var(--text-secondary)]">GitHub Sync</div>
          {auth ? (
            <>
              <div className="flex items-center gap-3 mb-4">
                <img src={auth.user.avatar_url} className="h-10 w-10 rounded-full border border-[var(--border-default)]" alt="" />
                <div>
                  <div className="text-sm font-medium text-[var(--text-primary)]">{auth.user.name ?? auth.user.login}</div>
                  <div className="text-xs text-[var(--text-muted)]">@{auth.user.login} · {auth.repoName}</div>
                </div>
                <a href={`https://github.com/${auth.user.login}/${auth.repoName}`} target="_blank" rel="noopener noreferrer"
                  className="ml-auto text-xs text-[var(--accent)] hover:underline flex items-center gap-1">
                  <Github size={12} /> View Repo
                </a>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  iconLeft={synced ? <Check size={12} /> : <RefreshCw size={12} className={syncing ? 'animate-spin' : ''} />}
                  onClick={handleSync}
                  loading={syncing}
                >
                  {synced ? 'Synced!' : 'Sync Now'}
                </Button>
                <Button variant="secondary" size="sm" iconLeft={<Download size={12} />} onClick={handleExport}>
                  Export JSON
                </Button>
              </div>
            </>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-[var(--text-secondary)]">
                Connect GitHub to sync your progress across devices and keep a permanent backup.
              </p>
              <Button
                variant="secondary"
                size="sm"
                iconLeft={<Cloud size={12} />}
                onClick={() => setShowConnect(true)}
              >
                Connect GitHub
              </Button>
            </div>
          )}
        </Card>

        {/* Data */}
        <Card>
          <div className="mb-3 text-xs font-semibold text-[var(--text-secondary)]">Data</div>
          <div className="space-y-2 text-xs text-[var(--text-secondary)]">
            <div className="flex justify-between"><span>Version</span><span className="text-[var(--text-muted)]">{userData.version}</span></div>
            <div className="flex justify-between"><span>Last updated</span><span className="text-[var(--text-muted)]">{new Date(userData.updatedAt).toLocaleString()}</span></div>
            <div className="flex justify-between"><span>Storage</span><span className="text-[var(--text-muted)]">{auth ? 'localStorage + GitHub' : 'localStorage (guest)'}</span></div>
          </div>
          <div className="mt-3">
            <Button variant="ghost" size="sm" iconLeft={<Download size={12} />} onClick={handleExport}>
              Export JSON
            </Button>
          </div>
        </Card>

        {/* Danger Zone — only if authed */}
        {auth && (
          <Card className="border-[color-mix(in_srgb,var(--danger)_30%,transparent)]">
            <div className="mb-3 text-xs font-semibold text-[var(--danger)]">Danger Zone</div>
            <Button variant="danger" size="sm" iconLeft={<LogOut size={12} />} onClick={clearAuth}>
              Disconnect GitHub
            </Button>
            <p className="mt-2 text-[11px] text-[var(--text-muted)]">
              Removes your token from this browser. GitHub data is preserved. App continues in guest mode.
            </p>
          </Card>
        )}
      </div>

      {showConnect && <GithubConnectModal onClose={() => setShowConnect(false)} />}
    </>
  );
}
