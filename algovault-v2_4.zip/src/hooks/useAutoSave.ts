import { useEffect, useRef } from 'react';
import { useProgressStore } from '@/store';
import { LocalStorageAdapter } from '@/services/storage/LocalStorageAdapter';

const DEBOUNCE_MS = 800;

/**
 * useAutoSave — watches userData and persists to localStorage automatically.
 * Call once at the AppShell level. No component needs to think about saving.
 */
export function useAutoSave() {
  const { userData } = useProgressStore();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const adapter = useRef(new LocalStorageAdapter());

  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      adapter.current.save(userData);
    }, DEBOUNCE_MS);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [userData]);
}
