import { useEffect } from 'react';
import { useAuthStore, useProgressStore } from '@/store';
import { LocalStorageAdapter } from '@/services/storage/LocalStorageAdapter';
import { GithubClient } from '@/services/github/GithubClient';
import { GithubStorage } from '@/services/github/GithubStorage';

/**
 * useBootstrap — runs once on app mount.
 *
 * Priority order:
 * 1. If GitHub auth exists → load from GitHub (source of truth)
 * 2. Else if localStorage has data → load that
 * 3. Else → keep the default guest UserData already in the store
 */
export function useBootstrap() {
  const { auth } = useAuthStore();
  const { loadUserData } = useProgressStore();

  useEffect(() => {
    async function init() {
      const local = new LocalStorageAdapter();

      if (auth) {
        // Try GitHub first, fall back to local
        try {
          const client = new GithubClient(auth.token);
          const github = new GithubStorage(client, auth.user.login, auth.repoName);
          const data = await github.load() ?? await local.load();
          if (data) loadUserData(data);
        } catch {
          const data = await local.load();
          if (data) loadUserData(data);
        }
      } else {
        // Guest mode: load from localStorage if available
        const data = await local.load();
        if (data) loadUserData(data);
      }
    }

    init();
    // Only run on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
