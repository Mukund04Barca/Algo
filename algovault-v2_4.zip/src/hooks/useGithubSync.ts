import { useRef, useCallback } from 'react';
import { useAuthStore, useProgressStore } from '@/store';
import { GithubClient } from '@/services/github/GithubClient';
import { GithubStorage } from '@/services/github/GithubStorage';
import { LocalStorageAdapter } from '@/services/storage/LocalStorageAdapter';

const DEBOUNCE_MS = 2500;

/**
 * useGithubSync
 *
 * 1. Debounces saves (2.5s after last change)
 * 2. Writes to localStorage immediately (optimistic)
 * 3. Syncs to GitHub in background
 * 4. Updates sync status in progressStore
 */
export function useGithubSync() {
  const { auth } = useAuthStore();
  const { userData, setSyncing, setSyncError, setSyncSuccess } = useProgressStore();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const sync = useCallback(async () => {
    if (!userData) return;

    // Instantiate inside callback — no stale closure on the adapter
    const localAdapter = new LocalStorageAdapter();
    await localAdapter.save(userData);

    if (!auth) return;

    setSyncing(true);
    try {
      const client = new GithubClient(auth.token);
      const storage = new GithubStorage(client, auth.user.login, auth.repoName);
      await storage.save(userData);
      setSyncSuccess();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown sync error';
      setSyncError(message);
    }
  }, [userData, auth, setSyncing, setSyncError, setSyncSuccess]);

  const debouncedSync = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(sync, DEBOUNCE_MS);
  }, [sync]);

  const syncNow = useCallback(async () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    await sync();
  }, [sync]);

  return { debouncedSync, syncNow };
}
