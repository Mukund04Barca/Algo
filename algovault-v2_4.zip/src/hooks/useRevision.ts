import { useEffect } from 'react';
import { useProgressStore, useRevisionStore } from '@/store';
import { useRoadmaps } from './useRoadmaps';

/**
 * useRevision — populates revisionStore from current progress.
 * Call once at app level or on the Revision page.
 */
export function useRevision() {
  const { userData } = useProgressStore();
  const { computeDue } = useRevisionStore();
  const { allProblems } = useRoadmaps();

  useEffect(() => {
    if (!userData || allProblems.length === 0) return;
    computeDue(allProblems, userData.progress);
  }, [userData, allProblems, computeDue]);
}
