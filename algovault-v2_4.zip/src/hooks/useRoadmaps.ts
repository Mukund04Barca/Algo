import { useMemo } from 'react';
import type { Problem, Roadmap } from '@/types';
import { loadAllRoadmaps } from '@/data/roadmaps/RoadmapLoader';

let _cache: { roadmaps: Roadmap[]; allProblems: Problem[] } | null = null;

/**
 * useRoadmaps — returns all loaded, validated roadmaps.
 * Cached after first call — roadmap data never changes at runtime.
 */
export function useRoadmaps() {
  return useMemo(() => {
    if (!_cache) {
      const roadmaps = loadAllRoadmaps();
      const allProblems = roadmaps.flatMap((r) =>
        r.topics.flatMap((t) => t.problems)
      );
      _cache = { roadmaps, allProblems };
    }
    return _cache;
  }, []);
}
