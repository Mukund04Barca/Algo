import { useMemo } from 'react';
import type { Problem } from '@/types';

export interface SearchFilters {
  query: string;
  difficulty: 'All' | 'Easy' | 'Medium' | 'Hard';
  status: 'All' | 'Not Started' | 'Learning' | 'Solved' | 'Needs Revision' | 'Mastered';
  topic: string;
  roadmapId: string;
}

export function useSearch(
  problems: Problem[],
  statuses: Record<string, { status: string }>,
  filters: SearchFilters
) {
  return useMemo(() => {
    let result = problems;

    if (filters.query.trim()) {
      const q = filters.query.toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.topic.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q)) ||
          p.companies.some((c) => c.toLowerCase().includes(q))
      );
    }

    if (filters.difficulty !== 'All') {
      result = result.filter((p) => p.difficulty === filters.difficulty);
    }

    if (filters.status !== 'All') {
      result = result.filter(
        (p) => (statuses[p.id]?.status ?? 'Not Started') === filters.status
      );
    }

    if (filters.topic) {
      result = result.filter((p) => p.topic === filters.topic);
    }

    if (filters.roadmapId) {
      result = result.filter((p) => p.roadmapId === filters.roadmapId);
    }

    return result;
  }, [problems, statuses, filters]);
}
