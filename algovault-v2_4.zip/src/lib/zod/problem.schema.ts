import { z } from 'zod';

export const DifficultySchema = z.enum(['Easy', 'Medium', 'Hard']);
export const ProblemStatusSchema = z.enum([
  'Not Started', 'Learning', 'Solved', 'Needs Revision', 'Mastered',
]);
export const LanguageSchema = z.enum(['python', 'java', 'cpp', 'javascript']);
export const RoadmapIdSchema = z.enum(['striver-a2z', 'blind-75', 'neetcode-150']);

export const ProblemSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  topic: z.string().min(1),
  difficulty: DifficultySchema,
  platform: z.enum(['LeetCode', 'GFG', 'HackerRank', 'Other']),
  link: z.string().url().optional(),
  tags: z.array(z.string()),
  companies: z.array(z.string()),
  roadmapId: RoadmapIdSchema,
  order: z.number().int().nonnegative(),
  isPremium: z.boolean().optional(),
});
