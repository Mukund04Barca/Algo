import { z } from 'zod';
import { LanguageSchema, ProblemStatusSchema } from './problem.schema';

export const SolutionSchema = z.object({
  language: LanguageSchema,
  code: z.string(),
  timeComplexity: z.string(),
  spaceComplexity: z.string(),
  approach: z.string(),
  solvedAt: z.string().datetime(),
});

export const ReviewEventSchema = z.object({
  reviewedAt: z.string().datetime(),
  confidence: z.number().int().min(1).max(5),
});

export const ProblemProgressSchema = z.object({
  problemId: z.string().min(1),
  status: ProblemStatusSchema,
  confidence: z.number().int().min(1).max(5),
  attempts: z.number().int().nonnegative(),
  timeTaken: z.number().nonnegative(),
  notes: z.string(),
  mistakes: z.string(),
  solutions: z.array(SolutionSchema),
  reviewHistory: z.array(ReviewEventSchema),
  nextReview: z.string().datetime().nullable(),
  easeFactor: z.number().min(1.3),
  interval: z.number().int().nonnegative(),
  lastSolved: z.string().datetime().nullable(),
  favorite: z.boolean(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
