import { z } from 'zod';
import { ProblemSchema, RoadmapIdSchema } from './problem.schema';

export const RoadmapTopicSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  order: z.number().int().nonnegative(),
  problems: z.array(ProblemSchema),
});

export const RoadmapSchema = z.object({
  id: RoadmapIdSchema,
  name: z.string().min(1),
  description: z.string(),
  // totalProblems is 0 in source files and computed by RoadmapLoader after validation
  totalProblems: z.number().nonnegative(),
  topics: z.array(RoadmapTopicSchema),
});
