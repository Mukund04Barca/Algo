import { z } from 'zod';
import { ProblemProgressSchema } from './progress.schema';

export const UserProfileSchema = z.object({
  githubLogin: z.string().min(1),
  githubName: z.string(),
  avatarUrl: z.string().url(),
  repoName: z.string().min(1),
});

export const UserDataSchema = z.object({
  version: z.string(),
  profile: UserProfileSchema,
  progress: z.record(z.string(), ProblemProgressSchema),
  dailyActivity: z.record(z.string(), z.number().nonnegative()),
  streak: z.number().int().nonnegative(),
  longestStreak: z.number().int().nonnegative(),
  lastActiveDate: z.string().datetime().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
