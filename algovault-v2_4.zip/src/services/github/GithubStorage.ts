import type { StorageAdapter } from '@/services/storage/StorageAdapter';
import type { UserData } from '@/types';
import { UserDataSchema } from '@/lib/zod';
import { GithubClient } from './GithubClient';

const DATA_PATH = 'progress/data.json';

/**
 * GithubStorage — StorageAdapter backed by a private GitHub repo.
 * Tracks file SHA for conflict-free updates.
 */
export class GithubStorage implements StorageAdapter {
  readonly name = 'GitHub';
  private sha: string | null = null;

  constructor(
    private readonly client: GithubClient,
    private readonly owner: string,
    private readonly repo: string,
  ) {}

  async load(): Promise<UserData | null> {
    const file = await this.client.getFile(this.owner, this.repo, DATA_PATH);
    if (!file) return null;

    this.sha = file.sha;
    const json = decodeURIComponent(escape(atob(file.content.replace(/\n/g, ''))));

    let raw: unknown;
    try {
      raw = JSON.parse(json);
    } catch {
      console.error('[GithubStorage] Failed to parse JSON from repo');
      return null;
    }

    const result = UserDataSchema.safeParse(raw);
    if (!result.success) {
      console.warn('[GithubStorage] Schema validation failed:', result.error.flatten());
      return null;
    }
    return result.data;
  }

  async save(data: UserData): Promise<void> {
    const content = JSON.stringify(data, null, 2);
    await this.client.putFile(
      this.owner,
      this.repo,
      DATA_PATH,
      content,
      `chore: sync progress ${new Date().toISOString()}`,
      this.sha ?? undefined,
    );
    // After a successful write we don't know the new SHA without a separate GET.
    // Reset so next save re-fetches if needed. Most apps don't need perfect SHA
    // tracking between browser sessions.
    this.sha = null;
  }

  async delete(): Promise<void> {
    // No-op: don't delete from GitHub automatically on logout.
    // User can manually delete the repo.
  }
}
