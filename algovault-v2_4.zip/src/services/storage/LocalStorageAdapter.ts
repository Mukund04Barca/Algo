import type { StorageAdapter } from './StorageAdapter';
import type { UserData } from '@/types';
import { UserDataSchema } from '@/lib/zod';
import { ls, STORAGE_KEYS } from '@/lib/utils';

/**
 * LocalStorageAdapter
 * Primary storage before GitHub auth, or as offline cache.
 * All data is Zod-validated on read.
 */
export class LocalStorageAdapter implements StorageAdapter {
  readonly name = 'LocalStorage';

  async load(): Promise<UserData | null> {
    const raw = ls.get<unknown>(STORAGE_KEYS.DATA_CACHE);
    if (raw === null) return null;

    const result = UserDataSchema.safeParse(raw);
    if (!result.success) {
      console.warn('[LocalStorageAdapter] Schema validation failed:', result.error.flatten());
      return null;
    }
    return result.data;
  }

  async save(data: UserData): Promise<void> {
    ls.set(STORAGE_KEYS.DATA_CACHE, data);
  }

  async delete(): Promise<void> {
    ls.remove(STORAGE_KEYS.DATA_CACHE);
  }
}
