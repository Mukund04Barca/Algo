import type { UserData } from '@/types';

/**
 * StorageAdapter — the only interface stores ever see.
 * Swap GitHub for Supabase (or anything else) by implementing this.
 */
export interface StorageAdapter {
  /** Load user data. Returns null if not found. */
  load(): Promise<UserData | null>;
  /** Persist user data. */
  save(data: UserData): Promise<void>;
  /** Delete all persisted data. */
  delete(): Promise<void>;
  /** Human-readable name for debugging. */
  readonly name: string;
}
