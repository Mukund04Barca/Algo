import { cn } from '@/lib/utils';
import type { Difficulty, ProblemStatus } from '@/types';

type BadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'purple' | 'accent';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
}

const variantClasses: Record<BadgeVariant, string> = {
  default: 'bg-[var(--bg-overlay)] text-[var(--text-secondary)] border-[var(--border-default)]',
  success: 'bg-[var(--success-subtle)] text-[var(--success)] border-[color-mix(in_srgb,var(--success)_30%,transparent)]',
  warning: 'bg-[var(--warning-subtle)] text-[var(--warning)] border-[color-mix(in_srgb,var(--warning)_30%,transparent)]',
  danger: 'bg-[var(--danger-subtle)] text-[var(--danger)] border-[color-mix(in_srgb,var(--danger)_30%,transparent)]',
  purple: 'bg-[var(--purple-subtle)] text-[var(--purple)] border-[color-mix(in_srgb,var(--purple)_30%,transparent)]',
  accent: 'bg-[var(--accent-subtle)] text-[var(--accent)] border-[color-mix(in_srgb,var(--accent)_30%,transparent)]',
};

export function Badge({ children, variant = 'default', className }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-medium',
        variantClasses[variant],
        className
      )}
    >
      {children}
    </span>
  );
}

export function DifficultyBadge({ difficulty }: { difficulty: Difficulty }) {
  const variantMap: Record<Difficulty, BadgeVariant> = {
    Easy: 'success',
    Medium: 'warning',
    Hard: 'danger',
  };
  return <Badge variant={variantMap[difficulty]}>{difficulty}</Badge>;
}

export function StatusBadge({ status }: { status: ProblemStatus }) {
  const variantMap: Record<ProblemStatus, BadgeVariant> = {
    'Not Started': 'default',
    'Learning': 'purple',
    'Solved': 'accent',
    'Needs Revision': 'warning',
    'Mastered': 'success',
  };
  return <Badge variant={variantMap[status]}>{status}</Badge>;
}
