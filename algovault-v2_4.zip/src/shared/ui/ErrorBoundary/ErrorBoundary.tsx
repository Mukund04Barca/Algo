import { Component, type ReactNode, type ErrorInfo } from 'react';
import { Button } from '../Button/Button';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;

      return (
        <div className="flex min-h-[200px] flex-col items-center justify-center gap-3 rounded-lg border border-[var(--danger-subtle)] bg-[var(--danger-subtle)] p-6 text-center">
          <p className="text-sm font-semibold text-[var(--danger)]">Something went wrong</p>
          <p className="text-xs text-[var(--text-muted)]">{this.state.error?.message}</p>
          <Button
            variant="danger"
            size="sm"
            onClick={() => this.setState({ hasError: false, error: null })}
          >
            Try again
          </Button>
        </div>
      );
    }

    return this.props.children;
  }
}
