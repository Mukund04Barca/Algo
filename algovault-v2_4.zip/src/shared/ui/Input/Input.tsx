import { forwardRef, type InputHTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ iconLeft, iconRight, className, ...props }, ref) => {
    return (
      <div className="relative flex items-center">
        {iconLeft && (
          <span className="pointer-events-none absolute left-3 text-[var(--text-muted)]">
            {iconLeft}
          </span>
        )}
        <input
          ref={ref}
          className={cn(
            'h-9 w-full rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)]',
            'px-3 py-1.5 text-sm text-[var(--text-primary)]',
            'placeholder:text-[var(--text-muted)]',
            'outline-none transition-colors duration-150',
            'focus:border-[var(--accent)] focus:ring-2 focus:ring-[var(--accent-subtle)]',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            iconLeft && 'pl-9',
            iconRight && 'pr-9',
            className
          )}
          {...props}
        />
        {iconRight && (
          <span className="pointer-events-none absolute right-3 text-[var(--text-muted)]">
            {iconRight}
          </span>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';
