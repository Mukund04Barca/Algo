import { cn } from '@/lib/utils';

interface LoadingProps {
  fullscreen?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const sizeClasses = {
  sm: 'w-4 h-4 border-2',
  md: 'w-7 h-7 border-2',
  lg: 'w-10 h-10 border-[3px]',
};

export function Loading({ fullscreen, size = 'md', className }: LoadingProps) {
  const spinner = (
    <div
      className={cn(
        'rounded-full border-[var(--border-default)] border-t-[var(--accent)] animate-spin',
        sizeClasses[size]
      )}
    />
  );

  if (fullscreen) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-[var(--bg-base)]">
        {spinner}
      </div>
    );
  }

  return (
    <div className={cn('flex items-center justify-center p-8', className)}>
      {spinner}
    </div>
  );
}
