import { cn } from '@/lib/utils';

interface ProgressProps {
  value: number; // 0-100
  color?: 'accent' | 'success' | 'warning' | 'danger' | 'purple';
  size?: 'sm' | 'md';
  className?: string;
  showLabel?: boolean;
}

const colorMap = {
  accent: 'var(--accent)',
  success: 'var(--success)',
  warning: 'var(--warning)',
  danger: 'var(--danger)',
  purple: 'var(--purple)',
};

export function Progress({ value, color = 'accent', size = 'sm', className, showLabel }: ProgressProps) {
  const pct = Math.min(100, Math.max(0, value));

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <div
        className={cn(
          'relative w-full overflow-hidden rounded-full bg-[var(--bg-subtle)]',
          size === 'sm' ? 'h-1.5' : 'h-2.5'
        )}
      >
        <div
          className="h-full rounded-full transition-[width] duration-500"
          style={{ width: `${pct}%`, background: colorMap[color] }}
        />
      </div>
      {showLabel && (
        <span className="w-10 shrink-0 text-right text-[11px] tabular-nums text-[var(--text-muted)]">
          {pct}%
        </span>
      )}
    </div>
  );
}
