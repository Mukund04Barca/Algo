import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type { GitHubAuth } from '@/types';
import { ls, STORAGE_KEYS } from '@/lib/utils';

interface AuthState {
  auth: GitHubAuth | null;
  isLoading: boolean;
  error: string | null;
}

interface AuthActions {
  setAuth: (auth: GitHubAuth) => void;
  clearAuth: () => void;
  setError: (error: string | null) => void;
  setLoading: (loading: boolean) => void;
}

type AuthStore = AuthState & AuthActions;

export const useAuthStore = create<AuthStore>()(
  devtools(
    immer((set) => ({
      auth: ls.get<GitHubAuth>(STORAGE_KEYS.AUTH),
      isLoading: false,
      error: null,

      setAuth: (auth) => set((state) => {
        state.auth = auth;
        state.error = null;
        ls.set(STORAGE_KEYS.AUTH, auth);
      }),

      clearAuth: () => set((state) => {
        state.auth = null;
        ls.remove(STORAGE_KEYS.AUTH);
      }),

      setError: (error) => set((state) => { state.error = error; }),
      setLoading: (loading) => set((state) => { state.isLoading = loading; }),
    })),
    { name: 'AuthStore' }
  )
);
