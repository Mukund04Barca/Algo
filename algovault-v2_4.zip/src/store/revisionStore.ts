import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type { Problem, ProblemProgress } from '@/types';
import { isDue } from '@/features/revision/RevisionEngine';

export interface RevisionItem {
  problem: Problem;
  progress: ProblemProgress;
  isOverdue: boolean;
  daysOverdue: number;
}

interface RevisionState {
  dueItems: RevisionItem[];
  completedToday: Set<string>;
}

interface RevisionActions {
  computeDue: (
    problems: Problem[],
    progress: Record<string, ProblemProgress>
  ) => void;
  markComplete: (problemId: string) => void;
  reset: () => void;
}

type RevisionStore = RevisionState & RevisionActions;

export const useRevisionStore = create<RevisionStore>()(
  devtools(
    immer((set) => ({
      dueItems: [],
      completedToday: new Set(),

      computeDue: (problems, progress) => set((state) => {
        const now = new Date();
        const items: RevisionItem[] = [];

        for (const p of problems) {
          const prog = progress[p.id];
          if (!prog) continue;
          if (prog.status !== 'Solved' && prog.status !== 'Mastered') continue;
          if (!isDue(prog.nextReview)) continue;

          const dueDate = prog.nextReview ? new Date(prog.nextReview) : now;
          const daysOverdue = Math.max(
            0,
            Math.floor((now.getTime() - dueDate.getTime()) / 86_400_000)
          );

          items.push({ problem: p, progress: prog, isOverdue: daysOverdue > 0, daysOverdue });
        }

        items.sort((a, b) => b.daysOverdue - a.daysOverdue);
        state.dueItems = items;
      }),

      markComplete: (problemId) => set((state) => {
        state.completedToday.add(problemId);
        state.dueItems = state.dueItems.filter((i) => i.problem.id !== problemId);
      }),

      reset: () => set((state) => {
        state.dueItems = [];
        state.completedToday = new Set();
      }),
    })),
    { name: 'RevisionStore' }
  )
);
