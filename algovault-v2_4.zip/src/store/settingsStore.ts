import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';

type Theme = 'dark' | 'light' | 'system';
type DefaultLanguage = 'python' | 'java' | 'cpp' | 'javascript';

interface SettingsState {
  theme: Theme;
  defaultLanguage: DefaultLanguage;
  autoSync: boolean;
  syncDebounceMs: number;
  sidebarCollapsed: boolean;
}

interface SettingsActions {
  setTheme: (theme: Theme) => void;
  setDefaultLanguage: (lang: DefaultLanguage) => void;
  setAutoSync: (enabled: boolean) => void;
  toggleSidebar: () => void;
}

type SettingsStore = SettingsState & SettingsActions;

export const useSettingsStore = create<SettingsStore>()(
  devtools(
    persist(
      immer((set) => ({
        theme: 'dark',
        defaultLanguage: 'python',
        autoSync: true,
        syncDebounceMs: 2500,
        sidebarCollapsed: false,

        setTheme: (theme) => set((state) => { state.theme = theme; }),
        setDefaultLanguage: (lang) => set((state) => { state.defaultLanguage = lang; }),
        setAutoSync: (enabled) => set((state) => { state.autoSync = enabled; }),
        toggleSidebar: () => set((state) => {
          state.sidebarCollapsed = !state.sidebarCollapsed;
        }),
      })),
      { name: 'algovault:settings' }
    ),
    { name: 'SettingsStore' }
  )
);
