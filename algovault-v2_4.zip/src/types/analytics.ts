export interface DailyActivity {
  date: string; // "yyyy-MM-dd"
  count: number;
}

export interface TopicStats {
  topic: string;
  total: number;
  solved: number;
  mastered: number;
  pct: number;
}

export interface DifficultyStats {
  difficulty: 'Easy' | 'Medium' | 'Hard';
  total: number;
  solved: number;
  mastered: number;
}

export interface RoadmapStats {
  roadmapId: string;
  name: string;
  total: number;
  solved: number;
  mastered: number;
  pct: number;
}
