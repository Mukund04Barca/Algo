export interface GitHubUser {
  login: string;
  name: string | null;
  avatar_url: string;
  public_repos: number;
}

export interface GitHubAuth {
  token: string;
  user: GitHubUser;
  repoName: string;
}

export interface GitHubFile {
  sha: string;
  content: string; // base64
  path: string;
}

export interface SyncState {
  status: 'idle' | 'syncing' | 'error' | 'success';
  lastSynced: string | null; // ISO
  error: string | null;
}
