export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export type ProblemStatus =
  | 'Not Started'
  | 'Learning'
  | 'Solved'
  | 'Needs Revision'
  | 'Mastered';

export type Language = 'python' | 'java' | 'cpp' | 'javascript';

export type RoadmapId = 'striver-a2z' | 'blind-75' | 'neetcode-150';

export interface Problem {
  id: string;
  title: string;
  topic: string;
  difficulty: Difficulty;
  platform: 'LeetCode' | 'GFG' | 'HackerRank' | 'Other';
  link?: string;
  tags: string[];
  companies: string[];
  roadmapId: RoadmapId;
  order: number;
  isPremium?: boolean;
}
