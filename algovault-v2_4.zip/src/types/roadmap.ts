import type { Problem, RoadmapId } from './problem';

export interface RoadmapTopic {
  id: string;
  name: string;
  order: number;
  problems: Problem[];
}

export interface Roadmap {
  id: RoadmapId;
  name: string;
  description: string;
  totalProblems: number;
  topics: RoadmapTopic[];
}
