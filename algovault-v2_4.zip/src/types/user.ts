import type { Language, ProblemStatus } from './problem';

export interface Solution {
  language: Language;
  code: string;
  timeComplexity: string;
  spaceComplexity: string;
  approach: string;
  solvedAt: string; // ISO
}

export interface ReviewEvent {
  reviewedAt: string; // ISO
  confidence: number; // 1-5
}

export interface ProblemProgress {
  problemId: string;
  status: ProblemStatus;
  confidence: number; // 1-5
  attempts: number;
  timeTaken: number; // minutes
  notes: string;
  mistakes: string;
  solutions: Solution[];
  // Spaced repetition
  reviewHistory: ReviewEvent[];
  nextReview: string | null; // ISO
  easeFactor: number; // SM-2, starts at 2.5
  interval: number; // days
  // Meta
  lastSolved: string | null; // ISO
  favorite: boolean;
  createdAt: string; // ISO
  updatedAt: string; // ISO
}

export interface UserProfile {
  githubLogin: string;
  githubName: string;
  avatarUrl: string;
  repoName: string;
}

export interface UserData {
  version: string; // semver, for migration
  profile: UserProfile;
  progress: Record<string, ProblemProgress>;
  dailyActivity: Record<string, number>; // "yyyy-MM-dd" → count
  streak: number;
  longestStreak: number;
  lastActiveDate: string | null; // ISO
  createdAt: string; // ISO
  updatedAt: string; // ISO
}
