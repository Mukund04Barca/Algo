import { useSettingsStore } from '@/store';
import { Sidebar } from '@/widgets/Sidebar/Sidebar';
import { cn } from '@/lib/utils';

export function AppLayout({ children }: { children: React.ReactNode }) {
  const collapsed = useSettingsStore((s) => s.sidebarCollapsed);

  return (
    <div className="flex h-screen overflow-hidden bg-[var(--bg-base)]">
      <Sidebar />
      <main
        className={cn(
          'flex-1 overflow-y-auto transition-[margin] duration-300',
          collapsed ? 'ml-[60px]' : 'ml-[220px]'
        )}
      >
        {children}
      </main>
    </div>
  );
}
