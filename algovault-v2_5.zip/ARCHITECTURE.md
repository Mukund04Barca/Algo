# AlgoVault — Architecture

## Invariants

These rules must never be violated without a conscious RFC decision.

1. **Stores never perform I/O.** Stores own state. Services and adapters own I/O. A store action must never call `fetch`, `localStorage`, or any storage adapter.

2. **Components never call storage adapters directly.** The only path from a component to storage is: component → service function → store → `useAutoSave` → `StorageAdapter`.

3. **All external data passes through Zod validation.** Every read from localStorage, GitHub, or any external source must be validated via a Zod schema before entering a store. Unvalidated data never reaches React.

4. **Derived values are never persisted.** Topic progress, roadmap progress, and revision due counts are computed from `userData.progress` at render time. They must not be stored in `UserData` or any adapter.

5. **Business workflows live in service functions, not components.** Components express intent (`saveProblem(payload)`). Service functions orchestrate the response (update progress, compute revision, mark activity). No component coordinates multiple store actions directly.

6. **Schema changes are versioned and migrated.** Every change to `UserData` or `ProblemProgress` shape requires a version bump in `DATA_VERSION` and a corresponding migration in `src/services/migration/migrate.ts`.

---

## Data Flow

```
User action
  ↓
Component (expresses intent)
  ↓
Service function (orchestrates)
  ↓
Store action (updates state)
  ↓
useAutoSave (watches state, debounced)
  ↓
StorageAdapter (persists)
```

GitHub sync follows the same path via `useGithubSync`, called explicitly from Settings or triggered post-save.

---

## Layers

| Layer | Location | Responsibility |
|---|---|---|
| Types | `src/types/` | Domain interfaces — source of truth |
| Schemas | `src/lib/zod/` | Runtime validation — derived from types |
| Stores | `src/store/` | Reactive state — no I/O |
| Services | `src/services/` | Orchestration, I/O adapters, migration |
| Hooks | `src/hooks/` | React integration — compose stores + services |
| Widgets | `src/widgets/` | Structural UI (layout, sidebar) |
| Features | `src/features/` | Page-level components |
| Shared UI | `src/shared/ui/` | Reusable, stateless components |

---

## Versioning

`UserData.version` follows semver. The current version is defined in `src/lib/zod/user.schema.ts` as `DATA_VERSION`.

Migration chain lives in `src/services/migration/migrate.ts`. Each key is a version that can be migrated from; each value is a function returning the migrated data or `null` (start fresh).
