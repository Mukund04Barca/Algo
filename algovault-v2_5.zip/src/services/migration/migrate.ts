import type { UserData } from '@/types';
import { UserDataSchema, DATA_VERSION } from '@/lib/zod/user.schema';

/**
 * Migration registry.
 * Each entry migrates from its key version to the next.
 * Return null to signal the migration cannot be completed → start fresh.
 */
const migrations: Record<string, (raw: unknown) => unknown> = {
  '2.0.0': (raw) => {
    // 2.0.0 → 2.1.0
    // ProblemProgress replaced timeComplexity/spaceComplexity with complexity: { time?, space? }
    if (typeof raw !== 'object' || raw === null) return null;
    const data = raw as Record<string, unknown>;
    const progress = data['progress'] as Record<string, Record<string, unknown>> | undefined;
    if (!progress) return { ...data, version: '2.1.0' };

    const migratedProgress: Record<string, unknown> = {};
    for (const [id, prog] of Object.entries(progress)) {
      const { timeComplexity, spaceComplexity, ...rest } = prog as Record<string, unknown>;
      migratedProgress[id] = {
        ...rest,
        complexity: {
          time: typeof timeComplexity === 'string' ? timeComplexity : undefined,
          space: typeof spaceComplexity === 'string' ? spaceComplexity : undefined,
        },
      };
    }

    return { ...data, version: '2.1.0', progress: migratedProgress };
  },
};

export interface MigrationResult {
  data: UserData | null;
  migrated: boolean;
  fromVersion: string;
  error?: string;
}

/**
 * Attempt to load and migrate raw persisted data to the current schema.
 *
 * Priority:
 * 1. Raw data matches current version → validate and return.
 * 2. Migration path exists → migrate, validate, return.
 * 3. No path → return null (start fresh), log warning.
 */
export function migrateUserData(raw: unknown): MigrationResult {
  if (typeof raw !== 'object' || raw === null) {
    return { data: null, migrated: false, fromVersion: 'unknown', error: 'Not an object' };
  }

  const rawVersion = (raw as Record<string, unknown>)['version'];
  const fromVersion = typeof rawVersion === 'string' ? rawVersion : 'unknown';

  // Already current — just validate
  if (fromVersion === DATA_VERSION) {
    const result = UserDataSchema.safeParse(raw);
    if (result.success) return { data: result.data as UserData, migrated: false, fromVersion };
    console.warn('[Migration] Current version failed validation:', result.error.flatten());
    return { data: null, migrated: false, fromVersion, error: 'Validation failed' };
  }

  // Try migration chain
  let current = raw;
  let currentVersion = fromVersion;
  const visited = new Set<string>();

  while (currentVersion !== DATA_VERSION) {
    if (visited.has(currentVersion)) {
      const msg = `[Migration] Cycle detected at version ${currentVersion}`;
      console.error(msg);
      return { data: null, migrated: true, fromVersion, error: msg };
    }
    visited.add(currentVersion);

    const migrate = migrations[currentVersion];
    if (!migrate) {
      const msg = `[Migration] No path from ${currentVersion} to ${DATA_VERSION} — starting fresh`;
      console.warn(msg);
      return { data: null, migrated: true, fromVersion, error: msg };
    }

    current = migrate(current);
    if (current === null) {
      const msg = `[Migration] Migration from ${currentVersion} returned null — starting fresh`;
      console.warn(msg);
      return { data: null, migrated: true, fromVersion, error: msg };
    }

    currentVersion = (current as Record<string, unknown>)['version'] as string;
    console.info(`[Migration] ${fromVersion} → ${currentVersion}`);
  }

  const result = UserDataSchema.safeParse(current);
  if (!result.success) {
    console.warn('[Migration] Post-migration validation failed:', result.error.flatten());
    return { data: null, migrated: true, fromVersion, error: 'Post-migration validation failed' };
  }

  return { data: result.data as UserData, migrated: true, fromVersion };
}
