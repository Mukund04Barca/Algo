# AlgoVault — Architecture

**Current version:** 2.1.0  
**Completed milestones:** Foundation · Roadmap Engine · Progress Engine

---

## Invariants

These rules must never be violated without a conscious RFC decision.

1. **Stores never perform I/O.** Stores own state. Services and adapters own I/O. A store action must never call `fetch`, `localStorage`, or any storage adapter.

2. **Components never call storage adapters directly.** The only path from a component to storage is: component → service function → store → `useAutoSave` → `StorageAdapter`.

3. **All external data passes through Zod validation and migration.** Every read from localStorage or GitHub passes through `migrateUserData()` before entering a store. Unvalidated data never reaches React.

4. **Derived values are never persisted.** Topic progress, roadmap progress, and revision due counts are computed from `userData.progress` at render time. They must not be stored in `UserData`.

5. **Business workflows live in service functions, not components.** Components express intent (`saveProblem(payload)`). Service functions orchestrate (update progress, compute revision, mark activity). No component coordinates multiple store actions directly.

6. **Schema changes are versioned and migrated.** Every change to `UserData` or `ProblemProgress` requires a version bump in `DATA_VERSION` (`src/lib/zod/user.schema.ts`) and a migration in `src/services/migration/migrate.ts`.

---

## Data Flow

```
User action
  ↓
Component (expresses intent)
  ↓
Service function (orchestrates)
  ↓
Store action (updates state)
  ↓
useAutoSave (watches userData, debounced 800ms)
  ↓
LocalStorageAdapter.save()

GitHub sync (on demand or post-save)
  ↓
useGitHubSync → GitHubStorage.save()
```

---

## Layer Map

| Layer | Location | Responsibility |
|---|---|---|
| Types | `src/types/` | Domain interfaces — source of truth for all shapes |
| Schemas | `src/lib/zod/` | Runtime validation — validates external data before it enters stores |
| Migration | `src/services/migration/` | Schema versioning — upgrades persisted data to current version |
| Stores | `src/store/` | Reactive state — no I/O, no business logic |
| Services | `src/services/` | Orchestration (`progress/`), I/O adapters (`storage/`, `github/`) |
| Hooks | `src/hooks/` | React integration — compose stores + services |
| Widgets | `src/widgets/` | Structural UI (AppLayout, Sidebar) |
| Features | `src/features/` | Page-level components and their sub-components |
| Shared UI | `src/shared/ui/` | Stateless, reusable primitives |

---

## Service Functions

All business workflows go through these — not components, not stores:

| Function | Location | Purpose |
|---|---|---|
| `saveProblem()` | `services/progress/` | Status, confidence, notes, complexity, first-solve logic |
| `toggleFavorite()` | `services/progress/` | Immediate favorite toggle |
| `reviewProblem()` | `services/progress/` | Post-revision SM-2 update |
| `migrateUserData()` | `services/migration/` | Version-aware schema migration |

---

## Versioning

`UserData.version` follows semver. The current version is `DATA_VERSION` in `src/lib/zod/user.schema.ts`.

Migration chain in `src/services/migration/migrate.ts`. Each key is a migratable-from version; each value is a pure function returning migrated data or `null` (start fresh). Both `LocalStorageAdapter` and `GitHubStorage` run every read through this pipeline.

---

## Naming Conventions

- GitHub (not Github) — consistent with brand in all identifiers and filenames
- `ProblemWorkspace/` — the problem detail panel (not ProblemDrawer)
- Store action naming: `setSyncing`, `setSyncError`, `setSyncSuccess`, `setSyncOffline`
- `SyncStatus` type is exported from `progressStore.ts`
