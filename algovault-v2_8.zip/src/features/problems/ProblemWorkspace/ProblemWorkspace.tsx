import { useState, useEffect, useCallback } from 'react';
import type { Problem, ProblemProgress, ProblemStatus, ProblemComplexity } from '@/types';
import { useProgressStore } from '@/store';
import { saveProblem, toggleFavorite } from '@/services/progress';
import { WorkspaceHeader } from './WorkspaceHeader';
import { WorkspaceBody } from './WorkspaceBody';
import { WorkspaceFooter } from './WorkspaceFooter';
import type { SaveStatus } from './WorkspaceFooter';

interface ProblemWorkspaceProps {
  problem: Problem;
  progress: ProblemProgress | undefined;
  /** All problems in the same topic, for ← → navigation */
  siblingProblems: Problem[];
  onClose: () => void;
  onNavigate: (problem: Problem) => void;
}

export function ProblemWorkspace({
  problem, progress, siblingProblems, onClose, onNavigate,
}: ProblemWorkspaceProps) {
  const { updateProgress, markActivity } = useProgressStore();

  // Local form state — mirrors persisted values, diverges when user edits
  const [status, setStatus]         = useState<ProblemStatus>(progress?.status ?? 'Not Started');
  const [confidence, setConfidence] = useState(progress?.confidence ?? 3);
  const [notes, setNotes]           = useState(progress?.notes ?? '');
  const [complexity, setComplexity] = useState<ProblemComplexity>(progress?.complexity ?? {});
  const [saveStatus, setSaveStatus] = useState<SaveStatus>(progress ? 'saved-local' : 'idle');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Sync local state when a different problem is selected
  useEffect(() => {
    setStatus(progress?.status ?? 'Not Started');
    setConfidence(progress?.confidence ?? 3);
    setNotes(progress?.notes ?? '');
    setComplexity(progress?.complexity ?? {});
    setSaveStatus(progress ? 'saved-local' : 'idle');
    setHasUnsavedChanges(false);
  }, [problem.id, progress]);

  function markEditing() {
    setHasUnsavedChanges(true);
    setSaveStatus('editing');
  }

  const handleSave = useCallback(() => {
    setSaveStatus('saving');
    saveProblem(
      {
        problemId: problem.id,
        roadmapId: problem.roadmapId,
        topicId: problem.topic,
        status,
        confidence,
        notes,
        complexity,
        source: 'workspace',
      },
      progress,
      { updateProgress, markActivity }
    );
    setHasUnsavedChanges(false);
    setSaveStatus('saved-local');
  }, [problem, progress, status, confidence, notes, complexity, updateProgress, markActivity]);

  const handleToggleFavorite = useCallback(() => {
    toggleFavorite(problem.id, progress, { updateProgress });
  }, [problem.id, progress, updateProgress]);

  // Navigation within the same topic
  const currentIdx = siblingProblems.findIndex((p) => p.id === problem.id);
  const hasPrev = currentIdx > 0;
  const hasNext = currentIdx < siblingProblems.length - 1;

  const navigateTo = useCallback((delta: number) => {
    const target = siblingProblems[currentIdx + delta];
    if (target) onNavigate(target);
  }, [siblingProblems, currentIdx, onNavigate]);

  // Keyboard shortcuts — only when focus is NOT in a text input/textarea
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement).tagName;
      const isTyping = tag === 'INPUT' || tag === 'TEXTAREA' || (e.target as HTMLElement).isContentEditable;

      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
        return;
      }

      // Ctrl+S / Cmd+S always saves regardless of focus
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        if (hasUnsavedChanges) handleSave();
        return;
      }

      // Arrow navigation — only when not typing
      if (!isTyping) {
        if (e.key === 'ArrowLeft' && hasPrev) { e.preventDefault(); navigateTo(-1); }
        if (e.key === 'ArrowRight' && hasNext) { e.preventDefault(); navigateTo(1); }
      }
    }

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose, handleSave, hasUnsavedChanges, hasPrev, hasNext, navigateTo]);

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40 bg-black/40 backdrop-blur-[2px]"
        onClick={onClose}
      />

      {/* Workspace panel */}
      <div className="fixed right-0 top-0 z-50 h-full w-full max-w-[460px] flex flex-col bg-[var(--bg-elevated)] border-l border-[var(--border-default)] shadow-2xl">
        <WorkspaceHeader
          problem={problem}
          progress={progress}
          onClose={onClose}
          onToggleFavorite={handleToggleFavorite}
        />
        <WorkspaceBody
          problem={problem}
          progress={progress}
          status={status}
          confidence={confidence}
          notes={notes}
          complexity={complexity}
          onStatusChange={(s) => { setStatus(s); markEditing(); }}
          onConfidenceChange={(c) => { setConfidence(c); markEditing(); }}
          onNotesChange={(n) => { setNotes(n); markEditing(); }}
          onComplexityChange={(c) => { setComplexity(c); markEditing(); }}
        />
        <WorkspaceFooter
          saveStatus={saveStatus}
          hasPrev={hasPrev}
          hasNext={hasNext}
          onPrev={() => navigateTo(-1)}
          onNext={() => navigateTo(1)}
          onSave={handleSave}
          onClose={onClose}
        />
      </div>
    </>
  );
}
