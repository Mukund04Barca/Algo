import { type ReactNode } from 'react';
import { ExternalLink, BookOpen, CheckCircle2, RotateCcw, Brain, Trophy } from 'lucide-react';
import type { Problem, ProblemProgress, ProblemStatus, ProblemComplexity } from '@/types';
import { WorkspaceNotes } from './WorkspaceNotes';
import { WorkspaceComplexity } from './WorkspaceComplexity';
import { WorkspaceMetadata } from './WorkspaceMetadata';
import { cn } from '@/lib/utils';

interface WorkspaceBodyProps {
  problem: Problem;
  progress: ProblemProgress | undefined;
  status: ProblemStatus;
  confidence: number;
  notes: string;
  complexity: ProblemComplexity;
  onStatusChange: (s: ProblemStatus) => void;
  onConfidenceChange: (c: number) => void;
  onNotesChange: (n: string) => void;
  onComplexityChange: (c: ProblemComplexity) => void;
}

const STATUS_OPTIONS: {
  value: ProblemStatus;
  label: string;
  icon: ReactNode;
  color: string;
}[] = [
  { value: 'Not Started',    label: 'Not Started',    icon: <RotateCcw size={13} />,    color: 'text-[var(--text-muted)]'    },
  { value: 'Learning',       label: 'Learning',       icon: <BookOpen size={13} />,     color: 'text-[var(--purple)]'        },
  { value: 'Solved',         label: 'Solved',         icon: <CheckCircle2 size={13} />, color: 'text-[var(--accent)]'        },
  { value: 'Needs Revision', label: 'Needs Revision', icon: <Brain size={13} />,        color: 'text-[var(--warning)]'       },
  { value: 'Mastered',       label: 'Mastered',       icon: <Trophy size={13} />,       color: 'text-[var(--success)]'       },
];

const SOLVED_STATUSES: ProblemStatus[] = ['Solved', 'Mastered', 'Needs Revision'];

export function WorkspaceBody({
  problem, progress, status, confidence, notes, complexity,
  onStatusChange, onConfidenceChange, onNotesChange, onComplexityChange,
}: WorkspaceBodyProps) {
  return (
    <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
      {/* External link */}
      {problem.link && (
        <a
          href={problem.link}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 rounded-md border border-[var(--border-default)] bg-[var(--bg-overlay)] px-3 py-1.5 text-xs font-medium text-[var(--text-secondary)] hover:border-[var(--accent)] hover:text-[var(--accent)] transition-colors"
        >
          <ExternalLink size={11} />
          Open on {problem.platform}
        </a>
      )}

      {/* Status */}
      <div>
        <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">Status</div>
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
          {STATUS_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => onStatusChange(opt.value)}
              className={cn(
                'flex items-center gap-2 rounded-md border px-3 py-2 text-xs font-medium transition-colors text-left',
                status === opt.value
                  ? 'border-[var(--accent)] bg-[var(--accent-subtle)] text-[var(--accent)]'
                  : 'border-[var(--border-default)] bg-[var(--bg-overlay)] text-[var(--text-secondary)] hover:border-[var(--border-emphasis)]'
              )}
            >
              <span className={status === opt.value ? 'text-[var(--accent)]' : opt.color}>
                {opt.icon}
              </span>
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Confidence — only after attempted */}
      {SOLVED_STATUSES.includes(status) && (
        <div>
          <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">
            Confidence{' '}
            <span className="text-[var(--text-muted)] font-normal">(affects revision schedule)</span>
          </div>
          <div className="flex gap-1.5">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                key={n}
                onClick={() => onConfidenceChange(n)}
                className={cn(
                  'flex-1 rounded-md border py-2 text-xs font-semibold tabular-nums transition-colors',
                  confidence === n
                    ? n <= 2
                      ? 'border-[var(--danger)] bg-[var(--danger-subtle)] text-[var(--danger)]'
                      : n === 3
                      ? 'border-[var(--warning)] bg-[var(--warning-subtle)] text-[var(--warning)]'
                      : 'border-[var(--success)] bg-[var(--success-subtle)] text-[var(--success)]'
                    : 'border-[var(--border-default)] bg-[var(--bg-overlay)] text-[var(--text-muted)] hover:border-[var(--border-emphasis)]'
                )}
              >
                {n}
              </button>
            ))}
          </div>
          <div className="mt-1 flex justify-between text-[10px] text-[var(--text-muted)]">
            <span>Couldn't do it</span>
            <span>Perfect</span>
          </div>
        </div>
      )}

      {/* Complexity */}
      <WorkspaceComplexity complexity={complexity} onChange={onComplexityChange} />

      {/* Notes */}
      <WorkspaceNotes notes={notes} onChange={onNotesChange} />

      {/* Metadata */}
      <WorkspaceMetadata problem={problem} progress={progress} />
    </div>
  );
}
