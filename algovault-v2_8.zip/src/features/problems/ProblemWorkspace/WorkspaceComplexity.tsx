import type { ProblemComplexity } from '@/types';

interface WorkspaceComplexityProps {
  complexity: ProblemComplexity;
  onChange: (c: ProblemComplexity) => void;
}

export function WorkspaceComplexity({ complexity, onChange }: WorkspaceComplexityProps) {
  return (
    <div>
      <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">Complexity</div>
      <div className="grid grid-cols-2 gap-2">
        {(['time', 'space'] as const).map((key) => (
          <div key={key}>
            <label className="mb-1 block text-[10px] uppercase tracking-wider text-[var(--text-muted)]">
              {key === 'time' ? 'Time' : 'Space'}
            </label>
            <input
              type="text"
              value={complexity[key] ?? ''}
              onChange={(e) => onChange({ ...complexity, [key]: e.target.value || undefined })}
              placeholder="O(n)"
              className="h-8 w-full rounded-md border border-[var(--border-default)] bg-[var(--bg-overlay)] px-2.5 text-xs font-mono text-[var(--text-primary)] placeholder:text-[var(--text-muted)] outline-none focus:border-[var(--accent)]"
            />
          </div>
        ))}
      </div>
    </div>
  );
}
