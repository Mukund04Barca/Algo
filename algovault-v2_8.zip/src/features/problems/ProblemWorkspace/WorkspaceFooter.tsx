import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/shared/ui/Button/Button';
import { cn } from '@/lib/utils';

export type SaveStatus = 'idle' | 'editing' | 'saving' | 'saved-local' | 'synced' | 'error';

interface WorkspaceFooterProps {
  saveStatus: SaveStatus;
  hasPrev: boolean;
  hasNext: boolean;
  onPrev: () => void;
  onNext: () => void;
  onSave: () => void;
  onClose: () => void;
}

const STATUS_LABEL: Record<SaveStatus, string> = {
  idle: '',
  editing: 'Unsaved changes',
  saving: 'Saving…',
  'saved-local': 'Saved locally',
  synced: 'Synced',
  error: 'Save failed',
};

const STATUS_COLOR: Record<SaveStatus, string> = {
  idle: 'text-[var(--text-muted)]',
  editing: 'text-[var(--warning)]',
  saving: 'text-[var(--text-muted)]',
  'saved-local': 'text-[var(--success)]',
  synced: 'text-[var(--success)]',
  error: 'text-[var(--danger)]',
};

export function WorkspaceFooter({
  saveStatus, hasPrev, hasNext, onPrev, onNext, onSave, onClose,
}: WorkspaceFooterProps) {
  return (
    <div className="border-t border-[var(--border-default)] px-5 py-3 flex items-center justify-between gap-3 shrink-0">
      {/* Navigation */}
      <div className="flex items-center gap-1">
        <button
          onClick={onPrev}
          disabled={!hasPrev}
          className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--text-muted)] transition-colors hover:bg-[var(--bg-overlay)] hover:text-[var(--text-primary)] disabled:opacity-30 disabled:cursor-not-allowed"
          title="Previous problem (←)"
        >
          <ChevronLeft size={14} />
        </button>
        <button
          onClick={onNext}
          disabled={!hasNext}
          className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--text-muted)] transition-colors hover:bg-[var(--bg-overlay)] hover:text-[var(--text-primary)] disabled:opacity-30 disabled:cursor-not-allowed"
          title="Next problem (→)"
        >
          <ChevronRight size={14} />
        </button>
        <span className={cn('ml-1 text-[11px]', STATUS_COLOR[saveStatus])}>
          {STATUS_LABEL[saveStatus]}
        </span>
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <Button variant="ghost" size="sm" onClick={onClose}>Cancel</Button>
        <Button
          variant="primary"
          size="sm"
          onClick={onSave}
          loading={saveStatus === 'saving'}
          disabled={saveStatus !== 'editing'}
        >
          Save
        </Button>
      </div>
    </div>
  );
}
