import { X, Star } from 'lucide-react';
import type { Problem, ProblemProgress } from '@/types';
import { DifficultyBadge } from '@/shared/ui/Badge/Badge';
import { cn } from '@/lib/utils';

interface WorkspaceHeaderProps {
  problem: Problem;
  progress: ProblemProgress | undefined;
  onClose: () => void;
  onToggleFavorite: () => void;
}

export function WorkspaceHeader({ problem, progress, onClose, onToggleFavorite }: WorkspaceHeaderProps) {
  const isFavorite = progress?.favorite ?? false;

  return (
    <div className="flex items-start gap-3 border-b border-[var(--border-default)] px-5 py-4 shrink-0">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <DifficultyBadge difficulty={problem.difficulty} />
          {problem.isPremium && (
            <span className="rounded-md bg-[var(--warning-subtle)] px-1.5 py-0.5 text-[10px] text-[var(--warning)]">
              Premium
            </span>
          )}
        </div>
        <h2 className="mt-1.5 text-base font-semibold text-[var(--text-primary)] leading-tight">
          {problem.title}
        </h2>
        <p className="mt-0.5 text-xs text-[var(--text-muted)]">{problem.topic}</p>
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <button
          onClick={onToggleFavorite}
          className={cn(
            'flex h-7 w-7 items-center justify-center rounded-md transition-colors',
            isFavorite
              ? 'text-[var(--warning)]'
              : 'text-[var(--text-muted)] hover:text-[var(--warning)]'
          )}
          title={isFavorite ? 'Unfavorite' : 'Favorite'}
        >
          <Star size={14} fill={isFavorite ? 'currentColor' : 'none'} />
        </button>
        <button
          onClick={onClose}
          className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--text-muted)] hover:bg-[var(--bg-overlay)] hover:text-[var(--text-primary)] transition-colors"
          title="Close (Esc)"
        >
          <X size={14} />
        </button>
      </div>
    </div>
  );
}
