import type { Problem, ProblemProgress } from '@/types';

interface WorkspaceMetadataProps {
  problem: Problem;
  progress: ProblemProgress | undefined;
}

export function WorkspaceMetadata({ problem, progress }: WorkspaceMetadataProps) {
  return (
    <div className="space-y-4">
      {/* Tags */}
      {problem.tags.length > 0 && (
        <div>
          <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">Tags</div>
          <div className="flex flex-wrap gap-1.5">
            {problem.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full bg-[var(--bg-overlay)] border border-[var(--border-muted)] px-2.5 py-0.5 text-[11px] text-[var(--text-secondary)]"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Companies */}
      {problem.companies.length > 0 && (
        <div>
          <div className="mb-2 text-xs font-semibold text-[var(--text-secondary)]">Asked at</div>
          <div className="flex flex-wrap gap-1.5">
            {problem.companies.map((c) => (
              <span
                key={c}
                className="rounded-full bg-[var(--accent-subtle)] px-2.5 py-0.5 text-[11px] text-[var(--accent)]"
              >
                {c}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Stats */}
      {progress && progress.attempts > 0 && (
        <div className="rounded-md bg-[var(--bg-overlay)] px-3 py-2 space-y-1">
          <div className="flex justify-between text-[11px]">
            <span className="text-[var(--text-muted)]">Attempts</span>
            <span className="tabular-nums text-[var(--text-secondary)]">{progress.attempts}</span>
          </div>
          {progress.lastSolved && (
            <div className="flex justify-between text-[11px]">
              <span className="text-[var(--text-muted)]">Last solved</span>
              <span className="text-[var(--text-secondary)]">
                {new Date(progress.lastSolved).toLocaleDateString()}
              </span>
            </div>
          )}
          {progress.nextReview && (
            <div className="flex justify-between text-[11px]">
              <span className="text-[var(--text-muted)]">Next review</span>
              <span className="text-[var(--text-secondary)]">
                {new Date(progress.nextReview).toLocaleDateString()}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
