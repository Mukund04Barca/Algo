const MAX_NOTES = 20_000;

interface WorkspaceNotesProps {
  notes: string;
  onChange: (notes: string) => void;
}

export function WorkspaceNotes({ notes, onChange }: WorkspaceNotesProps) {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-semibold text-[var(--text-secondary)]">Notes</span>
        <span className={`text-[10px] tabular-nums ${notes.length > MAX_NOTES * 0.9 ? 'text-[var(--warning)]' : 'text-[var(--text-muted)]'}`}>
          {notes.length.toLocaleString()} / {MAX_NOTES.toLocaleString()}
        </span>
      </div>
      <textarea
        value={notes}
        onChange={(e) => onChange(e.target.value.slice(0, MAX_NOTES))}
        placeholder="Approach, edge cases, key insight…"
        rows={5}
        className="w-full rounded-md border border-[var(--border-default)] bg-[var(--bg-overlay)] px-3 py-2 text-xs text-[var(--text-primary)] placeholder:text-[var(--text-muted)] outline-none focus:border-[var(--accent)] resize-none font-mono"
      />
    </div>
  );
}
