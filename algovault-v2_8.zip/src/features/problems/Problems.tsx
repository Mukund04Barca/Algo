import { useState, useMemo } from 'react';
import { Search } from 'lucide-react';
import { useProgressStore } from '@/store';
import { useRoadmaps } from '@/hooks';
import { Input } from '@/shared/ui/Input/Input';
import { EmptyState } from '@/shared/ui/EmptyState/EmptyState';
import type { Roadmap, RoadmapTopic, Problem } from '@/types';
import { cn } from '@/lib/utils';
import { TopicRow } from './TopicRow';
import { ProblemWorkspace } from './ProblemWorkspace';

interface WorkspaceState {
  problem: Problem;
  /** All problems in the same topic for ← → navigation */
  siblings: Problem[];
}

export default function Problems() {
  const { userData } = useProgressStore();
  const { roadmaps } = useRoadmaps();

  const [activeRoadmapId, setActiveRoadmapId] = useState<string>(roadmaps[0]?.id ?? '');
  const [query, setQuery] = useState('');
  const [workspace, setWorkspace] = useState<WorkspaceState | null>(null);

  const activeRoadmap: Roadmap | undefined = roadmaps.find((r) => r.id === activeRoadmapId);

  const filteredTopics: RoadmapTopic[] = useMemo(() => {
    if (!activeRoadmap) return [];
    if (!query.trim()) return activeRoadmap.topics;
    const q = query.toLowerCase();
    return activeRoadmap.topics
      .map((topic) => ({
        ...topic,
        problems: topic.problems.filter(
          (p) =>
            p.title.toLowerCase().includes(q) ||
            p.topic.toLowerCase().includes(q) ||
            p.tags.some((t) => t.toLowerCase().includes(q)) ||
            p.companies.some((c) => c.toLowerCase().includes(q))
        ),
      }))
      .filter((t) => t.problems.length > 0);
  }, [activeRoadmap, query]);

  const roadmapStats = useMemo(() => {
    if (!activeRoadmap) return { solved: 0, total: 0 };
    const total = activeRoadmap.totalProblems;
    const solved = activeRoadmap.topics
      .flatMap((t) => t.problems)
      .filter((p) => {
        const s = userData.progress[p.id]?.status;
        return s === 'Solved' || s === 'Mastered';
      }).length;
    return { solved, total };
  }, [activeRoadmap, userData]);

  function openWorkspace(problem: Problem, siblings: Problem[]) {
    setWorkspace({ problem, siblings });
  }

  function navigateWorkspace(problem: Problem) {
    if (!workspace) return;
    setWorkspace({ ...workspace, problem });
  }

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="border-b border-[var(--border-default)] px-6 py-4 shrink-0">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">Problems</h1>
            <p className="mt-0.5 text-sm text-[var(--text-secondary)]">
              {roadmapStats.solved} of {roadmapStats.total} solved
              {query && ` · ${filteredTopics.reduce((n, t) => n + t.problems.length, 0)} results`}
            </p>
          </div>
          <Input
            className="w-64"
            placeholder="Search title, tag, company…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            iconLeft={<Search size={13} />}
          />
        </div>

        {/* Roadmap tabs */}
        <div className="mt-3 flex gap-0.5">
          {roadmaps.map((rm) => {
            const total = rm.totalProblems;
            const done = rm.topics
              .flatMap((t) => t.problems)
              .filter((p) => {
                const s = userData.progress[p.id]?.status;
                return s === 'Solved' || s === 'Mastered';
              }).length;
            const active = activeRoadmapId === rm.id;
            return (
              <button
                key={rm.id}
                onClick={() => { setActiveRoadmapId(rm.id); setQuery(''); }}
                className={cn(
                  'flex items-center gap-2 rounded-md px-3 py-1.5 text-xs font-medium transition-colors',
                  active
                    ? 'bg-[var(--accent-subtle)] text-[var(--accent)]'
                    : 'text-[var(--text-secondary)] hover:bg-[var(--bg-overlay)] hover:text-[var(--text-primary)]'
                )}
              >
                {rm.name}
                <span className={cn(
                  'rounded-full px-1.5 py-0.5 text-[10px] tabular-nums',
                  active
                    ? 'bg-[var(--accent)] text-[#0d1117]'
                    : 'bg-[var(--bg-overlay)] text-[var(--text-muted)]'
                )}>
                  {done}/{total}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto">
        {!activeRoadmap ? (
          <EmptyState title="No roadmap selected" />
        ) : filteredTopics.length === 0 ? (
          <EmptyState
            title="No results"
            description={`No problems match "${query}"`}
            action={{ label: 'Clear search', onClick: () => setQuery('') }}
          />
        ) : (
          <div className="divide-y divide-[var(--border-muted)]">
            {filteredTopics.map((topic) => (
              <TopicRow
                key={topic.id}
                topic={topic}
                progress={userData.progress}
                onSelectProblem={(p) => openWorkspace(p, topic.problems)}
                defaultOpen={filteredTopics.length === 1 || query.length > 0}
              />
            ))}
          </div>
        )}
      </div>

      {/* Workspace */}
      {workspace && (
        <ProblemWorkspace
          problem={workspace.problem}
          progress={userData.progress[workspace.problem.id]}
          siblingProblems={workspace.siblings}
          onClose={() => setWorkspace(null)}
          onNavigate={navigateWorkspace}
        />
      )}
    </div>
  );
}
