import { z } from 'zod';
import { LanguageSchema, ProblemStatusSchema, RoadmapIdSchema } from './problem.schema';

export const SolutionSchema = z.object({
  language: LanguageSchema,
  code: z.string(),
  timeComplexity: z.string(),
  spaceComplexity: z.string(),
  approach: z.string(),
  solvedAt: z.string().datetime(),
});

export const ReviewEventSchema = z.object({
  reviewedAt: z.string().datetime(),
  confidence: z.number().int().min(1).max(5),
});

export const ProblemComplexitySchema = z.object({
  time: z.string().optional(),
  space: z.string().optional(),
});

export const ActivitySourceSchema = z.enum(['workspace', 'revision', 'import']);

export const ActivityEventSchema = z.object({
  problemId: z.string().min(1),
  roadmapId: RoadmapIdSchema,
  topicId: z.string().min(1),
  status: ProblemStatusSchema,
  timestamp: z.string().datetime(),
  source: ActivitySourceSchema,
});

export const ProblemProgressSchema = z.object({
  problemId: z.string().min(1),
  status: ProblemStatusSchema,
  confidence: z.number().int().min(1).max(5),
  attempts: z.number().int().nonnegative(),
  timeTaken: z.number().nonnegative(),
  notes: z.string(),
  mistakes: z.string(),
  complexity: ProblemComplexitySchema,
  solutions: z.array(SolutionSchema),
  reviewHistory: z.array(ReviewEventSchema),
  nextReview: z.string().datetime().nullable(),
  easeFactor: z.number().min(1.3),
  interval: z.number().int().nonnegative(),
  lastSolved: z.string().datetime().nullable(),
  favorite: z.boolean(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
