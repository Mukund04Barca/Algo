import { z } from 'zod';
import { ProblemProgressSchema } from './progress.schema';

export const DATA_VERSION = '2.1.0' as const;

export const UserProfileSchema = z.object({
  githubLogin: z.string(),
  githubName: z.string(),
  avatarUrl: z.string(),
  repoName: z.string(),
});

export const UserDataSchema = z.object({
  version: z.string(),
  profile: UserProfileSchema,
  progress: z.record(z.string(), ProblemProgressSchema),
  dailyActivity: z.record(z.string(), z.number().nonnegative()),
  streak: z.number().int().nonnegative(),
  longestStreak: z.number().int().nonnegative(),
  lastActiveDate: z.string().datetime().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
