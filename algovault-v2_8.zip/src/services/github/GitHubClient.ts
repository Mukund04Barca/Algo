import type { GitHubUser } from '@/types';

const GITHUB_API = 'https://api.github.com';

export class GitHubClient {
  constructor(private readonly token: string) {}

  private async request<T>(path: string, options: RequestInit = {}): Promise<T> {
    const res = await fetch(`${GITHUB_API}${path}`, {
      ...options,
      headers: {
        Authorization: `Bearer ${this.token}`,
        Accept: 'application/vnd.github+json',
        'Content-Type': 'application/json',
        'X-GitHub-Api-Version': '2022-11-28',
        ...options.headers,
      },
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({})) as { message?: string };
      throw new Error(`GitHub API ${res.status}: ${body.message ?? res.statusText}`);
    }

    return res.json() as Promise<T>;
  }

  async getUser(): Promise<GitHubUser> {
    return this.request<GitHubUser>('/user');
  }

  async repoExists(owner: string, repo: string): Promise<boolean> {
    try {
      await this.request(`/repos/${owner}/${repo}`);
      return true;
    } catch {
      return false;
    }
  }

  async createRepo(name: string): Promise<void> {
    await this.request('/user/repos', {
      method: 'POST',
      body: JSON.stringify({
        name,
        private: true,
        description: 'AlgoVault — DSA progress tracker',
        auto_init: true,
      }),
    });
  }

  async getFile(owner: string, repo: string, path: string): Promise<{ sha: string; content: string } | null> {
    try {
      const data = await this.request<{ sha: string; content: string }>(
        `/repos/${owner}/${repo}/contents/${path}`
      );
      return data;
    } catch {
      return null;
    }
  }

  async putFile(
    owner: string,
    repo: string,
    path: string,
    content: string,
    message: string,
    sha?: string
  ): Promise<void> {
    await this.request(`/repos/${owner}/${repo}/contents/${path}`, {
      method: 'PUT',
      body: JSON.stringify({
        message,
        content: btoa(unescape(encodeURIComponent(content))),
        ...(sha ? { sha } : {}),
      }),
    });
  }
}
