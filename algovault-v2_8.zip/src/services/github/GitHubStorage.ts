import type { StorageAdapter } from '@/services/storage/StorageAdapter';
import type { UserData } from '@/types';
import { GitHubClient } from './GitHubClient';
import { migrateUserData } from '@/services/migration/migrate';

const DATA_PATH = 'progress/data.json';

/**
 * GitHubStorage — StorageAdapter backed by a private GitHub repo.
 * Tracks file SHA for conflict-free updates.
 * All reads pass through the migration + Zod validation pipeline.
 */
export class GitHubStorage implements StorageAdapter {
  readonly name = 'GitHub';
  private sha: string | null = null;

  constructor(
    private readonly client: GitHubClient,
    private readonly owner: string,
    private readonly repo: string,
  ) {}

  async load(): Promise<UserData | null> {
    const file = await this.client.getFile(this.owner, this.repo, DATA_PATH);
    if (!file) return null;

    this.sha = file.sha;

    let raw: unknown;
    try {
      const json = decodeURIComponent(escape(atob(file.content.replace(/\n/g, ''))));
      raw = JSON.parse(json);
    } catch {
      console.error('[GitHubStorage] Failed to parse JSON from repo');
      return null;
    }

    const { data, error, fromVersion, migrated } = migrateUserData(raw);

    if (error && !data) {
      console.warn(`[GitHubStorage] Load failed (from v${fromVersion}): ${error}`);
    } else if (migrated) {
      console.info(`[GitHubStorage] Migrated data from v${fromVersion}`);
    }

    return data;
  }

  async save(data: UserData): Promise<void> {
    const content = JSON.stringify(data, null, 2);
    await this.client.putFile(
      this.owner,
      this.repo,
      DATA_PATH,
      content,
      `chore: sync progress ${new Date().toISOString()}`,
      this.sha ?? undefined,
    );
    this.sha = null;
  }

  async delete(): Promise<void> {
    // No-op: don't delete from GitHub on disconnect.
  }
}
