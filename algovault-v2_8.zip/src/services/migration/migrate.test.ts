import { describe, it, expect } from 'vitest';
import { migrateUserData } from './migrate';
import { DATA_VERSION } from '@/lib/zod/user.schema';

// Minimal valid v2.1.0 UserData
function makeCurrentData(overrides: Record<string, unknown> = {}): unknown {
  const now = new Date().toISOString();
  return {
    version: DATA_VERSION,
    profile: { githubLogin: '', githubName: 'Test', avatarUrl: '', repoName: '' },
    progress: {},
    dailyActivity: {},
    streak: 0,
    longestStreak: 0,
    lastActiveDate: null,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

// Minimal valid v2.0.0 UserData (old schema with top-level complexity fields)
function makeV200Data(progressEntries: Record<string, unknown> = {}): unknown {
  const now = new Date().toISOString();
  return {
    version: '2.0.0',
    profile: { githubLogin: 'user', githubName: 'User', avatarUrl: 'https://example.com/a.png', repoName: 'test' },
    progress: progressEntries,
    dailyActivity: {},
    streak: 0,
    longestStreak: 0,
    lastActiveDate: null,
    createdAt: now,
    updatedAt: now,
  };
}

function makeV200Progress(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  const now = new Date().toISOString();
  return {
    problemId: 'p-001',
    status: 'Solved',
    confidence: 4,
    attempts: 1,
    timeTaken: 0,
    notes: '',
    mistakes: '',
    timeComplexity: 'O(n)',
    spaceComplexity: 'O(1)',
    solutions: [],
    reviewHistory: [],
    nextReview: null,
    easeFactor: 2.5,
    interval: 1,
    lastSolved: now,
    favorite: false,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

describe('migrateUserData', () => {
  it('accepts current version without migrating', () => {
    const result = migrateUserData(makeCurrentData());
    expect(result.data).not.toBeNull();
    expect(result.migrated).toBe(false);
    expect(result.fromVersion).toBe(DATA_VERSION);
  });

  it('returns null for non-object input', () => {
    expect(migrateUserData(null).data).toBeNull();
    expect(migrateUserData('string').data).toBeNull();
    expect(migrateUserData(42).data).toBeNull();
  });

  it('returns null for unknown version with no migration path', () => {
    const result = migrateUserData(makeCurrentData({ version: '99.0.0' }));
    expect(result.data).toBeNull();
    expect(result.migrated).toBe(true);
    expect(result.error).toContain('No path from');
  });

  it('migrates v2.0.0 to current version', () => {
    const raw = makeV200Data({ 'p-001': makeV200Progress() });
    const result = migrateUserData(raw);
    expect(result.data).not.toBeNull();
    expect(result.migrated).toBe(true);
    expect(result.fromVersion).toBe('2.0.0');
    expect(result.data?.version).toBe(DATA_VERSION);
  });

  it('converts timeComplexity/spaceComplexity to complexity object', () => {
    const raw = makeV200Data({ 'p-001': makeV200Progress({ timeComplexity: 'O(n)', spaceComplexity: 'O(1)' }) });
    const result = migrateUserData(raw);
    const prog = result.data?.progress['p-001'];
    expect(prog?.complexity).toEqual({ time: 'O(n)', space: 'O(1)' });
  });

  it('handles empty timeComplexity/spaceComplexity gracefully', () => {
    const raw = makeV200Data({ 'p-001': makeV200Progress({ timeComplexity: '', spaceComplexity: '' }) });
    const result = migrateUserData(raw);
    const prog = result.data?.progress['p-001'];
    expect(prog?.complexity).toEqual({ time: undefined, space: undefined });
  });

  it('returns null and sets error when current version fails validation', () => {
    const bad = makeCurrentData({ streak: 'not-a-number' });
    const result = migrateUserData(bad);
    expect(result.data).toBeNull();
    expect(result.error).toBeTruthy();
  });
});
