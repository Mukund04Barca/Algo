import type { UserData } from '@/types';
import { UserDataSchema, DATA_VERSION } from '@/lib/zod/user.schema';

const V2_1_0 = '2.1.0' as const;

type MigrationData = Record<string, unknown>;
type MigrationFn = (raw: MigrationData) => MigrationData | null;

/**
 * Migration registry.
 * Each entry migrates from its key version to the next.
 * Return null to signal the migration cannot be completed → start fresh.
 */
const migrations: Record<string, MigrationFn> = {
  '2.0.0': (raw) => {
    // 2.0.0 → 2.1.0: replace timeComplexity/spaceComplexity with complexity: { time?, space? }
    const progress = raw['progress'] as Record<string, MigrationData> | undefined;
    if (!progress) return { ...raw, version: V2_1_0 };

    const migratedProgress: Record<string, MigrationData> = {};
    for (const [id, prog] of Object.entries(progress)) {
      const { timeComplexity, spaceComplexity, ...rest } = prog;
      migratedProgress[id] = {
        ...rest,
        complexity: {
          time: typeof timeComplexity === 'string' && timeComplexity ? timeComplexity : undefined,
          space: typeof spaceComplexity === 'string' && spaceComplexity ? spaceComplexity : undefined,
        },
      };
    }

    return { ...raw, version: V2_1_0, progress: migratedProgress };
  },
};

export interface MigrationResult {
  data: UserData | null;
  migrated: boolean;
  fromVersion: string;
  error?: string;
}

/**
 * Attempt to load and migrate raw persisted data to the current schema.
 *
 * Priority:
 * 1. Raw data matches current version → validate and return.
 * 2. Migration path exists → migrate, validate, return.
 * 3. No path → return null (start fresh), log warning.
 */
export function migrateUserData(raw: unknown): MigrationResult {
  if (typeof raw !== 'object' || raw === null) {
    return { data: null, migrated: false, fromVersion: 'unknown', error: 'Not an object' };
  }

  const rawObj = raw as MigrationData;
  const rawVersion = rawObj['version'];
  const fromVersion = typeof rawVersion === 'string' ? rawVersion : 'unknown';

  // Already current — just validate
  if (fromVersion === DATA_VERSION) {
    const result = UserDataSchema.safeParse(raw);
    if (result.success) return { data: result.data as UserData, migrated: false, fromVersion };
    console.warn('[Migration] Current version failed validation:', result.error.flatten());
    return { data: null, migrated: false, fromVersion, error: 'Validation failed' };
  }

  // Try migration chain
  let current: MigrationData = rawObj;
  let currentVersion = fromVersion;
  const visited = new Set<string>();

  while (currentVersion !== DATA_VERSION) {
    if (visited.has(currentVersion)) {
      const msg = `[Migration] Cycle detected at version ${currentVersion}`;
      console.error(msg);
      return { data: null, migrated: true, fromVersion, error: msg };
    }
    visited.add(currentVersion);

    const migrate = migrations[currentVersion];
    if (!migrate) {
      const msg = `[Migration] No path from ${currentVersion} to ${DATA_VERSION} — starting fresh`;
      console.warn(msg);
      return { data: null, migrated: true, fromVersion, error: msg };
    }

    const next = migrate(current);
    if (next === null) {
      const msg = `[Migration] Migration from ${currentVersion} returned null — starting fresh`;
      console.warn(msg);
      return { data: null, migrated: true, fromVersion, error: msg };
    }

    current = next;
    currentVersion = typeof current['version'] === 'string' ? current['version'] : 'unknown';
    console.info(`[Migration] Migrated to v${currentVersion}`);
  }

  const result = UserDataSchema.safeParse(current);
  if (!result.success) {
    console.warn('[Migration] Post-migration validation failed:', result.error.flatten());
    return { data: null, migrated: true, fromVersion, error: 'Post-migration validation failed' };
  }

  return { data: result.data as UserData, migrated: true, fromVersion };
}
