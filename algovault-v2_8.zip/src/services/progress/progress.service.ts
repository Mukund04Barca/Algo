import type { ProblemProgress } from '@/types';
import { DEFAULT_EASE_FACTOR } from '@/features/revision/RevisionEngine';
import { computeNextReview } from '@/features/revision/RevisionEngine';
import type { SaveProblemPayload, SaveProblemActions, ToggleFavoriteActions } from './progress.types';

/**
 * ProgressService — pure functions orchestrating progress workflows.
 *
 * Architectural invariants:
 * - Components express intent ("save this problem"), not implementation.
 * - These functions are the ONLY path that calls updateProgress or markActivity.
 * - No React imports — fully testable outside React.
 */

const SOLVED_STATUSES = new Set(['Solved', 'Mastered']);

function isFirstSolve(
  existing: ProblemProgress | undefined,
  newStatus: string
): boolean {
  const wasUnsolved = !existing || !SOLVED_STATUSES.has(existing.status);
  return wasUnsolved && SOLVED_STATUSES.has(newStatus);
}

export function createFreshProgress(problemId: string): ProblemProgress {
  const now = new Date().toISOString();
  return {
    problemId,
    status: 'Not Started',
    confidence: 3,
    attempts: 0,
    timeTaken: 0,
    notes: '',
    mistakes: '',
    complexity: {},
    solutions: [],
    reviewHistory: [],
    nextReview: null,
    easeFactor: DEFAULT_EASE_FACTOR,
    interval: 0,
    lastSolved: null,
    favorite: false,
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * saveProblem — the primary workflow for updating a problem's progress.
 *
 * Handles:
 * - First solve detection
 * - SM-2 next review computation on solve
 * - Attempt counting (only on first solve)
 * - Activity event (only on first solve)
 */
export function saveProblem(
  payload: SaveProblemPayload,
  existing: ProblemProgress | undefined,
  actions: SaveProblemActions
): void {
  const { problemId, roadmapId, topicId, status, confidence, notes, complexity, source = 'workspace' } = payload;
  const base = existing ?? createFreshProgress(problemId);
  const now = new Date().toISOString();
  const firstSolve = isFirstSolve(existing, status);

  let nextReview = base.nextReview;
  let newInterval = base.interval;
  let newEaseFactor = base.easeFactor;

  if (firstSolve) {
    const reviewed = computeNextReview(confidence, base.interval, base.easeFactor);
    nextReview = reviewed.nextReview.toISOString();
    newInterval = reviewed.newInterval;
    newEaseFactor = reviewed.newEaseFactor;
  }

  actions.updateProgress(problemId, {
    ...base,
    status,
    confidence,
    notes,
    complexity,
    attempts: firstSolve ? base.attempts + 1 : base.attempts,
    lastSolved: firstSolve ? now : base.lastSolved,
    nextReview,
    interval: newInterval,
    easeFactor: newEaseFactor,
    updatedAt: now,
  });

  if (firstSolve) {
    actions.markActivity({
      problemId,
      roadmapId,
      topicId,
      status,
      timestamp: now,
      source,
    });
  }
}

/**
 * toggleFavorite — immediate, no save button required.
 */
export function toggleFavorite(
  problemId: string,
  existing: ProblemProgress | undefined,
  actions: ToggleFavoriteActions
): void {
  const base = existing ?? createFreshProgress(problemId);
  actions.updateProgress(problemId, {
    ...base,
    favorite: !base.favorite,
    updatedAt: new Date().toISOString(),
  });
}

/**
 * reviewProblem — called from the Revision page after a spaced repetition session.
 * Updates review history, computes next review date, and upgrades status to
 * Mastered after 4 successful reviews.
 */
export function reviewProblem(
  problemId: string,
  existing: ProblemProgress,
  actions: { updateProgress: (id: string, patch: Partial<ProblemProgress>) => void }
): void {
  const { nextReview, newInterval, newEaseFactor } = computeNextReview(
    existing.confidence,
    existing.interval,
    existing.easeFactor
  );

  const newReviewHistory = [
    ...existing.reviewHistory,
    { reviewedAt: new Date().toISOString(), confidence: existing.confidence },
  ];

  actions.updateProgress(problemId, {
    reviewHistory: newReviewHistory,
    nextReview: nextReview.toISOString(),
    interval: newInterval,
    easeFactor: newEaseFactor,
    status: newReviewHistory.length >= 4 ? 'Mastered' : existing.status,
    updatedAt: new Date().toISOString(),
  });
}
