import { describe, it, expect, vi } from 'vitest';
import { saveProblem, toggleFavorite, createFreshProgress } from './progress.service';
import type { SaveProblemActions, ToggleFavoriteActions } from './progress.types';
import type { ProblemProgress } from '@/types';

function makeActions(): SaveProblemActions {
  return {
    updateProgress: vi.fn(),
    markActivity: vi.fn(),
  };
}

function getUpdateCall(actions: SaveProblemActions, index = 0): ProblemProgress {
  return (actions.updateProgress as ReturnType<typeof vi.fn>).mock.calls[index][1] as ProblemProgress;
}

const BASE_PAYLOAD = {
  problemId: 'p-001',
  roadmapId: 'striver-a2z' as const,
  topicId: 'striver-arrays-basic',
  status: 'Solved' as const,
  confidence: 4,
  notes: 'Used two pointers',
  complexity: { time: 'O(n)', space: 'O(1)' },
};

describe('saveProblem', () => {
  it('creates fresh progress when none exists', () => {
    const actions = makeActions();
    saveProblem(BASE_PAYLOAD, undefined, actions);
    expect(actions.updateProgress).toHaveBeenCalledOnce();
    const patch = getUpdateCall(actions);
    expect(patch.status).toBe('Solved');
    expect(patch.attempts).toBe(1);
    expect(patch.lastSolved).not.toBeNull();
  });

  it('marks activity on first solve', () => {
    const actions = makeActions();
    saveProblem(BASE_PAYLOAD, undefined, actions);
    expect(actions.markActivity).toHaveBeenCalledOnce();
  });

  it('does NOT mark activity on re-save of already-solved problem', () => {
    const actions = makeActions();
    const existing = { ...createFreshProgress('p-001'), status: 'Solved' as const };
    saveProblem(BASE_PAYLOAD, existing, actions);
    expect(actions.markActivity).not.toHaveBeenCalled();
  });

  it('does NOT increment attempts on re-save', () => {
    const actions = makeActions();
    const existing = { ...createFreshProgress('p-001'), status: 'Solved' as const, attempts: 3 };
    saveProblem(BASE_PAYLOAD, existing, actions);
    const patch = getUpdateCall(actions);
    expect(patch.attempts).toBe(3);
  });

  it('computes nextReview on first solve', () => {
    const actions = makeActions();
    saveProblem(BASE_PAYLOAD, undefined, actions);
    const patch = getUpdateCall(actions);
    expect(patch.nextReview).not.toBeNull();
  });

  it('does NOT recompute nextReview on re-save', () => {
    const actions = makeActions();
    const existing = {
      ...createFreshProgress('p-001'),
      status: 'Solved' as const,
      nextReview: '2030-01-01T00:00:00.000Z',
    };
    saveProblem(BASE_PAYLOAD, existing, actions);
    const patch = getUpdateCall(actions);
    expect(patch.nextReview).toBe('2030-01-01T00:00:00.000Z');
  });

  it('saves complexity object', () => {
    const actions = makeActions();
    saveProblem({ ...BASE_PAYLOAD, complexity: { time: 'O(n²)', space: 'O(n)' } }, undefined, actions);
    const patch = getUpdateCall(actions);
    expect(patch.complexity).toEqual({ time: 'O(n²)', space: 'O(n)' });
  });

  it('activity event source defaults to workspace', () => {
    const actions = makeActions();
    saveProblem(BASE_PAYLOAD, undefined, actions);
    const event = (actions.markActivity as ReturnType<typeof vi.fn>).mock.calls[0][0] as { source: string };
    expect(event.source).toBe('workspace');
  });

  it('activity event contains roadmapId and topicId', () => {
    const actions = makeActions();
    saveProblem(BASE_PAYLOAD, undefined, actions);
    const event = (actions.markActivity as ReturnType<typeof vi.fn>).mock.calls[0][0] as {
      roadmapId: string;
      topicId: string;
    };
    expect(event.roadmapId).toBe('striver-a2z');
    expect(event.topicId).toBe('striver-arrays-basic');
  });
});

describe('toggleFavorite', () => {
  it('sets favorite true when previously false', () => {
    const actions: ToggleFavoriteActions = { updateProgress: vi.fn() };
    const existing = createFreshProgress('p-001');
    toggleFavorite('p-001', existing, actions);
    const patch = (actions.updateProgress as ReturnType<typeof vi.fn>).mock.calls[0][1] as ProblemProgress;
    expect(patch.favorite).toBe(true);
  });

  it('sets favorite false when previously true', () => {
    const actions: ToggleFavoriteActions = { updateProgress: vi.fn() };
    const existing = { ...createFreshProgress('p-001'), favorite: true };
    toggleFavorite('p-001', existing, actions);
    const patch = (actions.updateProgress as ReturnType<typeof vi.fn>).mock.calls[0][1] as ProblemProgress;
    expect(patch.favorite).toBe(false);
  });

  it('creates fresh progress if none exists', () => {
    const actions: ToggleFavoriteActions = { updateProgress: vi.fn() };
    toggleFavorite('p-001', undefined, actions);
    expect(actions.updateProgress).toHaveBeenCalledOnce();
    const patch = (actions.updateProgress as ReturnType<typeof vi.fn>).mock.calls[0][1] as ProblemProgress;
    expect(patch.favorite).toBe(true);
  });
});
