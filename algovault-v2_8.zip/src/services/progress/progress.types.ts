import type {
  ProblemProgress, ProblemStatus, ProblemComplexity,
  ActivityEvent, ActivitySource, RoadmapId
} from '@/types';

export interface SaveProblemPayload {
  problemId: string;
  roadmapId: RoadmapId;
  topicId: string;
  status: ProblemStatus;
  confidence: number;
  notes: string;
  complexity: ProblemComplexity;
  source?: ActivitySource;
}

export interface SaveProblemActions {
  updateProgress: (id: string, patch: Partial<ProblemProgress>) => void;
  markActivity: (event: ActivityEvent) => void;
}

export interface ToggleFavoriteActions {
  updateProgress: (id: string, patch: Partial<ProblemProgress>) => void;
}
