import type { StorageAdapter } from './StorageAdapter';
import type { UserData } from '@/types';
import { ls, STORAGE_KEYS } from '@/lib/utils';
import { migrateUserData } from '@/services/migration/migrate';

/**
 * LocalStorageAdapter
 * Primary storage in guest mode, write-through cache when GitHub is connected.
 * All reads pass through the migration + Zod validation pipeline.
 */
export class LocalStorageAdapter implements StorageAdapter {
  readonly name = 'LocalStorage';

  async load(): Promise<UserData | null> {
    const raw = ls.get<unknown>(STORAGE_KEYS.DATA_CACHE);
    if (raw === null) return null;

    const { data, migrated, fromVersion, error } = migrateUserData(raw);

    if (error && !data) {
      console.warn(`[LocalStorageAdapter] Load failed (from v${fromVersion}): ${error}`);
    } else if (migrated) {
      console.info(`[LocalStorageAdapter] Migrated data from v${fromVersion}`);
      // Persist the migrated data immediately
      if (data) ls.set(STORAGE_KEYS.DATA_CACHE, data);
    }

    return data;
  }

  async save(data: UserData): Promise<void> {
    ls.set(STORAGE_KEYS.DATA_CACHE, data);
  }

  async delete(): Promise<void> {
    ls.remove(STORAGE_KEYS.DATA_CACHE);
  }
}
