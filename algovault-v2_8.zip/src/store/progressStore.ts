import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type { ProblemProgress, UserData, ActivityEvent } from '@/types';
import { DATA_VERSION } from '@/lib/zod/user.schema';
import { todayKey } from '@/lib/utils';

export function createGuestUserData(): UserData {
  const now = new Date().toISOString();
  return {
    version: DATA_VERSION,
    profile: {
      githubLogin: '',
      githubName: 'Guest',
      avatarUrl: '',
      repoName: '',
    },
    progress: {},
    dailyActivity: {},
    streak: 0,
    longestStreak: 0,
    lastActiveDate: null,
    createdAt: now,
    updatedAt: now,
  };
}

export type SyncStatus = 'idle' | 'syncing' | 'synced' | 'offline' | 'conflict' | 'error';

export interface SyncState {
  status: SyncStatus;
  lastSynced: string | null; // ISO
  error: string | null;
}

interface ProgressState {
  userData: UserData;
  isLoading: boolean;
  syncState: SyncState;
}

interface ProgressActions {
  loadUserData: (data: UserData) => void;
  updateProgress: (id: string, patch: Partial<ProblemProgress>) => void;
  markActivity: (event: ActivityEvent) => void;
  setSyncing: (syncing: boolean) => void;
  setSyncError: (error: string | null) => void;
  setSyncSuccess: () => void;
  setSyncOffline: () => void;
  clearUserData: () => void;
}

type ProgressStore = ProgressState & ProgressActions;

const INITIAL_SYNC_STATE: SyncState = { status: 'idle', lastSynced: null, error: null };

export const useProgressStore = create<ProgressStore>()(
  devtools(
    immer((set) => ({
      userData: createGuestUserData(),
      isLoading: false,
      syncState: INITIAL_SYNC_STATE,

      loadUserData: (data) => set((state) => {
        state.userData = data;
        state.isLoading = false;
      }),

      updateProgress: (id, patch) => set((state) => {
        const existing = state.userData.progress[id];
        state.userData.progress[id] = {
          ...existing,
          ...patch,
          updatedAt: new Date().toISOString(),
        };
        state.userData.updatedAt = new Date().toISOString();
      }),

      markActivity: (_event) => set((state) => {
        const today = todayKey();
        const prev = state.userData.dailyActivity[today] ?? 0;
        state.userData.dailyActivity[today] = prev + 1;

        const lastActive = state.userData.lastActiveDate;
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().slice(0, 10);

        if (lastActive === yesterdayStr) {
          state.userData.streak += 1;
        } else if (lastActive !== today) {
          state.userData.streak = 1;
        }

        state.userData.longestStreak = Math.max(
          state.userData.streak,
          state.userData.longestStreak
        );
        state.userData.lastActiveDate = today;
        state.userData.updatedAt = new Date().toISOString();
      }),

      setSyncing: (syncing) => set((state) => {
        state.syncState.status = syncing ? 'syncing' : 'idle';
        if (syncing) state.syncState.error = null;
      }),

      setSyncError: (error) => set((state) => {
        state.syncState.status = 'error';
        state.syncState.error = error;
      }),

      setSyncSuccess: () => set((state) => {
        state.syncState.status = 'synced';
        state.syncState.lastSynced = new Date().toISOString();
        state.syncState.error = null;
      }),

      setSyncOffline: () => set((state) => {
        state.syncState.status = 'offline';
      }),

      clearUserData: () => set((state) => {
        state.userData = createGuestUserData();
        state.syncState = INITIAL_SYNC_STATE;
      }),
    })),
    { name: 'ProgressStore' }
  )
);
