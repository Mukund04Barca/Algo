// Analytics types — expanded in Milestone 5 (Analytics Engine)
// Reserved for chart data shapes when the Analytics page gets real data.
export type {};
