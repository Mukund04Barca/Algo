export interface GitHubUser {
  login: string;
  name: string | null;
  avatar_url: string;
  public_repos: number;
}

export interface GitHubAuth {
  token: string;
  user: GitHubUser;
  repoName: string;
}
