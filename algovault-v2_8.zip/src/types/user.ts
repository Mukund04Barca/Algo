import type { Language, ProblemStatus, RoadmapId } from './problem';

export interface Solution {
  language: Language;
  code: string;
  timeComplexity: string;
  spaceComplexity: string;
  approach: string;
  solvedAt: string; // ISO
}

export interface ReviewEvent {
  reviewedAt: string; // ISO
  confidence: number; // 1-5
}

export interface ProblemComplexity {
  time?: string;   // e.g. "O(n log n)"
  space?: string;  // e.g. "O(1)"
}

export type ActivitySource = 'workspace' | 'revision' | 'import';

export interface ActivityEvent {
  problemId: string;
  roadmapId: RoadmapId;
  topicId: string;
  status: ProblemStatus;
  timestamp: string; // ISO
  source: ActivitySource;
}

export interface ProblemProgress {
  problemId: string;
  status: ProblemStatus;
  confidence: number; // 1-5
  attempts: number;
  timeTaken: number; // minutes
  notes: string;
  mistakes: string;
  complexity: ProblemComplexity;
  solutions: Solution[];
  // Spaced repetition
  reviewHistory: ReviewEvent[];
  nextReview: string | null; // ISO
  easeFactor: number; // SM-2, starts at 2.5
  interval: number; // days
  // Meta
  lastSolved: string | null; // ISO
  favorite: boolean;
  createdAt: string; // ISO
  updatedAt: string; // ISO
}

export interface UserProfile {
  githubLogin: string;
  githubName: string;
  avatarUrl: string;
  repoName: string;
}

export type DataVersion = '2.0.0' | '2.1.0';

export interface UserData {
  version: DataVersion;
  profile: UserProfile;
  progress: Record<string, ProblemProgress>;
  dailyActivity: Record<string, number>; // "yyyy-MM-dd" → count
  streak: number;
  longestStreak: number;
  lastActiveDate: string | null; // ISO
  createdAt: string; // ISO
  updatedAt: string; // ISO
}
